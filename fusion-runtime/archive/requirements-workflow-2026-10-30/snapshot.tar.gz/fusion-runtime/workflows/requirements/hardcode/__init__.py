"""Optional program workflow; Cursor's file-tool entry does not import this package."""
