"""Requirements workflow turn: analysis, dialogue, research and both Draft saves (plan §5 steps 2-6).

Copied from ``fusion-runtime-lab`` ``LangGraphRuntimeDriver`` and adapted:

- ``_n01`` / ``_assert_binding``: the project must be in the caller's allowlist
  and the task must be bound to that project; both come from
  ``WorkflowDependencies`` instead of checkpoint state.
- ``_n02`` / ``_read_context``: a requirements-role read context at ``N02``
  reads the project, README, decisions, requirements and PRD baseline before
  the role is called. ``_sha_or_missing`` / ``_sha_or_empty`` are not copied:
  an absent file stays ``missing`` and a failed read blocks the turn.
- ``_n03``: a read-only requirements context at ``N03`` and one
  ``AgentRunner.run`` call. The request carries the role rules, the user's
  words, material and document text and the result protocol instead of
  ``artifact=prd``; the result is parsed with ``parse_agent_result``.
- ``_n04``: the ``SavePrdDraftCommand`` built from expected versions, the
  deterministic ``N04`` write context with ``prd`` scope, the ``save_draft``
  grant check and ``_require_save_sha256``. The expected versions come from
  the candidate baseline, never from a fresh read; the PRD history path is
  granted when a previous PRD exists. The save goes through the injected
  adapter's public ``save_prd_draft``.
- ``_n05``: the requirements read context at ``N05`` and ``inspect_draft``
  digest, status and issue checks; a failed check is reported as written but
  not verified instead of raising.

The lightweight save shares the authorization, baseline comparison, effect
observation and partial-success handling in ``_DraftSave``. It uses the same
deterministic ``N04`` grant with ``requirements`` scope and calls
``RequirementsTools.save_requirements_draft``; there is no structure check, so
the N05 re-read of metadata, body, digest and history decides the result.

Multi-turn dialogue (plan §5 step 5) reuses the same N02 read and N03 role
call for ``analyze`` with progress, ``answer`` and ``revise``. Each such turn
calls the role at most once, inherits or re-checks the material set, merges
answers and explicit user choices into the caller-held ``Progress`` and gives
the role that progress and the previous candidate text, never a save grant. A
new candidate always gets a fresh baseline and, after an earlier candidate, a
new revision id, so an older save reference cannot authorize it. ``pause`` and
``resume`` only move the stage; they call no role or tool.

Research (plan §4.3, §5 step 6): a ``research`` turn runs the pending request
through the caller's injected ``research(request)`` at most once, within the
caller's finite budget, and records the result in ``Progress``; it calls no
role, reads nothing and writes nothing. The same request on the same inputs
returns its recorded result without another call. A later ``analyze`` goes
through the same analysis turn and gives the role the records, marking those
taken on other inputs as history only.

Index registration is rejected before any read, role call or tool call.
"""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from datetime import datetime, timezone
import json
import re
from types import MappingProxyType
from typing import Callable, Mapping

from fusion_runtime.domain.commands import SavePrdDraftCommand
from fusion_runtime.domain.errors import (
    AuthorizationError,
    ConflictError,
    ValidationError,
)
from fusion_runtime.domain.models import WorkflowRun, WorkflowState
from fusion_runtime.domain.policy import (
    DETERMINISTIC_ROLE,
    SAVE_DRAFT,
    CapabilityPolicy,
    ServerAssignment,
)
from fusion_runtime.ports.agents import AgentRequest, AgentRunner
from fusion_runtime.ports.domain_tools import DomainTools

from .contracts import (
    _OPTION_KEYS,
    _PAYLOAD_KEYS,
    _QUESTION_KEYS,
    _RESULT_KEYS,
    _SOURCE_REF_KEYS,
    DELIVERABLE_TARGETS,
    MISSING,
    ROLE,
    SCHEMA_VERSION,
    Action,
    Answer,
    Baseline,
    BlockedReport,
    Candidate,
    Choice,
    ContractError,
    Deliverable,
    Progress,
    Question,
    ResearchOutcome,
    ResearchRecord,
    ResearchRequest,
    ResearchResult,
    ResultKind,
    RoleResult,
    SourceMaterial,
    Stage,
    ToolResult,
    TurnInput,
    TurnResult,
    check_transition,
    check_turn,
    digest,
    parse_agent_result,
    research_request_id,
)
from .tools import (
    REQUIREMENTS_SAVE_READABLE,
    DocumentRead,
    ReadFailedError,
    RequirementsTools,
    RoleRules,
    requirements_history_path,
)

N02 = "N02"
N03 = "N03"
N04 = "N04"
N05 = "N05"
WORKFLOW_TYPE = "requirements"
INSTRUCTION = "requirements-turn"
_ATTEMPT = 1
_N02_READABLE = frozenset({"docs", "project.json", "README.md"})
_N03_READABLE = frozenset({"docs"})
PRD_PATH = DELIVERABLE_TARGETS[Deliverable.PRD]
_REQUIREMENTS_PATH = DELIVERABLE_TARGETS[Deliverable.REQUIREMENTS]
_N04_READABLE = frozenset({"project.json", "README.md", PRD_PATH, _REQUIREMENTS_PATH})
_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
_SAVE_ERRORS = (AuthorizationError, ConflictError, ValidationError)


class UnsupportedActionError(ContractError):
    """The turn is valid but this workflow step does not handle it yet."""


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


@dataclass(frozen=True, slots=True)
class WorkflowDependencies:
    """Caller-owned trusted configuration; never derived from turn content.

    For a first turn with a known research or full-PRD purpose, the caller selects
    the corresponding include flag. Later analysis also infers method needs from
    kept research progress and the existing candidate, never from body keywords.
    """

    allowed_projects: frozenset[str]
    task_projects: Mapping[str, str]
    agent_runner: AgentRunner
    tools: RequirementsTools
    domain_tools: DomainTools | None = None
    policy: CapabilityPolicy = field(default_factory=CapabilityPolicy)
    clock: Callable[[], datetime] = _utc_now
    research: Callable[[ResearchRequest], ResearchResult] | None = None
    research_budget: int = 0
    include_prd_template: bool = False
    include_research_methods: bool = False

    def __post_init__(self) -> None:
        if not isinstance(self.allowed_projects, frozenset) or not all(
            isinstance(p, str) for p in self.allowed_projects
        ):
            raise ContractError("allowed_projects must be a frozenset of str")
        if not isinstance(self.task_projects, Mapping):
            raise ContractError("task_projects must be a mapping")
        if self.research is not None and not callable(self.research):
            raise ContractError("research must be callable")
        if type(self.research_budget) is not int or self.research_budget < 0:
            raise ContractError("research_budget must be a non-negative int")
        if type(self.include_prd_template) is not bool:
            raise ContractError("include_prd_template must be a boolean")
        if type(self.include_research_methods) is not bool:
            raise ContractError("include_research_methods must be a boolean")
        object.__setattr__(
            self, "task_projects", MappingProxyType(dict(self.task_projects))
        )


def run_turn(
    turn_input: TurnInput,
    progress: Progress | None,
    dependencies: WorkflowDependencies,
) -> TurnResult:
    check_turn(turn_input, progress)
    if turn_input.action is Action.SAVE:
        return _save_turn(turn_input, progress, dependencies)
    if not isinstance(dependencies, WorkflowDependencies):
        raise ContractError("dependencies must be WorkflowDependencies")
    _check_project(turn_input, dependencies)
    if turn_input.action is Action.RESEARCH:
        return _research_turn(turn_input, progress, dependencies)
    if turn_input.action is Action.PAUSE:
        return _pause(turn_input, progress)
    if turn_input.action is Action.RESUME:
        return _resume(turn_input, progress)
    return _analysis_turn(turn_input, progress, dependencies)


def _analysis_turn(
    turn: TurnInput, progress: Progress | None, dependencies: WorkflowDependencies
) -> TurnResult:
    """``analyze``, ``answer`` or ``revise``: one read, at most one role call."""

    if turn.action is Action.REVISE and progress.candidate is None:
        raise ContractError("there is no candidate to revise")
    if (
        progress is not None
        and progress.stage is Stage.RESEARCHING
        and progress.research_record() is None
    ):
        raise ContractError("research has not run; there is no result to analyze")
    materials, material_changes = _effective_materials(turn, progress)
    versions = tuple(m.input_version for m in materials)
    if progress is None:
        check_transition(None, Stage.ANALYZING)
        analyzing = Progress(
            task_id=turn.task_id,
            project_id=turn.project_id,
            stage=Stage.ANALYZING,
            input_versions=versions,
            materials=materials,
        )
        checks: tuple[ToolResult, ...] = ()
    else:
        check_transition(progress, Stage.ANALYZING)
        answers, choices = _merge_answers(progress, turn.answers)
        analyzing = replace(
            progress,
            stage=Stage.ANALYZING,
            input_versions=versions,
            materials=materials,
            answers=answers,
            choices=choices,
            save_reference=None,
        )
        checks = (ToolResult("check_materials", True, material_changes),)
    now = dependencies.clock()

    try:
        rules = dependencies.tools.read_role_rules(
            research=(
                dependencies.include_research_methods
                or bool(analyzing.research or analyzing.research_records)
            ),
            prd=(
                dependencies.include_prd_template
                or (analyzing.candidate is not None
                    and analyzing.candidate.deliverable is Deliverable.PRD)
            ),
        )
        documents = dependencies.tools.read_project(
            turn.project_id, _context(turn, dependencies, now, N02)
        )
    except ReadFailedError as error:
        return _analysis_blocked(
            analyzing,
            f"读取失败，本轮未调用需求角色：{error}",
            "项目文档、角色规则与适用方法的完整读取",
            *checks,
            ToolResult("read_baseline", False, {"error": str(error)}),
        )
    baseline = Baseline(
        project_id=turn.project_id,
        documents=tuple(d.version for d in documents),
        materials=versions,
    )
    read = ToolResult(
        "read_baseline",
        True,
        {
            "documents": {d.path: d.sha256 for d in documents},
            "role_rules_sha256": rules.sha256,
            "method_sources": {m.path: m.sha256 for m in rules.methods},
        },
    )

    request = _agent_request(
        turn,
        rules,
        documents,
        materials,
        None if progress is None else _progress_view(analyzing, progress.stage),
        None if progress is None else material_changes,
    )
    role_context = _context(turn, dependencies, now, N03)
    try:
        agent_result = dependencies.agent_runner.run(request, role_context)
    except Exception as error:
        message = f"{type(error).__name__}: {error}"
        return _analysis_blocked(
            analyzing,
            f"需求角色调用失败，未形成候选，也未自动重试：{message}",
            "需求角色的本轮结果",
            *checks,
            read,
            ToolResult("requirements_role", False, {"error": message}),
        )
    try:
        result = parse_agent_result(
            agent_result,
            task_id=turn.task_id,
            project_id=turn.project_id,
            materials=materials,
        )
        updated = _progress_for(analyzing, result, baseline, turn, first=progress is None)
    except ContractError as error:
        return _analysis_blocked(
            analyzing,
            f"需求角色的返回不符合结果协议，未形成候选：{error}",
            "符合结果协议的需求角色返回",
            *checks,
            read,
            ToolResult("requirements_role", False, {"error": str(error)}),
        )

    check_transition(analyzing, updated.stage)
    formed: tuple[ToolResult, ...] = ()
    if result.kind is ResultKind.CANDIDATE and progress is not None:
        candidate = updated.candidate
        formed = (
            ToolResult(
                "check_candidate",
                True,
                {
                    "candidate_id": candidate.candidate_id,
                    "revision": candidate.revision,
                    "revises": candidate.revises,
                    "changes": list(candidate.changes),
                    "content_review": "pending_user_review",
                },
            ),
        )
    note = ""
    known = updated.research_record() if result.kind is ResultKind.RESEARCH else None
    if known is not None and known.called:
        note = (
            f"该请求在相同输入下已有调研记录 {known.request_id}（{known.result.outcome.value}）；"
            "再次 research 只返回已有结果，不会重复调用调研函数。"
        )
    return TurnResult(
        stage=updated.stage,
        content=_content(
            result, updated.candidate, _answer_lines(analyzing, turn.answers), note
        ),
        progress=updated,
        tool_results=(*checks, read, *formed),
    )


def _research_turn(
    turn: TurnInput, progress: Progress, dependencies: WorkflowDependencies
) -> TurnResult:
    """Run the pending request at most once; no role call, read or business write."""

    request = progress.research
    if request is None:
        raise ContractError("there is no research request to run")
    _same_materials(turn, progress)
    inputs = progress.research_inputs_sha256
    request_id = research_request_id(request, inputs)
    ran = [r for r in progress.research_records if r.request_id == request_id and r.called]
    if ran:
        return _research_result(progress, ran[-1], dependencies, reused=True)

    used, budget = progress.research_calls, dependencies.research_budget
    called = False
    if dependencies.research is None:
        result = _research_limit("未配置调研工具，本轮未执行调研")
    elif used >= budget:
        result = _research_limit(f"调研预算已用尽（已用 {used}／上限 {budget}），本轮未执行调研")
    else:
        called = True
        try:
            returned = dependencies.research(request)
        except Exception as error:
            result = _research_limit(
                f"调研调用异常：{type(error).__name__}: {error}；未当作证据，也未自动重试",
                ResearchOutcome.FAILED,
            )
        else:
            if (
                isinstance(returned, ResearchResult)
                and returned.outcome is not ResearchOutcome.FAILED
            ):
                result = returned
            else:
                result = _research_limit(
                    f"调研返回不合格（{type(returned).__name__}）；未当作证据，也未自动重试",
                    ResearchOutcome.FAILED,
                )
    record = ResearchRecord(request, inputs, result, called)
    if record not in progress.research_records:
        check_transition(progress, Stage.RESEARCHING)
        progress = replace(
            progress, research_records=(*progress.research_records, record)
        )
    return _research_result(progress, record, dependencies, reused=False)


def _research_limit(
    limitation: str, outcome: ResearchOutcome = ResearchOutcome.UNAVAILABLE
) -> ResearchResult:
    return ResearchResult(outcome, limitations=(limitation,))


def _research_result(
    progress: Progress,
    record: ResearchRecord,
    dependencies: WorkflowDependencies,
    *,
    reused: bool,
) -> TurnResult:
    result = record.result
    headline = {
        ResearchOutcome.EVIDENCE: f"调研得到 {len(result.evidence)} 条证据。",
        ResearchOutcome.INSUFFICIENT: "调研证据不足。",
        ResearchOutcome.UNAVAILABLE: "调研工具不可用，没有获得证据。",
        ResearchOutcome.FAILED: "调研失败，没有获得可用证据。",
    }[result.outcome]
    lines = []
    if reused:
        lines.append(
            f"调研请求 {record.request_id} 在相同输入下已有结果，本轮未再次调用调研函数。"
        )
    lines.append(headline)
    if result.test_material:
        lines.append("（以下为测试材料，不是真实调研结果。）")
    lines += _lines("证据：", tuple(_evidence_line(e) for e in result.evidence))
    lines += _lines("限制：", result.limitations)
    lines.append(
        f"调研预算：已用 {progress.research_calls}／上限 {dependencies.research_budget}。"
    )
    lines.append(
        "结果已返回，下一步分析：发送 analyze 把结果带回需求分析。"
        "本轮未调用需求角色，也未写入业务成果。"
    )
    tool = ToolResult(
        "research",
        result.outcome in (ResearchOutcome.EVIDENCE, ResearchOutcome.INSUFFICIENT),
        {
            "request_id": record.request_id,
            "outcome": result.outcome.value,
            "called": record.called and not reused,
            "reused": reused,
            "evidence": len(result.evidence),
            "calls_used": progress.research_calls,
            "budget": dependencies.research_budget,
            "test_material": result.test_material,
        },
    )
    return TurnResult(
        stage=Stage.RESEARCHING,
        content="\n".join(lines),
        progress=progress,
        tool_results=(tool,),
    )


def _evidence_line(evidence) -> str:
    line = f"{evidence.supports}：{evidence.content}（来源 {evidence.source}，访问于 {evidence.accessed_on}"
    if evidence.limitation:
        line += f"；限制：{evidence.limitation}"
    if evidence.test_material:
        line += "；测试材料"
    return line + "）"


def _unsupported(turn: TurnInput, progress: Progress | None, what: str = ""):
    stage = "start" if progress is None else progress.stage.value
    subject = what or f"action {turn.action.value} at {stage}"
    raise UnsupportedActionError(f"{subject} is not implemented yet")


def _check_project(turn: TurnInput, dependencies: WorkflowDependencies) -> None:
    if turn.project_id not in dependencies.allowed_projects:
        raise AuthorizationError("project is not in the workflow allowlist")
    if dependencies.task_projects.get(turn.task_id) != turn.project_id:
        raise AuthorizationError("task is not bound to this project")


def _context(
    turn: TurnInput,
    dependencies: WorkflowDependencies,
    now: datetime,
    node: str,
    *,
    run_id: str | None = None,
    role: str = ROLE,
    readable: frozenset[str] | None = None,
    writable: frozenset[str] = frozenset(),
    artifact_types: frozenset[str] = frozenset(),
):
    running = WorkflowRun(
        workflow_id=turn.task_id,
        workflow_type=WORKFLOW_TYPE,
        project_id=turn.project_id,
        state=WorkflowState.RUNNING,
        current_node=node,
        created_from_ingress=turn.task_id,
        created_at=now,
        updated_at=now,
    )
    if readable is None:
        readable = _N03_READABLE if node == N03 else _N02_READABLE
    assignment = ServerAssignment(
        principal="runtime",
        assigned_role=role,
        step_id=node,
        attempt=_ATTEMPT,
        readable_paths=readable,
        writable_paths=writable,
        artifact_types=artifact_types,
    )
    context = dependencies.policy.build_execution_context(
        workflow=running,
        run_id=run_id or f"{turn.task_id}-{node}-{_ATTEMPT}",
        ingress_ref=running.created_from_ingress,
        assignment=assignment,
    )
    if (
        context.project_id != turn.project_id
        or context.step_id != node
        or context.capability_grant.assigned_role != role
    ):
        raise AuthorizationError("execution context does not match this step")
    return context


def _result_protocol(
    turn: TurnInput, materials: tuple[SourceMaterial, ...]
) -> dict[str, object]:
    return {
        "schema_version": SCHEMA_VERSION,
        "format": "candidate_body 只含一个 JSON 对象，不加代码块或说明文字",
        "fields": sorted(_RESULT_KEYS),
        "task_id": turn.task_id,
        "project_id": turn.project_id,
        "source_refs": {
            "fields": sorted(_SOURCE_REF_KEYS),
            "allowed": [
                {"source_id": m.source_id, "version": m.version}
                for m in materials
            ],
        },
        "payload": {kind.value: sorted(keys) for kind, keys in _PAYLOAD_KEYS.items()},
        "question_fields": sorted(_QUESTION_KEYS),
        "option_fields": sorted(_OPTION_KEYS),
        "artifact_text": "只有 candidate 的 payload.body 是成果正文",
    }


def _agent_request(
    turn: TurnInput,
    rules: RoleRules,
    documents: tuple[DocumentRead, ...],
    materials: tuple[SourceMaterial, ...],
    progress: Mapping[str, object] | None,
    material_changes: Mapping[str, object] | None,
) -> AgentRequest:
    """Business inputs only; no grant, save reference or callable reaches the role."""

    def dump(value: object) -> str:
        return json.dumps(value, ensure_ascii=False, indent=2)

    return AgentRequest(
        instruction=INSTRUCTION,
        inputs={
            "task_id": turn.task_id,
            "project_id": turn.project_id,
            "action": turn.action.value,
            "utterance": turn.utterance,
            "role_rules_path": rules.path,
            "role_rules_sha256": rules.sha256,
            "role_rules": rules.body,
            "method_sources": dump([
                {"key": m.key, "path": m.path, "body": m.body, "sha256": m.sha256}
                for m in rules.methods
            ]),
            "materials": dump(
                [
                    {
                        "source_id": m.source_id,
                        "location": m.location,
                        "version": m.version,
                        "category": m.category.value,
                        "body_sha256": m.body_sha256,
                        "body": m.body,
                    }
                    for m in materials
                ]
            ),
            "project_documents": dump(
                [
                    {"path": d.path, "sha256": d.sha256, "content": d.content}
                    for d in documents
                ]
            ),
            "progress": dump(progress),
            "material_changes": dump(material_changes),
            "turn_answers": dump([_answer_view(a) for a in turn.answers]),
            "result_protocol": dump(_result_protocol(turn, materials)),
        },
    )


def _answer_view(answer: Answer) -> dict[str, object]:
    return {
        "question_id": answer.question_id,
        "text": answer.text,
        "option": answer.option,
        "replaces": answer.replaces,
    }


def _progress_view(progress: Progress, previous_stage: Stage) -> dict[str, object]:
    """The business progress a continuing role call needs, without save authority."""

    chosen = {c.question_id for c in progress.choices}
    answered = {a.question_id for a in progress.answers}
    candidate = progress.candidate
    current_inputs = progress.research_inputs_sha256
    written = [
        {"path": r.data["path"], "candidate_id": r.data["candidate_id"]}
        for r in (*progress.prior_save_results, *progress.save_results)
        if r.ok and "candidate_id" in r.data and "path" in r.data
    ]
    return {
        "previous_stage": previous_stage.value,
        "understanding": progress.understanding,
        "questions": [
            {
                "question_id": q.question_id,
                "text": q.text,
                "reason": q.reason,
                "options": [{"label": o.label, "impact": o.impact} for o in q.options],
                "status": (
                    "user_chose"
                    if q.question_id in chosen
                    else "answered_needs_clarification"
                    if q.question_id in answered
                    else "open"
                ),
            }
            for q in progress.questions
        ],
        "answers": [_answer_view(a) for a in progress.answers],
        "user_choices": [
            {"subject": c.subject, "value": c.value, "question_id": c.question_id}
            for c in progress.choices
        ],
        "evidence": [_evidence_view(e) for e in progress.evidence],
        "open_items": list(progress.open_items),
        "research_request": None
        if progress.research is None
        else {
            "request_id": research_request_id(progress.research, current_inputs),
            **_request_view(progress.research),
        },
        "research_records": [
            {
                "request_id": r.request_id,
                "request": _request_view(r.request),
                "applies_to_current_inputs": r.inputs_sha256 == current_inputs,
                "note": "外部调研结果，不是项目材料，也不是用户选择"
                if r.inputs_sha256 == current_inputs
                else "材料、回答或选择已变化：只作历史参考，不能当作当前事实",
                "called": r.called,
                "outcome": r.result.outcome.value,
                "test_material": r.result.test_material,
                "evidence": [_evidence_view(e) for e in r.result.evidence],
                "limitations": list(r.result.limitations),
            }
            for r in progress.research_records
        ],
        "blocked": None if progress.blocked is None else _blocked_view(progress.blocked),
        "candidate": None
        if candidate is None
        else {
            "candidate_id": candidate.candidate_id,
            "revision": candidate.revision,
            "deliverable": candidate.deliverable.value,
            "body": candidate.body,
            "body_sha256": candidate.body_sha256,
            "source_refs": [
                {"source_id": r.source_id, "version": r.version}
                for r in candidate.source_refs
            ],
            "changes": list(candidate.changes),
            "open_items": list(candidate.open_items),
            "research_refs": list(candidate.research_refs),
        },
        "written_drafts": written,
    }


def _request_view(request: ResearchRequest) -> dict[str, object]:
    return {
        "decision": request.decision,
        "questions": list(request.questions),
        "scope": request.scope,
        "known_basis": list(request.known_basis),
        "stop_condition": request.stop_condition,
    }


def _evidence_view(evidence) -> dict[str, object]:
    return {
        "source": evidence.source,
        "accessed_on": evidence.accessed_on,
        "supports": evidence.supports,
        "content": evidence.content,
        "limitation": evidence.limitation,
        "test_material": evidence.test_material,
    }


def _blocked_view(report: BlockedReport) -> dict[str, object]:
    return {
        "missing": list(report.missing),
        "completed": list(report.completed),
        "impact": report.impact,
        "resume_condition": report.resume_condition,
    }


def _effective_materials(
    turn: TurnInput, progress: Progress | None
) -> tuple[tuple[SourceMaterial, ...], dict[str, object]]:
    """Inherit the kept material text, or check a non-empty set as the full new one."""

    if progress is None:
        return turn.materials, {}
    if not turn.materials and progress.input_versions and not progress.materials:
        raise ContractError(
            "progress keeps no material text to continue from; provide the materials again"
        )
    materials = turn.materials or progress.materials
    old = {v.source_id: v for v in progress.input_versions}
    new = {m.source_id: m.input_version for m in materials}
    changed = [
        {
            "source_id": source_id,
            "version": [old[source_id].version, version.version],
            "body_changed": old[source_id].body_sha256 != version.body_sha256,
        }
        for source_id, version in new.items()
        if source_id in old and old[source_id] != version
    ]
    return materials, {
        "inherited": not turn.materials,
        "added": [s for s in new if s not in old],
        "removed": [s for s in old if s not in new],
        "changed": changed,
    }


def _merge_answers(
    progress: Progress, answers: tuple[Answer, ...]
) -> tuple[tuple[Answer, ...], tuple[Choice, ...]]:
    """Update answered questions in place; only an explicit option becomes a choice."""

    questions = {q.question_id: q for q in progress.questions}
    merged = list(progress.answers)
    index = {a.question_id: i for i, a in enumerate(merged)}
    choices = list(progress.choices)
    for answer in answers:
        position = index.get(answer.question_id)
        if position is None:
            index[answer.question_id] = len(merged)
            merged.append(answer)
        else:
            old = merged[position]
            if (old.text, old.option) == (answer.text, answer.option):
                continue
            merged[position] = Answer(
                answer.question_id, answer.text, answer.option, replaces=old.text
            )
        choices = [c for c in choices if c.question_id != answer.question_id]
        if answer.option is not None:
            subject = " ".join(questions[answer.question_id].text.split())
            choices.append(Choice(subject, answer.option, answer.question_id))
    return tuple(merged), tuple(choices)


def _merge_questions(
    progress: Progress, asked: tuple[Question, ...]
) -> tuple[Question, ...]:
    """Keep earlier questions; an id never silently changes its meaning."""

    known = {q.question_id: q for q in progress.questions}
    chosen = {c.question_id for c in progress.choices}
    merged = list(progress.questions)
    for question in asked:
        earlier = known.get(question.question_id)
        if earlier is None:
            merged.append(question)
        elif earlier != question:
            raise ContractError(
                f"question_id {question.question_id} is reused with a different meaning; "
                "a changed question needs a new id"
            )
        elif question.question_id in chosen:
            raise ContractError(
                f"question {question.question_id} already has the user's explicit choice"
            )
    return tuple(merged)


def _candidate_id(
    task_id: str, body_sha256: str, baseline: Baseline, lineage: tuple[str, ...] = ()
) -> str:
    parts = [task_id, body_sha256]
    parts += [f"{d.path}={d.sha256}" for d in baseline.documents]
    parts += [f"{m.source_id}={m.version}={m.body_sha256}" for m in baseline.materials]
    parts += list(lineage)
    return "cand-" + digest("\0".join(parts))[:16]


def _progress_for(
    analyzing: Progress,
    result: RoleResult,
    baseline: Baseline,
    turn: TurnInput,
    *,
    first: bool,
) -> Progress:
    fields: dict[str, object] = {
        "stage": result.stage,
        "understanding": result.summary,
        "open_items": result.open_items,
        "research": None,
        "blocked": None,
    }
    if result.kind is ResultKind.QUESTIONS:
        fields["questions"] = _merge_questions(analyzing, result.payload)
    elif result.kind is ResultKind.RESEARCH:
        fields["research"] = result.payload
    elif result.kind is ResultKind.BLOCKED:
        fields["blocked"] = result.payload
    else:
        previous = analyzing.candidate
        if previous is not None and not result.changes:
            raise ContractError("a revised candidate must state its changes")
        revision = 1 if previous is None else previous.revision + 1
        revises = None if previous is None else previous.candidate_id
        lineage: tuple[str, ...] = ()
        if not first:
            dialogue = {
                "action": turn.action.value,
                "utterance": turn.utterance,
                "answers": [_answer_view(a) for a in analyzing.answers],
                "choices": [[c.subject, c.value, c.question_id] for c in analyzing.choices],
            }
            lineage = (
                f"revision={revision}",
                f"revises={revises or ''}",
                "dialogue=" + digest(json.dumps(dialogue, ensure_ascii=False, sort_keys=True)),
            )
        research_refs = tuple(dict.fromkeys(r.request_id for r in analyzing.research_records))
        if research_refs:
            research = [
                [r.request_id, r.inputs_sha256, r.called, repr(r.result)]
                for r in analyzing.research_records
            ]
            lineage += ("research=" + digest(json.dumps(research, ensure_ascii=False)),)
        candidate_id = _candidate_id(
            analyzing.task_id, digest(result.payload.body), baseline, lineage
        )
        fields["candidate"] = Candidate.from_role_result(
            result,
            candidate_id,
            baseline,
            revision=revision,
            revises=revises,
            research_refs=research_refs,
        )
        fields["save_results"] = ()
        fields["prior_save_results"] = (
            *analyzing.prior_save_results,
            *analyzing.save_results,
        )
    return replace(analyzing, **fields)


def _analysis_blocked(
    analyzing: Progress, content: str, missing: str, *tool_results: ToolResult
) -> TurnResult:
    """Keep the valid progress and this turn's input; nothing is retried."""

    check_transition(analyzing, Stage.BLOCKED)
    progress = replace(
        analyzing,
        stage=Stage.BLOCKED,
        blocked=BlockedReport(
            missing=(missing,),
            completed=("已保留已有进度与本轮输入（材料、回答和选择）",),
            impact=content,
            resume_condition="核对原因后重新提交本轮；本轮未自动重试",
        ),
    )
    return TurnResult(
        stage=Stage.BLOCKED,
        content=content,
        progress=progress,
        tool_results=tool_results,
    )


def _same_materials(turn: TurnInput, progress: Progress) -> None:
    if turn.materials and {m.input_version for m in turn.materials} != set(
        progress.input_versions
    ):
        raise ContractError(
            f"materials changed; {turn.action.value} does not refresh the candidate "
            "baseline or carry over its authorization. Resume first, then analyze "
            "or revise with the new materials"
        )


def _pause(turn: TurnInput, progress: Progress) -> TurnResult:
    """Record where to resume and end the turn; no role, read or tool call."""

    if progress.stage in (Stage.ANALYZING, Stage.WAITING_SAVE):
        raise ContractError(f"stage {progress.stage.value} only exists inside a turn")
    _same_materials(turn, progress)
    check_transition(progress, Stage.ENDED)
    paused = replace(
        progress,
        stage=Stage.ENDED,
        resume_stage=progress.stage,
        save_reference=progress.save_reference if progress.stage is Stage.SAVED else None,
    )
    content = "\n".join(
        [f"已暂停，进度保留在 {progress.stage.value} 阶段；发送 resume 继续。", *_status_lines(paused)]
    )
    return TurnResult(stage=Stage.ENDED, content=content, progress=paused)


def _resume(turn: TurnInput, progress: Progress) -> TurnResult:
    """Restore the recorded stage only; no role call, save or new authorization."""

    _same_materials(turn, progress)
    target = progress.resume_stage
    check_transition(progress, target)
    resumed = replace(
        progress,
        stage=target,
        resume_stage=None,
        save_reference=progress.save_reference if target is Stage.SAVED else None,
    )
    content = "\n".join(
        [
            f"已恢复到 {target.value} 阶段。本轮未调用需求角色、未保存，也未重新授权保存。",
            "项目文档是否变化将在下一次分析读取或保存前的基线比较中核对。",
            *_status_lines(resumed),
        ]
    )
    return TurnResult(stage=target, content=content, progress=resumed)


def _status_lines(progress: Progress) -> list[str]:
    answered = {a.question_id for a in progress.answers}
    lines = [progress.understanding] if progress.understanding else []
    lines += _lines(
        "未回答的问题：",
        tuple(
            f"{q.question_id}：{q.text}"
            for q in progress.questions
            if q.question_id not in answered
        ),
    )
    lines += _lines(
        "用户选择：", tuple(f"{c.subject} → {c.value}" for c in progress.choices)
    )
    if progress.candidate is not None:
        candidate = progress.candidate
        lines.append(
            f"当前候选 {candidate.candidate_id}（{candidate.deliverable.value}，"
            f"第 {candidate.revision} 版）。"
        )
    if progress.research is not None:
        lines.append(f"待调研：{progress.research.decision}")
    if progress.blocked is not None:
        lines.append(f"继续条件：{progress.blocked.resume_condition}")
    lines += _lines("待决项：", progress.open_items)
    return lines


def _answer_lines(analyzing: Progress, answers: tuple[Answer, ...]) -> list[str]:
    recorded = {a.question_id: a for a in analyzing.answers}
    lines = []
    for answer in answers:
        kept = recorded[answer.question_id]
        line = f"- {kept.question_id}：{kept.text}"
        line += f"（选择：{kept.option}）" if kept.option else "（未选择选项，保留待澄清）"
        if kept.replaces is not None:
            line += f"；替换原回答：{kept.replaces}"
        lines.append(line)
    return ["已记录回答：", *lines, ""] if lines else []


def _save_turn(
    turn: TurnInput, progress: Progress, dependencies: WorkflowDependencies
) -> TurnResult:
    if progress.stage not in (Stage.CANDIDATE_REVIEW, Stage.WAITING_SAVE):
        _unsupported(turn, progress)
    candidate = progress.candidate
    if turn.register_index:
        _unsupported(turn, progress, "index registration")
    if not isinstance(dependencies, WorkflowDependencies):
        raise ContractError("dependencies must be WorkflowDependencies")
    _check_project(turn, dependencies)
    prd = candidate.deliverable is Deliverable.PRD
    if prd and dependencies.domain_tools is None:
        raise ContractError("a PRD save requires the trusted domain tools")
    if turn.save.target != DELIVERABLE_TARGETS[candidate.deliverable]:
        raise ContractError("save target does not match the candidate deliverable")
    baseline = candidate.baseline
    if baseline is None:
        raise ContractError("the candidate has no baseline and cannot be saved")
    if set(progress.input_versions) != set(baseline.materials):
        raise ContractError("progress inputs differ from the candidate baseline")
    if turn.materials and {m.input_version for m in turn.materials} != set(
        baseline.materials
    ):
        raise ContractError(
            "materials changed after the candidate was formed; "
            "its save reference no longer applies"
        )

    if progress.stage is Stage.CANDIDATE_REVIEW:
        check_transition(progress, Stage.WAITING_SAVE)
    waiting = replace(progress, stage=Stage.WAITING_SAVE, save_reference=turn.save)
    save = (_PrdSave if prd else _RequirementsSave)(turn, dependencies, waiting)
    return save.run()


class _DraftSave:
    """One authorized save of the current candidate against its baseline.

    Subclasses supply the target, the tool call, the kernel metadata and any
    structure check; authorization, baseline comparison, effect observation and
    the partial-success reporting are shared.
    """

    deliverable: Deliverable
    label: str
    save_tool: str
    reread_tool: str
    verified_text: str

    def __init__(
        self, turn: TurnInput, dependencies: WorkflowDependencies, waiting: Progress
    ) -> None:
        self.turn = turn
        self.dependencies = dependencies
        self.waiting = waiting
        self.candidate = waiting.candidate
        self.baseline = waiting.candidate.baseline
        self.path = DELIVERABLE_TARGETS[self.deliverable]
        self.previous = self.baseline.document(self.path).sha256
        self.history = self.history_path(self.previous)
        self.now = dependencies.clock()
        self.run_prefix = (
            f"{turn.task_id}-{self.candidate.candidate_id}-{self.deliverable.value}"
        )
        self.spaced = f" {self.label} " if self.label.isascii() else self.label
        self.subject = self.spaced.lstrip()

    def history_path(self, previous: str) -> str | None:
        raise NotImplementedError

    def prepare(self) -> Callable[[], Mapping[str, object]]:
        """Build the command and N04 context; the returned call performs the save."""

        raise NotImplementedError

    def expected_metadata(self) -> dict[str, str]:
        raise NotImplementedError

    def checks(self, context, context_error, expected: str) -> tuple[ToolResult, ...]:
        """Structure checks after the re-read; none unless the deliverable has one."""

        return ()

    def save_context(self, readable: frozenset[str]):
        writable = {self.path} | ({self.history} if self.history else set())
        context = self.context(
            N04,
            role=DETERMINISTIC_ROLE,
            readable=readable,
            writable=frozenset(writable),
            artifact_types=frozenset({self.deliverable.value}),
        )
        if SAVE_DRAFT not in context.capability_grant.allowed_tools:
            raise AuthorizationError("tool is not authorized: save_draft")
        return context

    def context(self, node: str, **scope):
        return _context(
            self.turn,
            self.dependencies,
            self.now,
            node,
            run_id=f"{self.run_prefix}-{node}-{_ATTEMPT}",
            **scope,
        )

    def run(self) -> TurnResult:
        try:
            read_context = self.context(N02)
            current = self.read(read_context)
        except (ReadFailedError, AuthorizationError) as error:
            return self.not_saved(
                f"保存前读取失败：{error}",
                ToolResult("check_baseline", False, {"error": str(error)}),
            )
        changed = _changed(self.baseline, current)
        check = ToolResult(
            "check_baseline",
            not changed,
            {
                "changed": list(changed),
                "baseline": {p: self.baseline.document(p).sha256 for p in changed},
                "current": {p: current[p].sha256 for p in changed},
            },
        )
        if changed:
            if changed == (self.path,) and not self.effect_problems(
                current, read_context
            ):
                saved = self.save_result(current[self.path].sha256, changed=False)
                return self.verify(check, saved, already_applied=True)
            return self.not_saved(
                "审阅基线之后以下文件已变化，未覆盖：" + "、".join(changed),
                check,
            )

        try:
            save = self.prepare()
        except _SAVE_ERRORS as error:
            return self.not_saved(
                f"保存授权或命令不成立：{error}",
                check,
                ToolResult(self.save_tool, False, {"error": str(error), "written": False}),
            )
        try:
            saved = dict(save())
        except _SAVE_ERRORS as error:
            return self.not_saved(
                f"保存工具在写入前拒绝：{error}",
                check,
                ToolResult(self.save_tool, False, {"error": str(error), "written": False}),
            )
        except Exception as error:
            return self.observe(check, f"保存调用异常：{type(error).__name__}: {error}")
        try:
            digest_value = _require_save_result(saved, self.save_tool, self.path)
        except ValidationError as error:
            return self.observe(check, f"保存返回不合格：{error}")
        return self.verify(
            check, self.save_result(digest_value, changed=saved["changed"])
        )

    def read(self, context) -> dict[str, DocumentRead]:
        documents = self.dependencies.tools.read_project(self.turn.project_id, context)
        return {d.path: d for d in documents}

    def effect_problems(self, documents: Mapping[str, DocumentRead], context) -> list[str]:
        """How the project differs from this candidate saved on its baseline."""

        problems = [
            f"{path} 与审阅基线不一致"
            for path in _changed(self.baseline, documents)
            if path != self.path
        ]
        target = documents[self.path]
        problems += _draft_problems(
            self.path, self.expected_metadata(), self.candidate.body, target.content
        )
        if self.history and target.sha256 != self.previous:
            try:
                archived = self.dependencies.tools.read_document(
                    self.turn.project_id, self.history, context
                )
            except (ReadFailedError, AuthorizationError) as error:
                problems.append(f"{self.history} 读取失败：{error}")
            else:
                if archived.sha256 != self.previous:
                    problems.append(
                        f"{self.history} 未保留审阅基线中的{self.spaced.rstrip()}"
                    )
        return problems

    def save_result(self, digest_value: str, *, changed: bool) -> ToolResult:
        return ToolResult(
            self.save_tool,
            True,
            {
                "path": self.path,
                "sha256": digest_value,
                "status": "Draft",
                "approval_verified": False,
                "changed": changed,
                "history": self.history if changed else None,
                "candidate_id": self.candidate.candidate_id,
            },
        )

    def observe(self, check: ToolResult, error: str) -> TurnResult:
        """Find the actual effect of a save whose outcome is unknown; never retry."""

        try:
            context = self.context(N05)
            current = self.read(context)
        except (ReadFailedError, AuthorizationError) as read_error:
            return self.unknown(check, f"{error}；复读失败：{read_error}")
        if not _changed(self.baseline, current):
            return self.not_saved(
                f"{error}；复读确认{self.spaced}未写入",
                check,
                ToolResult(self.save_tool, False, {"error": error, "written": False}),
            )
        if not self.effect_problems(current, context):
            return self.verify(
                check,
                self.save_result(current[self.path].sha256, changed=True),
                note=f"{error}；复读确认本候选已写入。",
            )
        return self.unknown(check, f"{error}；复读结果与审阅基线和本候选都不一致")

    def verify(
        self,
        check: ToolResult,
        saved: ToolResult,
        *,
        already_applied: bool = False,
        note: str = "",
    ) -> TurnResult:
        expected = saved.data["sha256"]
        context_error = None
        try:
            context = self.context(N05)
        except AuthorizationError as error:
            context, context_error = None, error
        try:
            if context is None:
                raise context_error
            current = self.read(context)
        except (ReadFailedError, AuthorizationError) as error:
            reread = ToolResult(self.reread_tool, False, {"error": str(error)})
        else:
            problems = self.effect_problems(current, context)
            if current[self.path].sha256 != expected:
                problems.insert(0, f"{self.path} 摘要与保存返回不一致")
            reread = ToolResult(
                self.reread_tool,
                not problems,
                {"sha256": current[self.path].sha256, "problems": problems},
            )
        checks = self.checks(context, context_error, expected)

        results = (saved, reread, *checks)
        changed = saved.data["changed"]
        if already_applied:
            effect = "核对到本候选已按审阅基线保存，本轮未重写。"
        elif changed:
            effect = f"本轮写入新版本，摘要 {expected[:12]}。"
            if self.history:
                effect += f"原{self.spaced}保留在 {self.history}。"
        else:
            effect = "文件已是该内容，未重写，也未新增历史。"
        if all(r.ok for r in results[1:]):
            check_transition(self.waiting, Stage.SAVED)
            progress = replace(self.waiting, stage=Stage.SAVED, save_results=results)
            content = "\n".join(
                [
                    f"{self.label} Draft 已保存到 {self.path}"
                    f"（候选 {self.candidate.candidate_id}）。",
                    note + effect,
                    self.verified_text,
                    "Draft 不等于正式确认；未登记项目索引，也未启动方案。",
                    *_lines("待决项：", self.candidate.open_items),
                ]
            ).strip()
            return TurnResult(
                stage=Stage.SAVED,
                content=content,
                progress=progress,
                tool_results=(check, *results),
            )

        failed = [r.tool for r in results[1:] if not r.ok]
        written = (
            f"{self.subject}文件已写入"
            if changed or already_applied or note
            else f"{self.subject}文件已是该内容"
        )
        content = "\n".join(
            [
                f"{written}（{self.path}），但写后检查未通过："
                + "、".join(failed)
                + "。本轮不算完整成功，未自动重试。",
                note + effect,
                *_lines("复读问题：", tuple(reread.data.get("problems", ()))),
                *_lines(
                    "结构问题：",
                    tuple(
                        json.dumps(i, ensure_ascii=False)
                        for r in checks
                        for i in r.data.get("issues") or ()
                    ),
                ),
            ]
        ).strip()
        return self.blocked(content, check, *results)

    def not_saved(self, reason: str, *tool_results: ToolResult) -> TurnResult:
        return self.blocked(
            f"{self.subject}未保存：{reason}。文件保持原状，未调用需求角色，也未重新生成候选。",
            *tool_results,
        )

    def unknown(self, check: ToolResult, reason: str) -> TurnResult:
        return self.blocked(
            f"{self.subject}保存结果无法确认：{reason}。未重试保存，请先核对 {self.path}。",
            check,
            ToolResult(self.save_tool, False, {"error": reason, "written": None}),
        )

    def blocked(self, content: str, *tool_results: ToolResult) -> TurnResult:
        check_transition(self.waiting, Stage.BLOCKED)
        progress = replace(
            self.waiting,
            stage=Stage.BLOCKED,
            save_reference=None,
            save_results=tuple(r for r in tool_results if r.tool != "check_baseline"),
        )
        return TurnResult(
            stage=Stage.BLOCKED,
            content=content,
            progress=progress,
            tool_results=tool_results,
        )


class _PrdSave(_DraftSave):
    """PRD Draft through the injected adapter's ``save_prd_draft`` and ``inspect_draft``."""

    deliverable = Deliverable.PRD
    label = "PRD"
    save_tool = "save_prd_draft"
    reread_tool = "reread_prd"
    verified_text = "写后复读与 PRD 结构检查通过。"

    def history_path(self, previous: str) -> str | None:
        return None if previous == MISSING else f"docs/prd-history/{previous}.md"

    def prepare(self) -> Callable[[], Mapping[str, object]]:
        command = SavePrdDraftCommand(
            body=self.candidate.body,
            expected_prd_sha256=self.previous,
            expected_requirements_sha256=self.baseline.document(
                _REQUIREMENTS_PATH
            ).sha256,
        )
        context = self.save_context(_N04_READABLE)
        return lambda: self.dependencies.domain_tools.save_prd_draft(command, context)

    def expected_metadata(self) -> dict[str, str]:
        return {
            "artifact_kind": Deliverable.PRD.value,
            "status": "Draft",
            "approval_verified": "false",
            "source_requirements_path": _REQUIREMENTS_PATH,
            "source_requirements_sha256": self.baseline.document(
                _REQUIREMENTS_PATH
            ).sha256,
        }

    def checks(self, context, context_error, expected: str) -> tuple[ToolResult, ...]:
        try:
            if context is None:
                raise context_error
            report = dict(
                self.dependencies.domain_tools.inspect_draft(
                    self.turn.project_id, Deliverable.PRD.value, context
                )
            )
        except Exception as error:
            return (
                ToolResult(
                    "inspect_prd", False, {"error": f"{type(error).__name__}: {error}"}
                ),
            )
        issues = report.get("issues")
        status = str(report.get("status") or "")
        return (
            ToolResult(
                "inspect_prd",
                report.get("sha256") == expected
                and status == "ready_for_review"
                and isinstance(issues, list)
                and not issues,
                {
                    "sha256": report.get("sha256"),
                    "status": status,
                    "issues": list(issues) if isinstance(issues, list) else issues,
                },
            ),
        )


class _RequirementsSave(_DraftSave):
    """Lightweight Draft through ``RequirementsTools.save_requirements_draft``.

    The kernel's atomic version check covers only ``docs/requirements.md``;
    other baseline documents are compared once before the save.
    """

    deliverable = Deliverable.REQUIREMENTS
    label = "轻量需求"
    save_tool = "save_requirements_draft"
    reread_tool = "reread_requirements"
    verified_text = "写后复读通过；轻量需求不做 PRD 结构检查。"

    def history_path(self, previous: str) -> str | None:
        return requirements_history_path(previous)

    def prepare(self) -> Callable[[], Mapping[str, object]]:
        extra = {self.history} if self.history else set()
        context = self.save_context(REQUIREMENTS_SAVE_READABLE | extra)
        project_id, body, expected = self.turn.project_id, self.candidate.body, self.previous
        return lambda: self.dependencies.tools.save_requirements_draft(
            project_id, body, expected, context
        )

    def expected_metadata(self) -> dict[str, str]:
        return {"status": "Draft", "approval_verified": "false"}


def _changed(
    baseline: Baseline, documents: Mapping[str, DocumentRead]
) -> tuple[str, ...]:
    return tuple(
        d.path for d in baseline.documents if documents[d.path].sha256 != d.sha256
    )


def _draft_problems(
    path: str, expected: Mapping[str, str], body: str, content: str | None
) -> list[str]:
    """Split a saved Draft into kernel metadata and body and compare both."""

    if content is None:
        return [f"{path} 不存在"]
    end = content.find("\n---\n\n", 3)
    if not content.startswith("---\n") or end < 0:
        return [f"{path} 缺少工具维护的元数据"]
    lines = content[4:end].split("\n")
    metadata = dict(line.split(": ", 1) for line in lines if ": " in line)
    problems = []
    if len(metadata) != len(lines) or metadata != expected:
        problems.append(f"{path} 元数据与候选基线不符")
    if content[end + len("\n---\n\n"):] != body.strip() + "\n":
        problems.append(f"{path} 正文与候选不一致")
    return problems


def _require_save_result(saved: Mapping[str, object], tool: str, path: str) -> str:
    """Both kernel result shapes: ``changed=False`` omits ``approval_verified``."""

    digest_value = saved.get("sha256")
    if not isinstance(digest_value, str) or not _SHA256_RE.fullmatch(digest_value):
        raise ValidationError(f"{tool} must return sha256")
    if saved.get("status") != "Draft" or saved.get("approval_verified", False):
        raise ValidationError(f"{tool} must return an unapproved Draft")
    if not isinstance(saved.get("changed"), bool):
        raise ValidationError(f"{tool} must report whether it changed the file")
    if not str(saved.get("path") or "").replace("\\", "/").endswith("/" + path):
        raise ValidationError(f"{tool} returned another path")
    return digest_value


def _lines(title: str, items: tuple[str, ...]) -> list[str]:
    return [title, *(f"- {item}" for item in items)] if items else []


def _content(
    result: RoleResult,
    candidate: Candidate | None,
    recorded: tuple[str, ...] | list[str] = (),
    research_note: str = "",
) -> str:
    parts = [*recorded, result.summary, ""]
    payload = result.payload
    if result.kind is ResultKind.QUESTIONS:
        parts.append("需要你确认：")
        for index, question in enumerate(payload, 1):
            parts.append(f"{index}. {question.text}")
            parts.append(f"   原因：{question.reason}")
            parts += [f"   - {o.label}：{o.impact}" for o in question.options]
    elif result.kind is ResultKind.RESEARCH:
        parts.append(f"需要调研以支持：{payload.decision}")
        parts += [f"- {q}" for q in payload.questions]
        parts.append(f"范围：{payload.scope}")
        parts.append(f"停止条件：{payload.stop_condition}")
        parts.append(research_note or "调研尚未执行；发送 research 执行一次。")
    elif result.kind is ResultKind.CANDIDATE:
        parts.append(
            f"候选 {candidate.candidate_id}（{candidate.deliverable.value}）待审阅，"
            "尚未保存。"
        )
        if candidate.revises is not None:
            parts.append(
                f"这是第 {candidate.revision} 版，修订自 {candidate.revises}；"
                "旧候选的保存授权不适用于本版，保存需要指向本版的新授权。"
                "流程只核对来源、基线与变更说明，内容是否保留未受影响的要求请审阅确认。"
            )
            parts += _lines("变更：", candidate.changes)
        if candidate.research_refs:
            parts.append(
                "形成本候选时提供给角色的调研记录：" + "、".join(candidate.research_refs)
                + "；调研只作依据，不代表用户选择。"
            )
        parts += ["", candidate.body]
    else:
        parts += _lines("缺少：", payload.missing)
        parts += _lines("已完成：", payload.completed)
        parts.append(f"影响：{payload.impact}")
        parts.append(f"继续条件：{payload.resume_condition}")
    parts += _lines("假设：", result.assumptions)
    parts += _lines("待决项：", result.open_items)
    return "\n".join(parts).strip()
