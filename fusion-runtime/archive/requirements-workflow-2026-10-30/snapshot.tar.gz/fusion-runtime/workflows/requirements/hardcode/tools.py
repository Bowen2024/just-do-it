"""Trusted local tool connections for the requirements workflow.

Project and lightweight-save kernels come from this directory's ``file_tools``
package. The main role document is located beside this package's MCP entry;
``helper_root`` locates A/R sources and templates, while ``foundation`` locates
the host's project configuration. Access checks use the
public ``ExecutionContext`` / ``CapabilityGrant`` objects and remain in
``_authorize_read`` / ``_authorize_write``.

Reads and the lightweight ``save_requirements_draft`` connection live here. The
save calls the existing ``requirements.save_draft`` kernel, which keeps its own
locks, version check, history and Draft metadata; its errors are mapped the way
``DevelopHelperDomainTools._call_kernel`` maps them. The PRD save and
inspection go through the public ``DevelopHelperDomainTools`` methods the
caller injects.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import re

from fusion_runtime.domain.errors import (
    AuthorizationError,
    ConflictError,
    ValidationError,
)
from fusion_runtime.domain.models import (
    ExecutionContext,
    validate_project_relative_path,
)
from fusion_runtime.domain.policy import (
    DETERMINISTIC_ROLE,
    INSPECT_ARTIFACT,
    INSPECT_PROJECT,
    SAVE_DRAFT,
)

from .contracts import (
    BASELINE_DOCUMENTS,
    DELIVERABLE_TARGETS,
    MISSING,
    Deliverable,
    DocumentVersion,
    digest,
)
from ..file_tools import project_init, requirements

ROLE_RULES_PATH = str(Path(__file__).resolve().parents[1] / "requirements.md")
_PRODUCT_METHODS = "harness-core/skills/sdd-product-design/"
_METHOD_PATHS = {
    "A": _PRODUCT_METHODS + "phase-A.md",
    "R": _PRODUCT_METHODS + "phase-R.md",
    "research_template": _PRODUCT_METHODS + "references/research-template.md",
}
REQUIREMENTS_PATH = DELIVERABLE_TARGETS[Deliverable.REQUIREMENTS]
REQUIREMENTS_HISTORY = "docs/requirements-history"
SAVE_NODE = "N04"
_RULES_LIMIT = 128 * 1024
_SAVE_TOOLS = frozenset({INSPECT_PROJECT, INSPECT_ARTIFACT, SAVE_DRAFT})
REQUIREMENTS_SAVE_READABLE = frozenset({"project.json", "README.md", REQUIREMENTS_PATH})
_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")


class ReadFailedError(Exception):
    """A required read could not complete; distinct from a missing document."""


@dataclass(frozen=True, slots=True)
class DocumentRead:
    """Text and digest from one kernel read; ``content`` is None when missing."""

    path: str
    sha256: str
    content: str | None

    @property
    def version(self) -> DocumentVersion:
        return DocumentVersion(self.path, self.sha256)


@dataclass(frozen=True, slots=True)
class MethodSource:
    key: str
    path: str
    body: str
    sha256: str


@dataclass(frozen=True, slots=True)
class RoleRules:
    path: str
    body: str
    sha256: str
    methods: tuple[MethodSource, ...] = ()


def requirements_history_path(previous_sha256: str) -> str | None:
    """Archive path the kernel uses for the replaced requirements version."""

    if previous_sha256 == MISSING:
        return None
    return f"{REQUIREMENTS_HISTORY}/{previous_sha256}.md"


class RequirementsTools:
    def __init__(self, *, foundation: Path, helper_root: Path) -> None:
        self._foundation = Path(foundation).resolve(strict=True)
        self._helper_root = Path(helper_root).resolve(strict=True)
        self._project_init = project_init
        self._requirements = requirements

    def read_role_rules(self, *, research: bool = False, prd: bool = False) -> RoleRules:
        """Load the shared rule and selected methods; never execute upstream code.

        These flags are chosen by the calling adapter, not parsed from material.
        The existing foundation checker validates the explicit symlink and lock;
        document reads reuse the safe, bounded UTF-8 reader.
        """

        if type(research) is not bool or type(prd) is not bool:
            raise ReadFailedError("method selection must use boolean flags")
        path = Path(ROLE_RULES_PATH)
        try:
            if path.is_symlink() or not path.is_file():
                raise ValueError("role rules are not a regular file")
            with path.open("rb") as stream:
                raw = stream.read(_RULES_LIMIT + 1)
            if len(raw) > _RULES_LIMIT:
                raise ValueError("role rules exceed the read limit")
            body = raw.decode("utf-8")
        except (OSError, ValueError) as error:
            raise ReadFailedError(f"{ROLE_RULES_PATH}: {error}") from None
        if not body.strip():
            raise ReadFailedError(f"{ROLE_RULES_PATH}: role rules are empty")
        try:
            self._project_init.check(self._helper_root)
            upstream_link = self._helper_root / "upstream/develop-helper"
            upstream = upstream_link.resolve(strict=True)
            keys = ("A", "R", "research_template") if research else ("A",)
            methods = []
            for key in keys:
                relative = _METHOD_PATHS[key]
                document = self._read_document(upstream, relative)
                if not document.content or not document.content.strip():
                    raise ValueError(f"method source is missing or empty: {relative}")
                methods.append(MethodSource(
                    key, f"upstream/develop-helper/{relative}",
                    document.content, document.sha256,
                ))
            if prd:
                relative = "capabilities/requirements-prd-template.md"
                document = self._read_document(self._helper_root, relative)
                if not document.content or not document.content.strip():
                    raise ValueError("PRD template is missing or empty")
                methods.append(MethodSource(
                    "prd_template", relative, document.content, document.sha256,
                ))
        except (OSError, ValueError, RuntimeError) as error:
            raise ReadFailedError(f"method sources: {error}") from None
        return RoleRules(
            path=str(path), body=body, sha256=digest(body), methods=tuple(methods),
        )

    def read_project(
        self, project_id: str, context: ExecutionContext
    ) -> tuple[DocumentRead, ...]:
        """Read the baseline documents of one authorized project in one pass."""

        self._authorize_read(project_id, context, BASELINE_DOCUMENTS)
        try:
            _, root = self._project_init.context(self._foundation, project_id)
            self._project_init.load_project(root, project_id)
            return tuple(self._read_document(root, path) for path in BASELINE_DOCUMENTS)
        except (OSError, ValueError) as error:
            raise ReadFailedError(str(error)) from None

    def read_document(
        self, project_id: str, path: str, context: ExecutionContext
    ) -> DocumentRead:
        """Read one project document, such as a history archive, in full."""

        self._authorize_read(project_id, context, (path,))
        try:
            _, root = self._project_init.context(self._foundation, project_id)
            self._project_init.load_project(root, project_id)
            return self._read_document(root, path)
        except (OSError, ValueError) as error:
            raise ReadFailedError(str(error)) from None

    def save_requirements_draft(
        self,
        project_id: str,
        body: str,
        expected_sha256: str,
        context: ExecutionContext,
    ) -> dict[str, object]:
        """Save the lightweight requirements Draft through ``save_draft``.

        Returns the kernel result unchanged; a ``changed=False`` result carries
        fewer fields than a write, so callers confirm the state by re-reading.
        """

        if not isinstance(expected_sha256, str) or not (
            expected_sha256 == MISSING or _SHA256_RE.fullmatch(expected_sha256)
        ):
            raise ValidationError("expected requirements version must be sha256 or missing")
        history = requirements_history_path(expected_sha256)
        extra = {history} if history else set()
        self._authorize_write(
            project_id,
            context,
            artifact_type=Deliverable.REQUIREMENTS.value,
            readable=REQUIREMENTS_SAVE_READABLE | extra,
            writable=frozenset({REQUIREMENTS_PATH} | extra),
        )
        if not isinstance(body, str) or not body.strip():
            raise ValidationError("requirements draft body must be non-empty text")
        if body.lstrip().startswith("---"):
            raise ValidationError(
                "正文不得自带 front matter；状态与审批标记由工具生成"
            )
        try:
            result = self._requirements.save_draft(
                self._foundation, project_id, body, expected_sha256
            )
        except PermissionError as error:
            raise AuthorizationError(str(error)) from error
        except ValueError as error:
            message = str(error)
            if "冲突" in message or "版本" in message or "已改变" in message:
                raise ConflictError(message) from error
            raise ValidationError(message) from error
        return dict(result)

    def _read_document(self, root: Path, path: str) -> DocumentRead:
        document = self._requirements.read_document(root, path)
        sha, content = document.get("sha256"), document.get("content")
        if sha == MISSING and content is None:
            return DocumentRead(path, MISSING, None)
        if not isinstance(content, str) or sha != digest(content):
            raise ValueError(f"{path}: read result does not match its digest")
        return DocumentRead(path, sha, content)

    @staticmethod
    def _check_context(project_id: str, context: ExecutionContext) -> None:
        if not isinstance(context, ExecutionContext):
            raise AuthorizationError("trusted ExecutionContext is required")
        grant = context.capability_grant
        if not grant.active or grant.revoked:
            raise AuthorizationError("capability grant is inactive or revoked")
        if (
            grant.project_id != context.project_id
            or grant.step_id != context.step_id
            or grant.attempt != context.attempt
        ):
            raise AuthorizationError("capability grant does not match context")
        if context.project_id != project_id:
            raise AuthorizationError("execution context project mismatch")

    @classmethod
    def _authorize_read(
        cls, project_id: str, context: ExecutionContext, paths: tuple[str, ...]
    ) -> None:
        cls._check_context(project_id, context)
        grant = context.capability_grant
        if not grant.permits(INSPECT_PROJECT, project_id):
            raise AuthorizationError(f"tool is not authorized: {INSPECT_PROJECT}")
        try:
            granted = [validate_project_relative_path(p) for p in grant.readable_paths]
            for path in paths:
                wanted = validate_project_relative_path(path)
                if not any(g == wanted or g in wanted.parents for g in granted):
                    raise AuthorizationError(f"path is not readable: {path}")
        except ValidationError as error:
            raise AuthorizationError("readable path scope is invalid") from error

    @classmethod
    def _authorize_write(
        cls,
        project_id: str,
        context: ExecutionContext,
        *,
        artifact_type: str,
        readable: frozenset[str],
        writable: frozenset[str],
    ) -> None:
        """The grant must equal the N04 save template exactly, as in the adapter."""

        cls._check_context(project_id, context)
        grant = context.capability_grant
        if context.step_id != SAVE_NODE:
            raise AuthorizationError(f"command is not authorized at node {context.step_id}")
        if grant.assigned_role != DETERMINISTIC_ROLE:
            raise AuthorizationError("authoritative writes require deterministic role")
        if not grant.permits(SAVE_DRAFT, project_id):
            raise AuthorizationError(f"tool is not authorized: {SAVE_DRAFT}")
        if grant.allowed_tools != _SAVE_TOOLS:
            raise AuthorizationError("tool scope does not match the save template")
        if grant.allowed_side_effects != frozenset({SAVE_DRAFT}):
            raise AuthorizationError("side-effect scope does not match the save template")
        if grant.artifact_types != frozenset({artifact_type}):
            raise AuthorizationError("artifact type scope does not match the save template")
        for label, wanted, granted in (
            ("readable", readable, grant.readable_paths),
            ("writable", writable, grant.writable_paths),
        ):
            try:
                normalized = {validate_project_relative_path(p) for p in granted}
                required = {validate_project_relative_path(p) for p in wanted}
            except ValidationError as error:
                raise AuthorizationError(f"{label} path scope is invalid") from error
            if not normalized or normalized != required:
                raise AuthorizationError(
                    f"{label} path scope does not match the save template"
                )
