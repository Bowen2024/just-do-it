"""Turn contracts for the requirements workflow.

The workflow is called once per turn: ``run_turn(turn_input, progress,
dependencies) -> turn_result``. The caller keeps ``Progress`` between turns.
This module only defines and validates the turn input, progress, candidate,
the four role result kinds and the turn result; it performs no reads, role
calls or saves.

Reuse map (requirements-workflow-plan.md §1). S2 rows live in ``workflow.py``
and ``tools.py``; later rows are not copied yet.

| Source                                   | Used by step | How                           |
| ---------------------------------------- | ------------ | ----------------------------- |
| langgraph_runtime ``_n01`` allowlist,    | S2           | copy; project/task from input |
|   ``_assert_binding``                    |              |                               |
| langgraph_runtime ``_n02`` baseline      | S2           | copy; keep "missing" distinct |
|   ``_sha_or_missing`` / ``_sha_or_empty``|              |   from unreadable input       |
| langgraph_runtime ``_n03`` role call     | S2           | copy; inputs from TurnInput   |
| langgraph_runtime ``_n04`` PRD save      | S3           | copy after SaveReference check|
| langgraph_runtime ``_n05`` re-read       | S3           | copy; report written vs check |
| langgraph_runtime ``_n06`` registration  | S3 optional  | copy when register_index=True |
| ports.agents AgentRequest/AgentResult    | S2           | import; parse candidate_body  |
| domain.commands SavePrdDraftCommand      | S3           | import                        |
| domain.policy build_execution_context    | S2-S4        | import; step id = current_node|
| adapters.develop_helper PRD save/inspect | S3           | import; private checks unused |
| requirements.py save_draft               | S4           | kernel call from local tools  |

Stage transitions (plan §2, §3.2). ``None`` is a task with no progress yet.

| From             | To                                                    |
| ---------------- | ----------------------------------------------------- |
| None             | analyzing                                             |
| analyzing        | waiting_answer, researching, candidate_review,        |
|                  | blocked, ended                                        |
| waiting_answer   | analyzing, ended                                      |
| researching      | researching (a research turn), analyzing, ended       |
| candidate_review | analyzing, waiting_save, ended                        |
| waiting_save     | saved, blocked, ended                                 |
| saved            | analyzing, ended                                      |
| blocked          | analyzing, ended                                      |
| ended            | the recorded resume_stage, or analyzing               |

``researching`` accepts ``analyze`` only once the pending request has a
research record on the current inputs (``allowed_actions``).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from hashlib import sha256
import json
import re
from typing import Mapping, Sequence


SCHEMA_VERSION = 1
ROLE = "requirements"

_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$")
_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


class ContractError(ValueError):
    """A turn input, progress value or role result breaks the contract."""


class Stage(str, Enum):
    ANALYZING = "analyzing"
    WAITING_ANSWER = "waiting_answer"
    RESEARCHING = "researching"
    CANDIDATE_REVIEW = "candidate_review"
    WAITING_SAVE = "waiting_save"
    SAVED = "saved"
    BLOCKED = "blocked"
    ENDED = "ended"


class Action(str, Enum):
    ANALYZE = "analyze"
    ANSWER = "answer"
    REVISE = "revise"
    SAVE = "save"
    RESEARCH = "research"
    PAUSE = "pause"
    RESUME = "resume"


class ResultKind(str, Enum):
    QUESTIONS = "questions"
    RESEARCH = "research"
    CANDIDATE = "candidate"
    BLOCKED = "blocked"


class Deliverable(str, Enum):
    REQUIREMENTS = "requirements"
    PRD = "prd"


class ResearchOutcome(str, Enum):
    EVIDENCE = "evidence"
    INSUFFICIENT = "insufficient"
    UNAVAILABLE = "unavailable"
    FAILED = "failed"


class MaterialCategory(str, Enum):
    SOURCE_FACT = "source_fact"
    PRESALES_ASSUMPTION = "presales_assumption"
    TEST_SCENARIO = "test_scenario"


DELIVERABLE_TARGETS: Mapping[Deliverable, str] = {
    Deliverable.REQUIREMENTS: "docs/requirements.md",
    Deliverable.PRD: "docs/PRD.md",
}

MISSING = "missing"
# The N02 baseline documents, in read order.
BASELINE_DOCUMENTS: tuple[str, ...] = (
    "project.json",
    "README.md",
    "docs/decisions.md",
    "docs/requirements.md",
    "docs/PRD.md",
)
_REQUIRED_DOCUMENTS = frozenset({"project.json", "README.md"})

RESULT_STAGES: Mapping[ResultKind, Stage] = {
    ResultKind.QUESTIONS: Stage.WAITING_ANSWER,
    ResultKind.RESEARCH: Stage.RESEARCHING,
    ResultKind.CANDIDATE: Stage.CANDIDATE_REVIEW,
    ResultKind.BLOCKED: Stage.BLOCKED,
}

TRANSITIONS: Mapping[Stage | None, frozenset[Stage]] = {
    None: frozenset({Stage.ANALYZING}),
    Stage.ANALYZING: frozenset(
        {
            Stage.WAITING_ANSWER,
            Stage.RESEARCHING,
            Stage.CANDIDATE_REVIEW,
            Stage.BLOCKED,
            Stage.ENDED,
        }
    ),
    Stage.WAITING_ANSWER: frozenset({Stage.ANALYZING, Stage.ENDED}),
    Stage.RESEARCHING: frozenset({Stage.RESEARCHING, Stage.ANALYZING, Stage.ENDED}),
    Stage.CANDIDATE_REVIEW: frozenset(
        {Stage.ANALYZING, Stage.WAITING_SAVE, Stage.ENDED}
    ),
    Stage.WAITING_SAVE: frozenset({Stage.SAVED, Stage.BLOCKED, Stage.ENDED}),
    Stage.SAVED: frozenset({Stage.ANALYZING, Stage.ENDED}),
    Stage.BLOCKED: frozenset({Stage.ANALYZING, Stage.ENDED}),
    Stage.ENDED: frozenset({Stage.ANALYZING}),
}

NEXT_ACTIONS: Mapping[Stage | None, frozenset[Action]] = {
    None: frozenset({Action.ANALYZE}),
    Stage.ANALYZING: frozenset({Action.PAUSE}),
    Stage.WAITING_ANSWER: frozenset({Action.ANSWER, Action.ANALYZE, Action.PAUSE}),
    Stage.RESEARCHING: frozenset({Action.RESEARCH, Action.PAUSE}),
    Stage.CANDIDATE_REVIEW: frozenset({Action.REVISE, Action.SAVE, Action.PAUSE}),
    Stage.WAITING_SAVE: frozenset({Action.SAVE, Action.PAUSE}),
    Stage.SAVED: frozenset({Action.REVISE, Action.PAUSE}),
    Stage.BLOCKED: frozenset(
        {Action.ANALYZE, Action.ANSWER, Action.REVISE, Action.PAUSE}
    ),
    Stage.ENDED: frozenset({Action.RESUME}),
}

# Stages a paused task may resume into; waiting_save and analyzing only exist
# inside a turn.
_RESUMABLE = frozenset(
    {
        Stage.WAITING_ANSWER,
        Stage.RESEARCHING,
        Stage.CANDIDATE_REVIEW,
        Stage.SAVED,
        Stage.BLOCKED,
    }
)

_RESULT_KEYS = frozenset(
    {
        "schema_version",
        "kind",
        "task_id",
        "project_id",
        "summary",
        "source_refs",
        "assumptions",
        "changes",
        "open_items",
        "payload",
    }
)
_PAYLOAD_KEYS: Mapping[ResultKind, frozenset[str]] = {
    ResultKind.QUESTIONS: frozenset({"questions"}),
    ResultKind.RESEARCH: frozenset(
        {"decision", "questions", "scope", "known_basis", "stop_condition"}
    ),
    ResultKind.CANDIDATE: frozenset({"deliverable", "body"}),
    ResultKind.BLOCKED: frozenset(
        {"missing", "completed", "impact", "resume_condition"}
    ),
}
_QUESTION_KEYS = frozenset({"question_id", "text", "reason", "options"})
_OPTION_KEYS = frozenset({"label", "impact"})
_SOURCE_REF_KEYS = frozenset({"source_id", "version"})


def digest(body: str) -> str:
    return sha256(body.encode("utf-8")).hexdigest()


def _text(value: object, label: str, *, multiline: bool = False) -> str:
    if not isinstance(value, str) or not value.strip() or "\x00" in value:
        raise ContractError(f"{label} must be non-empty text")
    allowed_controls = {9, 10} if multiline else set()
    if any(
        ord(character) == 127
        or (ord(character) < 32 and ord(character) not in allowed_controls)
        for character in value
    ):
        if multiline:
            raise ContractError(f"{label} contains an invalid control character")
        raise ContractError(f"{label} must be single-line text")
    return value


def _optional_text(value: object, label: str) -> str:
    if value == "":
        return value
    return _text(value, label, multiline=True)


def _ident(value: object, label: str) -> str:
    if not isinstance(value, str) or not _ID_RE.fullmatch(value):
        raise ContractError(f"{label} must be a simple identifier")
    return value


def _sha(value: object, label: str) -> str:
    if not isinstance(value, str) or not _SHA256_RE.fullmatch(value):
        raise ContractError(f"{label} must be a lowercase SHA-256 digest")
    return value


def _enum(enum_type: type[Enum], value: object, label: str):
    if isinstance(value, enum_type):
        return value
    try:
        return enum_type(value)
    except (TypeError, ValueError):
        raise ContractError(f"{label} is not supported: {value!r}") from None


def _tuple_of(value: object, item_type: type, label: str) -> tuple:
    if not isinstance(value, tuple) or not all(
        isinstance(item, item_type) for item in value
    ):
        raise ContractError(f"{label} must be a tuple of {item_type.__name__}")
    return value


def _text_tuple(value: object, label: str, *, allow_empty: bool = True) -> tuple[str, ...]:
    _tuple_of(value, str, label)
    if not allow_empty and not value:
        raise ContractError(f"{label} must not be empty")
    for item in value:
        _text(item, label, multiline=True)
    return value


def _unique(values: Sequence[str], label: str) -> None:
    if len(set(values)) != len(values):
        raise ContractError(f"{label} must be unique")


@dataclass(frozen=True, slots=True)
class SourceMaterial:
    """Exact material text given to the role; the digest is computed here."""

    source_id: str
    location: str
    version: str
    category: MaterialCategory
    body: str
    body_sha256: str = field(init=False)

    def __post_init__(self) -> None:
        _ident(self.source_id, "source_id")
        _text(self.location, "location")
        _text(self.version, "version")
        object.__setattr__(
            self, "category", _enum(MaterialCategory, self.category, "category")
        )
        _text(self.body, "body", multiline=True)
        object.__setattr__(self, "body_sha256", digest(self.body))

    @classmethod
    def from_mapping(cls, data: Mapping[str, object]) -> SourceMaterial:
        material = cls(
            source_id=data.get("source_id"),
            location=data.get("location"),
            version=data.get("version"),
            category=data.get("category"),
            body=data.get("body"),
        )
        recorded = data.get("body_sha256")
        if recorded is not None and recorded != material.body_sha256:
            raise ContractError(
                f"body_sha256 does not match the body of {material.source_id}"
            )
        return material

    @property
    def ref(self) -> SourceRef:
        return SourceRef(self.source_id, self.version)

    @property
    def input_version(self) -> InputVersion:
        return InputVersion(self.source_id, self.version, self.body_sha256)


@dataclass(frozen=True, slots=True)
class SourceRef:
    """A role citation of one provided material."""

    source_id: str
    version: str

    def __post_init__(self) -> None:
        _ident(self.source_id, "source_id")
        _text(self.version, "version")


@dataclass(frozen=True, slots=True)
class InputVersion:
    """The exact material a turn used; the digest detects unlabelled edits."""

    source_id: str
    version: str
    body_sha256: str

    def __post_init__(self) -> None:
        _ident(self.source_id, "source_id")
        _text(self.version, "version")
        _sha(self.body_sha256, "body_sha256")


@dataclass(frozen=True, slots=True)
class DocumentVersion:
    """One baseline document; ``missing`` only means the file does not exist."""

    path: str
    sha256: str

    def __post_init__(self) -> None:
        if self.path not in BASELINE_DOCUMENTS:
            raise ContractError(f"not a baseline document: {self.path!r}")
        if self.sha256 == MISSING:
            if self.path in _REQUIRED_DOCUMENTS:
                raise ContractError(f"baseline document is required: {self.path}")
        else:
            _sha(self.sha256, f"{self.path} sha256")

    @property
    def exists(self) -> bool:
        return self.sha256 != MISSING


@dataclass(frozen=True, slots=True)
class Baseline:
    """Trusted read snapshot taken before the role call that formed a candidate."""

    project_id: str
    documents: tuple[DocumentVersion, ...]
    materials: tuple[InputVersion, ...]

    def __post_init__(self) -> None:
        _ident(self.project_id, "baseline.project_id")
        _tuple_of(self.documents, DocumentVersion, "baseline.documents")
        if tuple(d.path for d in self.documents) != BASELINE_DOCUMENTS:
            raise ContractError("baseline must list every baseline document once")
        _tuple_of(self.materials, InputVersion, "baseline.materials")
        _unique([m.source_id for m in self.materials], "baseline.materials")

    def document(self, path: str) -> DocumentVersion:
        for item in self.documents:
            if item.path == path:
                return item
        raise ContractError(f"not a baseline document: {path!r}")


@dataclass(frozen=True, slots=True)
class Option:
    label: str
    impact: str

    def __post_init__(self) -> None:
        _text(self.label, "option.label")
        _text(self.impact, "option.impact", multiline=True)


@dataclass(frozen=True, slots=True)
class Question:
    question_id: str
    text: str
    reason: str
    options: tuple[Option, ...] = ()

    def __post_init__(self) -> None:
        _ident(self.question_id, "question_id")
        _text(self.text, "question.text", multiline=True)
        _text(self.reason, "question.reason", multiline=True)
        _tuple_of(self.options, Option, "question.options")


@dataclass(frozen=True, slots=True)
class Answer:
    """A user answer. ``option`` is the option label the user explicitly picked;
    an answer without it stays open for clarification. ``replaces`` keeps the
    earlier answer text and is recorded by the workflow, never by the caller."""

    question_id: str
    text: str
    option: str | None = None
    replaces: str | None = None

    def __post_init__(self) -> None:
        _ident(self.question_id, "answer.question_id")
        _text(self.text, "answer.text", multiline=True)
        if self.option is not None:
            _text(self.option, "answer.option")
        if self.replaces is not None:
            _text(self.replaces, "answer.replaces", multiline=True)


@dataclass(frozen=True, slots=True)
class Choice:
    """A user decision kept across turns, optionally tied to a question."""

    subject: str
    value: str
    question_id: str | None = None

    def __post_init__(self) -> None:
        _text(self.subject, "choice.subject")
        _text(self.value, "choice.value", multiline=True)
        if self.question_id is not None:
            _ident(self.question_id, "choice.question_id")


@dataclass(frozen=True, slots=True)
class Evidence:
    source: str
    accessed_on: str
    supports: str
    content: str
    limitation: str = ""
    test_material: bool = False

    def __post_init__(self) -> None:
        _text(self.source, "evidence.source")
        if not isinstance(self.accessed_on, str) or not _DATE_RE.fullmatch(
            self.accessed_on
        ):
            raise ContractError("evidence.accessed_on must be YYYY-MM-DD")
        _text(self.supports, "evidence.supports", multiline=True)
        _text(self.content, "evidence.content", multiline=True)
        _optional_text(self.limitation, "evidence.limitation")
        if not isinstance(self.test_material, bool):
            raise ContractError("evidence.test_material must be a bool")


@dataclass(frozen=True, slots=True)
class ResearchRequest:
    decision: str
    questions: tuple[str, ...]
    scope: str
    known_basis: tuple[str, ...]
    stop_condition: str

    def __post_init__(self) -> None:
        _text(self.decision, "research.decision", multiline=True)
        _text_tuple(self.questions, "research.questions", allow_empty=False)
        _text(self.scope, "research.scope", multiline=True)
        _text_tuple(self.known_basis, "research.known_basis")
        _text(self.stop_condition, "research.stop_condition", multiline=True)


@dataclass(frozen=True, slots=True)
class ResearchResult:
    """What one research call returned; ``failed`` is recorded by the workflow."""

    outcome: ResearchOutcome
    evidence: tuple[Evidence, ...] = ()
    limitations: tuple[str, ...] = ()
    test_material: bool = False

    def __post_init__(self) -> None:
        object.__setattr__(
            self, "outcome", _enum(ResearchOutcome, self.outcome, "research.outcome")
        )
        _tuple_of(self.evidence, Evidence, "research.evidence")
        _text_tuple(self.limitations, "research.limitations")
        if not isinstance(self.test_material, bool):
            raise ContractError("research.test_material must be a bool")
        if self.outcome is ResearchOutcome.EVIDENCE and not self.evidence:
            raise ContractError("an evidence result needs evidence")
        if self.outcome is not ResearchOutcome.EVIDENCE and not self.limitations:
            raise ContractError(f"a {self.outcome.value} result states its limitations")
        if (
            self.outcome in (ResearchOutcome.UNAVAILABLE, ResearchOutcome.FAILED)
            and self.evidence
        ):
            raise ContractError(f"a {self.outcome.value} result carries no evidence")


def research_inputs_sha256(
    input_versions: Sequence[InputVersion],
    answers: Sequence[Answer],
    choices: Sequence[Choice],
) -> str:
    """The inputs a research request depends on; research results never count."""

    snapshot = {
        "materials": sorted([v.source_id, v.version, v.body_sha256] for v in input_versions),
        "answers": sorted([a.question_id, a.text, a.option or ""] for a in answers),
        "choices": sorted([c.subject, c.value, c.question_id or ""] for c in choices),
    }
    return digest(json.dumps(snapshot, ensure_ascii=False, sort_keys=True))


def research_request_id(request: ResearchRequest, inputs_sha256: str) -> str:
    content = [
        request.decision,
        list(request.questions),
        request.scope,
        list(request.known_basis),
        request.stop_condition,
        inputs_sha256,
    ]
    return "rs-" + digest(json.dumps(content, ensure_ascii=False))[:16]


@dataclass(frozen=True, slots=True)
class ResearchRecord:
    """One research turn: the request, its input snapshot and the actual result.

    ``called`` is whether the research function ran and used budget; a request
    that never ran (no tool or no budget) is ``unavailable``.
    """

    request: ResearchRequest
    inputs_sha256: str
    result: ResearchResult
    called: bool
    request_id: str = field(init=False)

    def __post_init__(self) -> None:
        if not isinstance(self.request, ResearchRequest):
            raise ContractError("research record needs a ResearchRequest")
        _sha(self.inputs_sha256, "research.inputs_sha256")
        if not isinstance(self.result, ResearchResult):
            raise ContractError("research record needs a ResearchResult")
        if not isinstance(self.called, bool):
            raise ContractError("research.called must be a bool")
        if not self.called and self.result.outcome is not ResearchOutcome.UNAVAILABLE:
            raise ContractError("research that did not run can only be unavailable")
        object.__setattr__(
            self, "request_id", research_request_id(self.request, self.inputs_sha256)
        )


@dataclass(frozen=True, slots=True)
class CandidateDraft:
    """Candidate payload; ``body`` is the only artifact text in a result."""

    deliverable: Deliverable
    body: str

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "deliverable",
            _enum(Deliverable, self.deliverable, "candidate.deliverable"),
        )
        _text(self.body, "candidate.body", multiline=True)


@dataclass(frozen=True, slots=True)
class BlockedReport:
    missing: tuple[str, ...]
    completed: tuple[str, ...]
    impact: str
    resume_condition: str

    def __post_init__(self) -> None:
        _text_tuple(self.missing, "blocked.missing", allow_empty=False)
        _text_tuple(self.completed, "blocked.completed")
        _text(self.impact, "blocked.impact", multiline=True)
        _text(self.resume_condition, "blocked.resume_condition", multiline=True)


_PAYLOAD_TYPES: Mapping[ResultKind, type] = {
    ResultKind.QUESTIONS: tuple,
    ResultKind.RESEARCH: ResearchRequest,
    ResultKind.CANDIDATE: CandidateDraft,
    ResultKind.BLOCKED: BlockedReport,
}


@dataclass(frozen=True, slots=True)
class RoleResult:
    """A validated role result. It carries no binding, grant or save authority."""

    kind: ResultKind
    task_id: str
    project_id: str
    summary: str
    source_refs: tuple[SourceRef, ...]
    assumptions: tuple[str, ...]
    changes: tuple[str, ...]
    open_items: tuple[str, ...]
    payload: tuple[Question, ...] | ResearchRequest | CandidateDraft | BlockedReport

    def __post_init__(self) -> None:
        object.__setattr__(self, "kind", _enum(ResultKind, self.kind, "kind"))
        _ident(self.task_id, "task_id")
        _ident(self.project_id, "project_id")
        _text(self.summary, "summary", multiline=True)
        _tuple_of(self.source_refs, SourceRef, "source_refs")
        _unique([ref.source_id for ref in self.source_refs], "source_refs")
        _text_tuple(self.assumptions, "assumptions")
        _text_tuple(self.changes, "changes")
        _text_tuple(self.open_items, "open_items")
        if not isinstance(self.payload, _PAYLOAD_TYPES[self.kind]):
            raise ContractError(f"payload does not match kind {self.kind.value}")
        if self.kind is ResultKind.QUESTIONS:
            _tuple_of(self.payload, Question, "payload.questions")
            if not self.payload:
                raise ContractError("payload.questions must not be empty")
            _unique([q.question_id for q in self.payload], "question_id")

    @property
    def stage(self) -> Stage:
        return RESULT_STAGES[self.kind]


@dataclass(frozen=True, slots=True)
class Candidate:
    candidate_id: str
    deliverable: Deliverable
    body: str
    source_refs: tuple[SourceRef, ...]
    changes: tuple[str, ...] = ()
    open_items: tuple[str, ...] = ()
    baseline: Baseline | None = None
    revision: int = 1
    revises: str | None = None
    research_refs: tuple[str, ...] = ()
    body_sha256: str = field(init=False)

    def __post_init__(self) -> None:
        _ident(self.candidate_id, "candidate_id")
        _tuple_of(self.research_refs, str, "candidate.research_refs")
        for ref in self.research_refs:
            _ident(ref, "candidate.research_refs")
        _unique(self.research_refs, "candidate.research_refs")
        if type(self.revision) is not int or self.revision < 1:
            raise ContractError("candidate.revision must be a positive int")
        if (self.revision == 1) != (self.revises is None):
            raise ContractError("only a revision names the candidate it revises")
        if self.revises is not None:
            _ident(self.revises, "candidate.revises")
            if self.revises == self.candidate_id:
                raise ContractError("a revision needs its own candidate_id")
        object.__setattr__(
            self,
            "deliverable",
            _enum(Deliverable, self.deliverable, "candidate.deliverable"),
        )
        _text(self.body, "candidate.body", multiline=True)
        _tuple_of(self.source_refs, SourceRef, "candidate.source_refs")
        _text_tuple(self.changes, "candidate.changes")
        _text_tuple(self.open_items, "candidate.open_items")
        if self.baseline is not None:
            if not isinstance(self.baseline, Baseline):
                raise ContractError("candidate.baseline must be a Baseline")
            read = {m.source_id: m.version for m in self.baseline.materials}
            for ref in self.source_refs:
                if read.get(ref.source_id) != ref.version:
                    raise ContractError(
                        f"candidate cites a material outside its baseline: {ref.source_id}"
                    )
        object.__setattr__(self, "body_sha256", digest(self.body))

    @classmethod
    def from_role_result(
        cls,
        result: RoleResult,
        candidate_id: str,
        baseline: Baseline | None = None,
        *,
        revision: int = 1,
        revises: str | None = None,
        research_refs: tuple[str, ...] = (),
    ) -> Candidate:
        if result.kind is not ResultKind.CANDIDATE:
            raise ContractError("only a candidate result forms a candidate")
        draft = result.payload
        return cls(
            candidate_id=candidate_id,
            deliverable=draft.deliverable,
            body=draft.body,
            source_refs=result.source_refs,
            changes=result.changes,
            open_items=result.open_items,
            baseline=baseline,
            revision=revision,
            revises=revises,
            research_refs=research_refs,
        )


@dataclass(frozen=True, slots=True)
class SaveReference:
    """Caller-supplied save authorization bound to one exact candidate."""

    candidate_id: str
    body_sha256: str
    deliverable: Deliverable
    target: str

    def __post_init__(self) -> None:
        _ident(self.candidate_id, "save.candidate_id")
        _sha(self.body_sha256, "save.body_sha256")
        object.__setattr__(
            self,
            "deliverable",
            _enum(Deliverable, self.deliverable, "save.deliverable"),
        )
        if self.target != DELIVERABLE_TARGETS[self.deliverable]:
            raise ContractError("save.target does not match the deliverable")

    def matches(self, candidate: Candidate | None) -> bool:
        return (
            candidate is not None
            and candidate.candidate_id == self.candidate_id
            and candidate.body_sha256 == self.body_sha256
            and candidate.deliverable is self.deliverable
        )


@dataclass(frozen=True, slots=True)
class ToolResult:
    tool: str
    ok: bool
    data: Mapping[str, object] = field(default_factory=dict)

    def __post_init__(self) -> None:
        _ident(self.tool, "tool")
        if not isinstance(self.ok, bool):
            raise ContractError("tool result ok must be a bool")
        if not isinstance(self.data, Mapping):
            raise ContractError("tool result data must be a mapping")


@dataclass(frozen=True, slots=True)
class TurnInput:
    task_id: str
    project_id: str
    action: Action
    utterance: str
    materials: tuple[SourceMaterial, ...] = ()
    answers: tuple[Answer, ...] = ()
    save: SaveReference | None = None
    register_index: bool = False

    def __post_init__(self) -> None:
        _ident(self.task_id, "task_id")
        _ident(self.project_id, "project_id")
        object.__setattr__(self, "action", _enum(Action, self.action, "action"))
        _text(self.utterance, "utterance", multiline=True)
        _tuple_of(self.materials, SourceMaterial, "materials")
        _unique([m.source_id for m in self.materials], "materials.source_id")
        _tuple_of(self.answers, Answer, "answers")
        _unique([a.question_id for a in self.answers], "answers.question_id")
        if any(a.replaces is not None for a in self.answers):
            raise ContractError("answer.replaces is recorded by the workflow")
        if (self.action is Action.ANSWER) != bool(self.answers):
            raise ContractError("answers are given exactly when action is answer")
        if self.save is not None and not isinstance(self.save, SaveReference):
            raise ContractError("save must be a SaveReference")
        if (self.action is Action.SAVE) != (self.save is not None):
            raise ContractError("a save reference is given exactly when action is save")
        if not isinstance(self.register_index, bool):
            raise ContractError("register_index must be a bool")
        if self.register_index and self.action is not Action.SAVE:
            raise ContractError("register_index only applies to a save action")


@dataclass(frozen=True, slots=True)
class Progress:
    """Everything a later turn needs, passed back by the caller.

    ``materials`` keeps the material text so a turn without materials can
    continue; ``input_versions`` is derived from it when left empty.
    ``save_results`` belong to the current candidate only; results of earlier
    candidates move to ``prior_save_results`` when a revision replaces it.
    ``research_records`` only grow; the research budget used is the number of
    records whose research function actually ran.
    """

    task_id: str
    project_id: str
    stage: Stage
    input_versions: tuple[InputVersion, ...] = ()
    understanding: str = ""
    choices: tuple[Choice, ...] = ()
    questions: tuple[Question, ...] = ()
    answers: tuple[Answer, ...] = ()
    evidence: tuple[Evidence, ...] = ()
    candidate: Candidate | None = None
    save_reference: SaveReference | None = None
    save_results: tuple[ToolResult, ...] = ()
    resume_stage: Stage | None = None
    materials: tuple[SourceMaterial, ...] = ()
    open_items: tuple[str, ...] = ()
    research: ResearchRequest | None = None
    blocked: BlockedReport | None = None
    prior_save_results: tuple[ToolResult, ...] = ()
    research_records: tuple[ResearchRecord, ...] = ()

    @property
    def research_calls(self) -> int:
        return sum(1 for record in self.research_records if record.called)

    @property
    def research_inputs_sha256(self) -> str:
        return research_inputs_sha256(self.input_versions, self.answers, self.choices)

    def research_record(self) -> ResearchRecord | None:
        """The pending request's latest record on the current inputs; a run one wins."""

        if self.research is None:
            return None
        request_id = research_request_id(self.research, self.research_inputs_sha256)
        matching = [r for r in self.research_records if r.request_id == request_id]
        ran = [r for r in matching if r.called]
        return (ran or matching or [None])[-1]

    def __post_init__(self) -> None:
        _ident(self.task_id, "task_id")
        _ident(self.project_id, "project_id")
        object.__setattr__(self, "stage", _enum(Stage, self.stage, "stage"))
        _tuple_of(self.materials, SourceMaterial, "materials")
        _unique([m.source_id for m in self.materials], "materials.source_id")
        if self.materials:
            versions = tuple(m.input_version for m in self.materials)
            if not self.input_versions:
                object.__setattr__(self, "input_versions", versions)
            elif set(versions) != set(self.input_versions):
                raise ContractError("materials do not match input_versions")
        _tuple_of(self.input_versions, InputVersion, "input_versions")
        _unique([ref.source_id for ref in self.input_versions], "input_versions")
        _optional_text(self.understanding, "understanding")
        _tuple_of(self.choices, Choice, "choices")
        _tuple_of(self.questions, Question, "questions")
        question_ids = [q.question_id for q in self.questions]
        _unique(question_ids, "questions.question_id")
        _tuple_of(self.answers, Answer, "answers")
        _unique([a.question_id for a in self.answers], "answers.question_id")
        known = {q.question_id: q for q in self.questions}
        picked = {}
        for answer in self.answers:
            question = known.get(answer.question_id)
            if question is None:
                raise ContractError(f"answer has no question: {answer.question_id}")
            if answer.option is not None:
                _check_option(question, answer.option)
                picked[answer.question_id] = answer.option
        for choice in self.choices:
            if choice.question_id is None:
                continue
            if choice.question_id not in known:
                raise ContractError(f"choice has no question: {choice.question_id}")
            if picked.get(choice.question_id) != choice.value:
                raise ContractError(
                    f"choice is not the user's explicit answer: {choice.question_id}"
                )
        _tuple_of(self.evidence, Evidence, "evidence")
        _text_tuple(self.open_items, "open_items")
        if self.research is not None and not isinstance(self.research, ResearchRequest):
            raise ContractError("research must be a ResearchRequest")
        if self.blocked is not None and not isinstance(self.blocked, BlockedReport):
            raise ContractError("blocked must be a BlockedReport")
        _tuple_of(self.research_records, ResearchRecord, "research_records")
        _unique(
            [r.request_id for r in self.research_records if r.called],
            "research run per request",
        )
        if self.candidate is not None:
            if not isinstance(self.candidate, Candidate):
                raise ContractError("candidate must be a Candidate")
            baseline = self.candidate.baseline
            if baseline is not None and baseline.project_id != self.project_id:
                raise ContractError("candidate baseline belongs to another project")
        if self.save_reference is not None:
            if not isinstance(self.save_reference, SaveReference):
                raise ContractError("save_reference must be a SaveReference")
            if not self.save_reference.matches(self.candidate):
                raise ContractError("save_reference does not match the current candidate")
        _tuple_of(self.save_results, ToolResult, "save_results")
        current = None if self.candidate is None else self.candidate.candidate_id
        for result in self.save_results:
            saved_for = result.data.get("candidate_id")
            if saved_for is not None and saved_for != current:
                raise ContractError("save_results belong to another candidate")
        _tuple_of(self.prior_save_results, ToolResult, "prior_save_results")
        if self.stage is Stage.ENDED:
            if self.resume_stage is None:
                raise ContractError("an ended task records its resume_stage")
            object.__setattr__(
                self, "resume_stage", _enum(Stage, self.resume_stage, "resume_stage")
            )
            if self.resume_stage not in _RESUMABLE:
                raise ContractError(
                    f"cannot resume into {self.resume_stage.value}"
                )
        elif self.resume_stage is not None:
            raise ContractError("resume_stage is only kept while ended")
        effective = self.resume_stage if self.stage is Stage.ENDED else self.stage
        if effective in {Stage.CANDIDATE_REVIEW, Stage.WAITING_SAVE} and (
            self.candidate is None
        ):
            raise ContractError(f"stage {effective.value} requires a candidate")
        if effective is Stage.WAITING_SAVE and self.save_reference is None:
            raise ContractError("stage waiting_save requires a save reference")


def _check_option(question: Question, option: str) -> None:
    if option not in {o.label for o in question.options}:
        raise ContractError(
            f"answer.option is not an option of {question.question_id}: {option!r}"
        )


def allowed_actions(progress: Progress | None) -> frozenset[Action]:
    actions = NEXT_ACTIONS[None if progress is None else progress.stage]
    if (
        progress is not None
        and progress.stage is Stage.RESEARCHING
        and progress.research_record() is not None
    ):
        actions = actions | {Action.ANALYZE}
    return actions


def check_transition(progress: Progress | None, target: Stage) -> None:
    source = None if progress is None else progress.stage
    target = _enum(Stage, target, "target stage")
    allowed = TRANSITIONS[source]
    if source is Stage.ENDED:
        allowed = allowed | {progress.resume_stage}
    if target not in allowed:
        label = "start" if source is None else source.value
        raise ContractError(f"stage cannot move from {label} to {target.value}")


def check_turn(turn: TurnInput, progress: Progress | None) -> None:
    """Reject a turn that does not belong to the given progress."""

    if not isinstance(turn, TurnInput):
        raise ContractError("turn must be a TurnInput")
    if progress is not None:
        if not isinstance(progress, Progress):
            raise ContractError("progress must be a Progress")
        if (turn.task_id, turn.project_id) != (progress.task_id, progress.project_id):
            raise ContractError("turn task or project does not match the progress")
    if turn.action not in allowed_actions(progress):
        stage = "start" if progress is None else progress.stage.value
        raise ContractError(f"action {turn.action.value} is not accepted at {stage}")
    if turn.answers:
        asked = {q.question_id: q for q in progress.questions}
        for answer in turn.answers:
            question = asked.get(answer.question_id)
            if question is None:
                raise ContractError(f"answer has no question: {answer.question_id}")
            if answer.option is not None:
                _check_option(question, answer.option)
    if turn.save is not None and not turn.save.matches(progress.candidate):
        raise ContractError("save reference does not match the current candidate")


def _reject_constant(value: str) -> object:
    raise ContractError(f"role result contains a non-JSON number: {value}")


def _unique_object(pairs: list[tuple[str, object]]) -> dict[str, object]:
    keys = [key for key, _ in pairs]
    if len(set(keys)) != len(keys):
        raise ContractError("role result repeats an object key")
    return dict(pairs)


def _object(value: object, keys: frozenset[str], label: str) -> Mapping[str, object]:
    if not isinstance(value, dict):
        raise ContractError(f"{label} must be a JSON object")
    missing = sorted(keys - value.keys())
    if missing:
        raise ContractError(f"{label} is missing: {', '.join(missing)}")
    extra = sorted(value.keys() - keys)
    if extra:
        raise ContractError(f"{label} has unsupported fields: {', '.join(extra)}")
    return value


def _string_list(value: object, label: str) -> tuple[str, ...]:
    if not isinstance(value, list):
        raise ContractError(f"{label} must be a JSON array")
    return _text_tuple(tuple(value), label)


def _parse_payload(kind: ResultKind, value: object):
    data = _object(value, _PAYLOAD_KEYS[kind], "payload")
    if kind is ResultKind.QUESTIONS:
        items = data["questions"]
        if not isinstance(items, list):
            raise ContractError("payload.questions must be a JSON array")
        questions = []
        for item in items:
            question = _object(item, _QUESTION_KEYS, "question")
            options = question["options"]
            if not isinstance(options, list):
                raise ContractError("question.options must be a JSON array")
            questions.append(
                Question(
                    question_id=question["question_id"],
                    text=question["text"],
                    reason=question["reason"],
                    options=tuple(
                        Option(**_object(option, _OPTION_KEYS, "option"))
                        for option in options
                    ),
                )
            )
        return tuple(questions)
    if kind is ResultKind.RESEARCH:
        return ResearchRequest(
            decision=data["decision"],
            questions=_string_list(data["questions"], "research.questions"),
            scope=data["scope"],
            known_basis=_string_list(data["known_basis"], "research.known_basis"),
            stop_condition=data["stop_condition"],
        )
    if kind is ResultKind.CANDIDATE:
        return CandidateDraft(deliverable=data["deliverable"], body=data["body"])
    return BlockedReport(
        missing=_string_list(data["missing"], "blocked.missing"),
        completed=_string_list(data["completed"], "blocked.completed"),
        impact=data["impact"],
        resume_condition=data["resume_condition"],
    )


def parse_role_result(
    raw: object,
    *,
    task_id: str,
    project_id: str,
    materials: Sequence[SourceMaterial],
) -> RoleResult:
    """Parse one role result package; never guesses a kind or salvages text."""

    if not isinstance(raw, str):
        raise ContractError("role result must be JSON text")
    try:
        data = json.loads(
            raw, object_pairs_hook=_unique_object, parse_constant=_reject_constant
        )
    except json.JSONDecodeError as error:
        raise ContractError(f"role result is not valid JSON: {error.msg}") from None
    data = _object(data, _RESULT_KEYS, "role result")
    version = data["schema_version"]
    if type(version) is not int or version != SCHEMA_VERSION:
        raise ContractError(f"schema_version is not supported: {version!r}")
    kind = _enum(ResultKind, data["kind"], "kind")
    if (data["task_id"], data["project_id"]) != (task_id, project_id):
        raise ContractError("role result task or project does not match this turn")

    provided = {m.source_id: m for m in materials}
    refs_data = data["source_refs"]
    if not isinstance(refs_data, list):
        raise ContractError("source_refs must be a JSON array")
    refs = []
    for item in refs_data:
        ref = SourceRef(**_object(item, _SOURCE_REF_KEYS, "source_ref"))
        material = provided.get(ref.source_id)
        if material is None or material.version != ref.version:
            raise ContractError(f"source_ref was not provided: {ref.source_id}")
        refs.append(ref)
    if kind is ResultKind.CANDIDATE and provided and not refs:
        raise ContractError("a candidate must cite the provided materials")

    return RoleResult(
        kind=kind,
        task_id=data["task_id"],
        project_id=data["project_id"],
        summary=data["summary"],
        source_refs=tuple(refs),
        assumptions=_string_list(data["assumptions"], "assumptions"),
        changes=_string_list(data["changes"], "changes"),
        open_items=_string_list(data["open_items"], "open_items"),
        payload=_parse_payload(kind, data["payload"]),
    )


def parse_agent_result(
    result: object,
    *,
    task_id: str,
    project_id: str,
    materials: Sequence[SourceMaterial],
) -> RoleResult:
    """Read a role result from an ``AgentResult``; claims never add authority."""

    claimed_project = getattr(result, "claimed_project_id", None)
    claimed_role = getattr(result, "claimed_role", None)
    claimed_tools = getattr(result, "claimed_tools", frozenset())
    if claimed_project not in (None, project_id):
        raise ContractError("agent result claims another project")
    if claimed_role not in (None, ROLE):
        raise ContractError("agent result claims another role")
    if claimed_tools:
        raise ContractError("agent result cannot claim tools")
    return parse_role_result(
        getattr(result, "candidate_body", None),
        task_id=task_id,
        project_id=project_id,
        materials=materials,
    )


@dataclass(frozen=True, slots=True)
class TurnResult:
    stage: Stage
    content: str
    progress: Progress
    tool_results: tuple[ToolResult, ...] = ()
    next_actions: frozenset[Action] = field(init=False)

    def __post_init__(self) -> None:
        object.__setattr__(self, "stage", _enum(Stage, self.stage, "stage"))
        _text(self.content, "content", multiline=True)
        if not isinstance(self.progress, Progress):
            raise ContractError("progress must be a Progress")
        if self.progress.stage is not self.stage:
            raise ContractError("turn result stage must equal the progress stage")
        _tuple_of(self.tool_results, ToolResult, "tool_results")
        object.__setattr__(self, "next_actions", allowed_actions(self.progress))
