"""File tools and optional, lazily loaded program-workflow compatibility exports."""

from importlib import import_module


def __getattr__(name):
    if name not in __all__:
        raise AttributeError(name)
    if name in {"INSTRUCTION", "UnsupportedActionError", "WorkflowDependencies", "run_turn"}:
        module = ".hardcode.workflow"
    elif name in {"ROLE_RULES_PATH", "DocumentRead", "MethodSource", "ReadFailedError",
                  "RequirementsTools", "RoleRules"}:
        module = ".hardcode.tools"
    else:
        module = ".hardcode.contracts"
    value = getattr(import_module(module, __name__), name)
    globals()[name] = value
    return value

__all__ = [
    "BASELINE_DOCUMENTS",
    "DELIVERABLE_TARGETS",
    "INSTRUCTION",
    "MISSING",
    "NEXT_ACTIONS",
    "RESULT_STAGES",
    "ROLE",
    "ROLE_RULES_PATH",
    "SCHEMA_VERSION",
    "TRANSITIONS",
    "Action",
    "Answer",
    "Baseline",
    "BlockedReport",
    "Candidate",
    "CandidateDraft",
    "Choice",
    "ContractError",
    "Deliverable",
    "DocumentRead",
    "DocumentVersion",
    "Evidence",
    "InputVersion",
    "MaterialCategory",
    "MethodSource",
    "Option",
    "Progress",
    "Question",
    "ReadFailedError",
    "RequirementsTools",
    "ResearchOutcome",
    "ResearchRecord",
    "ResearchRequest",
    "ResearchResult",
    "ResultKind",
    "RoleResult",
    "RoleRules",
    "SaveReference",
    "SourceMaterial",
    "SourceRef",
    "Stage",
    "ToolResult",
    "TurnInput",
    "TurnResult",
    "UnsupportedActionError",
    "WorkflowDependencies",
    "allowed_actions",
    "check_transition",
    "check_turn",
    "digest",
    "parse_agent_result",
    "parse_role_result",
    "research_inputs_sha256",
    "research_request_id",
    "run_turn",
]
