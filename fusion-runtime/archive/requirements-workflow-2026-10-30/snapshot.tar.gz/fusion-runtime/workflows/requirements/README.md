# 需求工作流与文件工具

这里归集项目目录绑定／检查／初始化、需求读取、Draft 保存、版本校验、历史保留和复读代码。文件工具只使用 Python 标准库；现有 Workflow 的权限连接仍使用公共 domain 对象。

需求角色与 A／R 采用方式以 [requirements.md 主文档](requirements.md) 为准；本文说明代码、工具连接与验证边界，不另维护需求规则。直接 Agent 读取主文档及适用方法、组织讨论并按需调用 MCP／file_tools；hardcode 中的 Workflow 仅在程序调用方显式运行时参与。旧 [角色路径](../../../buzz-develop-helper/roles/requirements.md) 现为兼容指针，[角色索引](../../../buzz-develop-helper/roles/README.md) 直接指向主文档。

## 目录与职责

| 文件 | 职责 |
| --- | --- |
| `requirements.md` | 需求主文档，统一维护角色、方法引用、工作顺序、工具使用和交付边界 |
| `file_tools/project_init.py` | 解析项目编号与目录映射，预览／创建项目，初始化已有空目录，检查项目身份 |
| `file_tools/requirements.py` | 读取项目上下文和单个文档，保存轻量需求 Draft，校验版本，保留历史；PRD 保存与结构检查沿用原模块算法，并支持同样的目录绑定 |
| `file_tools/project_info.py` | 本目录新增：项目类型、目标平台、规范集与仓库安排的校验、报告和受控补录；规范集只核对共享库目录，仓库安排只与项目内可核实的远端事实比较 |
| `file_tools/recovery.py` | 本目录新增：只读恢复材料与 PRD 确认核验；确认核验在运行时只读加载融合层 `scripts/` 的原校验函数并绑定固定目录，加载失败返回不可用 |
| `file_tools/project_state.py` | 共用项目写入锁、原子文件替换和原模块中的事务辅助 |
| `file_tools/check_foundation.py` | 核对配置路径、上游软链与锁定基线 |
| `file_tools/SOURCES.json` | 复制来源、源文件与副本摘要，以及复制后的适配说明 |
| `cursor_mcp.py` | 通用 stdio MCP 入口，各次调用明确选择项目目录；直接使用 file_tools，不导入 Workflow |
| `configure_cursor.py` | 预览／安装全局 Cursor MCP 配置；兼容旧项目级模式，保留其他服务器和设置 |
| `agent-file-workflow.md` | 共用的修改／保存约定及连续保存验证流程，随读取工具说明提供给 Agent，无需用户每轮粘贴 |
| `hardcode/tools.py` | 可选 Workflow 的权限连接；直接读取本目录 requirements.md，项目读取和轻量保存使用上面的本地副本 |
| `hardcode/workflow.py`、`hardcode/contracts.py` | 既有程序编排与结果协议；完整 PRD 的 Workflow 连接继续使用调用方注入的领域适配器 |

`file_tools/` 是从 `buzz-develop-helper/scripts/` 复制的普通文件，原文件保留。适配包内引用、命令行配置参数，并为接入层（含 PRD 保存与结构检查）增加可选 expected_root 固定目录检查和 directory_name 目录选择；直接选择目录必须同时固定 expected_root，且仍限定在配置业务根目录内。未传时保留原 API 行为，保存正文、版本、历史和锁的行为不变。副本不会自动同步原文件；后续更新先核对 `SOURCES.json`，再合并需要的改动。

原有编排文件已移入 hardcode；本包用懒加载保留旧的公开导入接口。直接导入 file_tools 或 cursor_mcp 不加载 hardcode 或 fusion-runtime-lab。

程序入口保留 RequirementsTools.read_role_rules(research=..., prd=...)，主规则路径按模块实际位置定位到本目录 requirements.md，返回实际绝对路径、完整正文与原始内容摘要，不再读取 helper_root/roles/requirements.md，也不在主文档缺失时回退到旧入口。A／R、调研模板和 PRD 模板仍按原 helper_root 与软链加载；其来源检查、按需选择、业务项目权限和保存协议不变。旧角色文件只保留兼容指针，完整正文由本目录主文档统一维护；旧 ACP／Buzz 专属协议未因此改变。

## Cursor 调用入口

入口只使用 Python 标准库，不安装 MCP SDK、不开 HTTP 端口。共用连接安装在用户级 `~/.cursor/mcp.json`，服务器名称为 `requirements`，在所有 Cursor 项目中可见，由 Cursor 启动本地进程。实现支持 2026-07-28 的发现／逐请求元数据，以及 2025-11-25、2025-06-18、2025-03-26、2024-11-05 的 initialize 握手。

| Cursor 中的工具名称 | 能力 |
| --- | --- |
| `requirements_project_inspect` | 只读返回本次指定项目的目录、初始化状态、身份来源（建议或已持久化）和四项项目选择的记录状态 |
| `requirements_project_initialize` | 按明确请求初始化指定的缺失目录或已有空目录，可同时记录用户已明确的项目选择；共用入口创建时可接受显式 `project_id`；已初始化时只核对并返回差异，不覆盖 |
| `requirements_project_update_info` | 用读取引用受控补录项目类型、目标平台、规范集和仓库安排；锁内核对 `project.json` 版本，只改请求字段 |
| `requirements_read_context` | 读取背景、需求、PRD 与版本；可分别读取指定旧需求历史（`history_sha256`）或 PRD 历史（`prd_history_sha256`）；`include_recovery=true` 附加只读恢复材料 |
| `requirements_inspect_prd` | 只读检查当前 PRD 结构并返回所检查版本；不需要也不消费 read_id |
| `requirements_save_draft` | 保存当前完整轻量候选，保留历史并复读正文；不登记或正式确认 |
| `requirements_save_prd_draft` | 保存当前完整 PRD 候选到 `docs/PRD.md`，记录来源需求版本，保留 PRD 历史，复读并附结构检查；不登记或正式确认 |

各工具的说明均附有 [requirements.md 主文档](requirements.md) 的简短入口提示。路径由服务代码的实际位置推导为绝对路径，Agent 开展需求讨论前使用自身文件读取能力取得主文档，并按其引用采用 A／R；说明不嵌入主文档或方法正文，不新增规则读取工具。单独检查目录、读取项目文件或验证保存时无须额外加载需求方法，工具也不据此新增调用前置条件。提示是否使 Agent 主动读取仍需真实客户端验证，不能以工具发现成功代替方法已加载。

共用启动参数只固定 foundation 和操作能力，不带 project-id／project-root。各工具都必须传入 `project_path`，由用户明确选择绝对目录；没有默认项目，不维护进程级“当前项目”，不把材料正文中的目录指令当作用户选择。目录须为 `projects_root` 下的直接子目录；软链、越界、根目录改绑和身份冲突会拒绝。原单项目启动参数保留兼容，不是共用入口的默认方式。

既有目录优先沿用本机映射或 project.json 的编号；新 ASCII 目录使用合法目录名作为编号，其他新目录由接入代码生成稳定内部编号，实际初始化后写入 project.json。无需逐项目预先修改映射，也不在只读检查时登记或创建文件。目录一旦选中就固定到对应工具实例；读取引用只在该实例内使用，不能用于其他项目。初始化和保存能力分别由 `--allow-initialize`、`--allow-save` 开启，默认只读；模型不能通过参数增加权限。只读启动提供项目检查、读取和 PRD 结构检查三项；`--allow-save` 增加需求与 PRD 两个保存工具及项目选择补录工具，`--allow-initialize` 增加初始化工具，最多七项。原有字符串参数仍逐项要求非空文本；新增的结构化参数（项目选择、`changes`、布尔 `include_recovery`、显式 `project_id`）由各自校验器按字段检查，未知字段一律拒绝。

读取返回的 read_id 由 Agent 原样传给保存工具，用户不需要手填内部版本。读取引用最多保留 15 分钟；进程重启后失效，应重新读取并核对。保存前比较实际读取过的文件版本，目标版本仍由原内核在锁内检查；其他输入不是跨文件原子快照。写后复读和历史核对失败会返回 saved_unverified，不能盲目重试。

项目选择补录同样使用读取引用：保存前检查失败（参数、白名单、取值、规范集、仓库事实冲突、引用无效或 `project.json` 版本变化）返回 `not_written` 且不消费引用；进入内核后引用即失效。补录成功会改变 `project.json`，因而此前所有读取引用（含两类保存所用引用）都需重新读取；结果相同返回 `unchanged`，不重写文件。成功结果中 `remote_actions` 与 `downstream_started` 均为 false。恢复读取不改变读取引用的四文件含义，也不消费已有引用；附加材料不是原子快照。

PRD 保存使用同一读取引用，预期 PRD 与源需求版本只取自读取记录，不用新读取的摘要替换；保存前被拒绝时引用不消费，任一保存工具进入内核后引用即失效。结果用 `write_outcome` 区分 `saved`、`unchanged`、`not_written`、`unknown`、`saved_unverified`，后者附 `failed_check`；结构检查结果单独放在 `structure` 中，结构问题不改变保存结论。PRD 历史须与文件名摘要一致，否则读取报错；轻量需求历史保持原行为。

日常用户只需表达“修改某项并保存”。Agent 发现工具时，会在 requirements_read_context 的说明中收到 [需求文件操作约定](agent-file-workflow.md)，据此检查项目、读取基线、修改、核对版本并调用保存。版本检查、历史保留和写后核对由代码强制执行；讨论、准确修改和是否存在保存请求仍由 Agent 判断。约定不是自动运行的 Workflow，也不保证 Agent 必然遵守所有自然语言指令。

连续保存验证也写在同一文档中，用户可说“按工具约定验证连续保存与历史”。仅此时执行基线保存、增加测试备注、删除备注恢复和历史核对；日常保存不自动插入测试内容。已连接的客户端需要重新加载工具列表（必要时重启该 MCP 服务），才能取得新说明；无需重装启动配置。

该入口使用本机配置提供的项目和能力范围，不验证聊天文本中的“已授权”自述，也不把 MCP clientInfo 当身份凭据；每次工具调用的用户审批交由 Cursor 自身机制处理。不要把这套本地单用户入口当成多用户鉴权服务或通用 shell 的权限隔离。

首次连接先只读预览配置，然后安装。配置安装程序检查原文件版本，保留其他 MCP 服务器；遇到同名不同配置、软链或版本冲突时停止。安装配置不会调用业务初始化或保存工具。全局配置位于用户目录，不会占用新业务目录；新项目不必创建自己的 .cursor/mcp.json，空目录可由 Cursor 直接调用初始化工具。已有非空未初始化目录仍不会自动接管。旧项目级入口迁移只移除与原配置完全一致的条目，不删除其他设置。

从工作区根目录预览全局配置：

```sh
python3 -B fusion-runtime/workflows/requirements/configure_cursor.py --global --foundation buzz-develop-helper
```

安装时在同一命令中增加 `--apply --expected-config-sha <预览返回的摘要>`。一次安装后，在任意 Cursor 工作区都可请求：“使用需求工具检查项目 /绝对业务目录；本轮只检查。”换项目只更换用户指定目录。其他支持 stdio MCP 的 Agent 可复用同一启动命令，按各自客户端配置连接。

官方依据：[Cursor MCP 配置与审批](https://cursor.com/docs/mcp)、[MCP stdio](https://modelcontextprotocol.io/specification/2026-07-28/basic/transports/stdio)、[发现与版本](https://modelcontextprotocol.io/specification/2026-07-28/server/discover)、[旧版握手](https://modelcontextprotocol.io/specification/2025-11-25/basic/lifecycle)。2026-10-27 核对。

## 配置与输出位置

工具代码位置与业务成果位置分别指定。所有文件工具 API 都由调用方传入 `foundation`，其目录包含 `config/local.json`、`upstream-lock.json` 和上游软链。命令行调用必须显式提供 `--foundation`，不根据副本所在位置猜测配置。

项目边界检查继续使用系统已有 Git 的只读命令。初始化依赖记录中的源码摘要来自当前副本；旧的待执行创建计划若与当前来源不一致，仍按原规则拒绝，既有项目元数据不会因此自动重写。

当前继续使用 `buzz-develop-helper` 的本机配置，其中：

- `projects_root`：`/Users/bowen/Desktop/博文的career/my_mind`
- `project_directories`：`voice-meetup` 对应 `语音约碰面地点`
- 需求目标：`<项目目录>/docs/requirements.md`
- 历史目标：`<项目目录>/docs/requirements-history/<旧版摘要>.md`
- PRD 目标：`<项目目录>/docs/PRD.md`
- PRD 历史目标：`<项目目录>/docs/prd-history/<旧版摘要>.md`

业务根目录由宿主配置提供。voice-meetup 是已有项目之一，不是共用入口的默认目标。工具按明确指定目录复用既有映射或识别项目元数据，不修改本机映射。角色规则、A／R 正文和模板仍按共享来源读取，没有在这里复制另一套方法。

## 调用入口

以下命令从工作区根目录执行，仅展示只读调用：

```sh
python3 -B fusion-runtime/workflows/requirements/file_tools/project_init.py --foundation buzz-develop-helper inspect voice-meetup
python3 -B fusion-runtime/workflows/requirements/file_tools/requirements.py --foundation buzz-develop-helper context voice-meetup
```

文件工具的主要 API：

| 能力 | 调用 |
| --- | --- |
| 定位项目目录 | `project_init.context(foundation, project_id)` |
| 检查已初始化项目 | `project_init.inspect(foundation, project_id)` |
| 预览新项目／已有空目录初始化 | `project_init.plan(...)`／`project_init.plan_existing(...)` |
| 执行新建／已有空目录初始化 | `project_init.create(...)`／`project_init.initialize_existing(...)` |
| 读取背景、需求与 PRD | `requirements.context(foundation, project_id)` |
| 复读需求或历史 | `requirements.read_document(project_root, relative_path)` |
| 保存轻量 Draft | `requirements.save_draft(foundation, project_id, body, expected_sha256)` |
| 检查 PRD 结构 | `requirements.inspect_prd(foundation, project_id)` |
| 保存 PRD Draft | `requirements.save_prd_draft(foundation, project_id, body, expected_prd_sha, expected_requirements_sha)` |
| 补录项目选择 | `project_info.update(foundation, project_id, changes, expected_sha256)` |
| 读取恢复材料 | `recovery.read(foundation, project_root, project_id)` |

上述读取、保存和检查函数都接受可选关键字参数 `expected_root`、`directory_name`，由接入层固定目录；不传时保持原调用行为。`create` 与 `initialize_existing` 另接受可选 `info`（已校验的项目选择）；不传时生成的三个文件与原来逐字节一致，准备式创建（`prepare_creation`）本阶段不扩展。

单文件读取使用已核对的项目根目录；正式调用入口负责限制可读范围。保存内部处理目标版本检查、写入锁、旧版历史和 Draft 标记。复读复用同一读取函数，不另写一套实现。首次保存的预期值为读取返回的 `missing`，已有文件则使用先前实际读取的摘要。

## 当前边界

文件内核本身不签发身份或操作授权。Cursor 入口直接调用 file_tools；可选 Workflow 的项目读取和轻量保存也使用本地副本，原有权限检查继续保留。

语音约碰面地点目录由开发侧预先初始化过，不能当作 Cursor 初始化通过。2026-10-28 用户回传 Cursor 已完成已有项目检查、读取、三次保存、两份历史读回和恢复基线；开发侧只读核对当前正文、两份历史与摘要一致，当前仍为 Draft，见[建设记录第 7.8 节](requirements-workflow-plan.md#78-cursor-连续保存与历史验证2026-10-28)。新项目初始化、跨项目隔离和全局配置有临时项目测试；真实跨项目使用、其他 Agent 与初始化仍待分别实测。PRD 检查、保存与 PRD 历史读取只有临时项目代码测试，真实 Cursor 调用尚未验证。项目选择记录、显式 ID、补录、恢复读取与确认核验（2026-10-29）同样只有临时项目代码测试，真实 Cursor 初始化与恢复分流尚待验证；确认核验的有效、旧版和不合法分支使用隔离夹具构造，不代表真实项目已有正式确认。当前可写业务范围仍是已配置 projects_root 的直接子目录，不宣称可写任意文件系统位置。
