"""The public workflow retains its save checks with a mapped Chinese directory."""

import json
from pathlib import Path
import sys

_HERE = Path(__file__).resolve()
if str(_HERE.parent) not in sys.path:
    sys.path.insert(0, str(_HERE.parent))

from test_requirements_workflow_candidate import (
    PROJECT, TASK, CandidateChainTestCase, _agent, _first_turn, _sample,
)
from fusion_runtime.adapters.memory import FakeAgentRunner
from workflows.requirements import Action, SaveReference, Stage, TurnInput, run_turn


class ProjectBindingWorkflowTests(CandidateChainTestCase):
    def setUp(self):
        super().setUp()
        target = self.root.parent / "语音约碰面地点"
        self.root.rename(target)
        self.root = target
        config_path = self.foundation / "config/local.json"
        config = json.loads(config_path.read_text(encoding="utf-8"))
        config["project_directories"] = {PROJECT: target.name}
        config_path.write_text(json.dumps(config, ensure_ascii=False), encoding="utf-8")

    def review(self):
        return run_turn(_first_turn(), None, self.deps(
            FakeAgentRunner([_agent(_sample("candidate"))]),
        )).progress

    @staticmethod
    def save_turn(candidate):
        return TurnInput(TASK, PROJECT, Action.SAVE, "保存这版需求 Draft", save=SaveReference(
            candidate.candidate_id, candidate.body_sha256, candidate.deliverable, "docs/requirements.md",
        ))

    def test_exact_save_and_readback_use_the_bound_directory(self):
        review = self.review()
        runner = FakeAgentRunner()
        saved = run_turn(self.save_turn(review.candidate), review, self.deps(runner))
        self.assertIs(saved.stage, Stage.SAVED, saved.content)
        self.assertEqual(runner.calls, [])
        target = self.root / "docs/requirements.md"
        self.assertEqual(target.read_text(encoding="utf-8"),
                         "---\nstatus: Draft\napproval_verified: false\n---\n\n"
                         + review.candidate.body.strip() + "\n")
        self.assertFalse((self.root.parent / PROJECT).exists())

    def test_changed_bound_file_is_not_overwritten(self):
        review = self.review()
        target = self.root / "docs/requirements.md"
        target.parent.mkdir(exist_ok=True)
        target.write_text("concurrent user revision", encoding="utf-8")
        before = self.tree()
        runner = FakeAgentRunner()
        result = run_turn(self.save_turn(review.candidate), review, self.deps(runner))
        self.assertIsNot(result.stage, Stage.SAVED)
        self.assertEqual(runner.calls, [])
        self.assertEqual(self.tree(), before)
        self.assertIn("未覆盖", result.content)
