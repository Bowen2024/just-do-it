"""Multi-turn dialogue: answers, revisions, pause/resume and saves under a new authorization."""

from __future__ import annotations

import copy
import dataclasses
from datetime import datetime, timezone
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest import mock

_HERE = Path(__file__).resolve()
_WORKSPACE = _HERE.parents[2]
for _path in (
    _WORKSPACE / "fusion-runtime-lab" / "tests",
    _WORKSPACE / "fusion-runtime-lab" / "src",
    _HERE.parents[1],
    _HERE.parent,
):
    if str(_path) not in sys.path:
        sys.path.insert(0, str(_path))

from fusion_runtime.adapters.develop_helper import DevelopHelperDomainTools  # noqa: E402
from fusion_runtime.adapters.memory import FakeAgentRunner  # noqa: E402
from fusion_runtime.domain.approval import ApprovalTrustPolicy  # noqa: E402
from fusion_runtime.domain.errors import AuthorizationError  # noqa: E402
from fusion_runtime.ports.agents import AgentResult  # noqa: E402
from langgraph.project_fixture import (  # noqa: E402
    HELPER_ROOT,
    create_foundation,
    create_project,
)
from test_requirements_workflow_lightweight import (  # noqa: E402
    RecordingDomainTools,
    RecordingTools,
    _rendered as _rendered_requirements,
)
from test_requirements_workflow_save import (  # noqa: E402
    FIRST_MATERIALS,
    MATERIALS,
    PRD_BODY,
    PRD_BODY_B,
    _rendered as _rendered_prd,
    _sha,
)
from workflows.requirements import (  # noqa: E402
    DELIVERABLE_TARGETS,
    Action,
    Answer,
    Candidate,
    Choice,
    ContractError,
    Progress,
    RequirementsTools,
    SaveReference,
    SourceMaterial,
    Stage,
    TurnInput,
    WorkflowDependencies,
    run_turn,
)


FIXTURE = json.loads(
    (_HERE.parent / "fixtures" / "requirements_case.json").read_text(encoding="utf-8")
)
TASK = FIXTURE["task_id"]
PROJECT = FIXTURE["project_id"]
NOW = datetime(2026, 10, 22, 11, 0, tzinfo=timezone.utc)
TURNS = {t["turn_id"]: t for t in FIXTURE["turns"]}
SAMPLES = FIXTURE["role_result_samples"]
FAIRNESS = SAMPLES["questions"]["payload"]["questions"][0]
BODY = SAMPLES["candidate"]["payload"]["body"]
# Test material: a revision adding the address-edit idea as a pending extension.
REVISED_BODY = (
    BODY.rstrip()
    + "\n\n## 待讨论扩展\n- 识别错地址后直接修改、不重新录音：待讨论，未纳入本次范围。\n"
)
EDIT_QUESTION = {
    "question_id": "q-edit-address",
    "text": "识别错地址后，是否允许直接修改而不重新录音？",
    "reason": "影响确认步骤、失败后的继续方式和验收范围。",
    "options": [
        {"label": "直接修改", "impact": "增加地址编辑入口，范围扩大。"},
        {"label": "重新录音", "impact": "沿用原流程，不增加新入口。"},
    ],
}
REQUIREMENTS = "docs/requirements.md"
PRD = "docs/PRD.md"
JSON_INPUTS = frozenset(
    {"materials", "project_documents", "progress", "material_changes", "turn_answers", "result_protocol"}
)


def _package(kind: str, **fields) -> AgentResult:
    package = copy.deepcopy(SAMPLES[kind])
    payload = fields.pop("payload", None)
    package.update(fields)
    if payload is not None:
        package["payload"].update(payload)
    return AgentResult(candidate_body=json.dumps(package, ensure_ascii=False))


def _revised(
    body: str = REVISED_BODY,
    deliverable: str = "requirements",
    changes: tuple[str, ...] = ("新增待讨论扩展：识别错地址后直接修改",),
) -> AgentResult:
    return _package(
        "candidate", changes=list(changes), payload={"deliverable": deliverable, "body": body}
    )


def _refs(*materials: SourceMaterial) -> list[dict]:
    return [{"source_id": m.source_id, "version": m.version} for m in materials]


def _turn(action: Action, utterance: str = "继续", **fields) -> TurnInput:
    return TurnInput(TASK, PROJECT, action, utterance, **fields)


def _first(materials: tuple = FIRST_MATERIALS) -> TurnInput:
    return _turn(Action.ANALYZE, TURNS["t1-analyze"]["utterance"], materials=materials)


def _answer(*answers: Answer, **fields) -> TurnInput:
    return _turn(Action.ANSWER, "回答问题", answers=answers, **fields)


def _revise(utterance: str = TURNS["t3-revise"]["utterance"], **fields) -> TurnInput:
    return _turn(Action.REVISE, utterance, **fields)


def _reference(candidate: Candidate) -> SaveReference:
    return SaveReference(
        candidate.candidate_id,
        candidate.body_sha256,
        candidate.deliverable,
        DELIVERABLE_TARGETS[candidate.deliverable],
    )


def _save(candidate: Candidate) -> TurnInput:
    return _turn(Action.SAVE, "保存当前这版", save=_reference(candidate))


def _inputs(request) -> dict:
    return {k: json.loads(v) if k in JSON_INPUTS else v for k, v in request.inputs.items()}


class DialogueTestCase(unittest.TestCase):
    def setUp(self) -> None:
        temp = tempfile.TemporaryDirectory(prefix="req-wf-s5-")
        self.addCleanup(temp.cleanup)
        self.foundation = create_foundation(Path(temp.name))
        self.root = create_project(self.foundation, PROJECT, "语音约碰面地点测试项目")
        self.domain = RecordingDomainTools(
            DevelopHelperDomainTools(
                foundation=self.foundation,
                helper_root=HELPER_ROOT,
                approval_policy=ApprovalTrustPolicy.deny_all(),
                runtime_authority="req-wf-s5-test",
            )
        )
        kernel = self.fresh_tools().inner._requirements
        patcher = mock.patch.object(kernel, "save_draft", wraps=kernel.save_draft)
        self.kernel_save = patcher.start()
        self.addCleanup(patcher.stop)

    def fresh_tools(self) -> RecordingTools:
        return RecordingTools(RequirementsTools(foundation=self.foundation, helper_root=HELPER_ROOT))

    def deps(self, runner, tools, **overrides) -> WorkflowDependencies:
        values = {
            "allowed_projects": frozenset({PROJECT}),
            "task_projects": {TASK: PROJECT},
            "agent_runner": runner,
            "tools": tools,
            "domain_tools": self.domain,
            "clock": lambda: NOW,
        }
        values.update(overrides)
        return WorkflowDependencies(**values)

    def tree(self) -> dict[str, str]:
        return {
            path.relative_to(self.root).as_posix(): (
                "dir" if path.is_dir() else _sha(path.read_bytes())
            )
            for path in sorted(self.root.rglob("*"))
        }

    def write(self, relative: str, text: str) -> bytes:
        path = self.root / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")
        return path.read_bytes()

    def prd_saves(self) -> int:
        return sum(1 for call in self.domain.calls if call[0] == "save_prd_draft")

    def talk(self, turn: TurnInput, progress: Progress | None, result: AgentResult):
        """One dialogue turn with fresh dependencies: one role call, reads only, no writes."""

        runner = FakeAgentRunner([result])
        tools = self.fresh_tools()
        before, saves, domain_calls = self.tree(), self.kernel_save.call_count, len(self.domain.calls)
        outcome = run_turn(turn, progress, self.deps(runner, tools))
        self.assertEqual(len(runner.calls), 1)
        self.assertEqual(tools.names(), ["read_role_rules", "read_project"])
        self.assertEqual(self.tree(), before)
        self.assertEqual(self.kernel_save.call_count, saves)
        self.assertEqual(len(self.domain.calls), domain_calls)
        self.assertIsNone(outcome.progress.save_reference)
        request, context = runner.calls[0]
        return outcome, _inputs(request), context

    def quiet(self, turn: TurnInput, progress: Progress):
        """A pause or resume turn: no role call, no tool call, no file change."""

        runner = FakeAgentRunner([_package("candidate")])
        tools = self.fresh_tools()
        before, saves, domain_calls = self.tree(), self.kernel_save.call_count, len(self.domain.calls)
        outcome = run_turn(turn, progress, self.deps(runner, tools))
        self.assertEqual((runner.calls, tools.calls), ([], []))
        self.assertEqual(self.tree(), before)
        self.assertEqual(self.kernel_save.call_count, saves)
        self.assertEqual(len(self.domain.calls), domain_calls)
        self.assertEqual(outcome.tool_results, ())
        return outcome

    def assert_rejected(self, error, turn: TurnInput, progress: Progress | None, **deps) -> None:
        runner = FakeAgentRunner([_package("candidate")])
        tools = self.fresh_tools()
        before, saves, domain_calls = self.tree(), self.kernel_save.call_count, len(self.domain.calls)
        with self.assertRaises(error):
            run_turn(turn, progress, self.deps(runner, tools, **deps))
        self.assertEqual((runner.calls, tools.calls), ([], []))
        self.assertEqual(self.tree(), before)
        self.assertEqual(self.kernel_save.call_count, saves)
        self.assertEqual(len(self.domain.calls), domain_calls)

    def save(self, progress: Progress):
        runner = FakeAgentRunner([_package("candidate")])
        result = run_turn(_save(progress.candidate), progress, self.deps(runner, self.fresh_tools()))
        self.assertEqual(runner.calls, [])
        self.assertIs(result.stage, Stage.SAVED, result.content)
        return result

    def asked(self) -> Progress:
        return self.talk(_first(), None, _package("questions"))[0].progress

    def review(self, result: AgentResult | None = None) -> Progress:
        outcome = self.talk(_first(), None, result or _package("candidate"))[0]
        self.assertIs(outcome.stage, Stage.CANDIDATE_REVIEW)
        return outcome.progress


class AnswerFlowTest(DialogueTestCase):
    def test_question_answer_candidate_carries_history_and_keeps_the_choice(self) -> None:
        asked = self.asked()
        self.assertEqual(asked.materials, FIRST_MATERIALS)
        answer = Answer("q-fairness", TURNS["t2-answer"]["answers"][0]["text"], option="地理中点")
        result, inputs, context = self.talk(_answer(answer), asked, _package("candidate"))

        self.assertEqual(inputs["action"], "answer")
        self.assertEqual(
            [(m["source_id"], m["version"], m["body"]) for m in inputs["materials"]],
            [(m.source_id, m.version, m.body) for m in FIRST_MATERIALS],
        )
        self.assertEqual(
            inputs["material_changes"],
            {"inherited": True, "added": [], "removed": [], "changed": []},
        )
        answer_view = {"question_id": "q-fairness", "text": answer.text, "option": "地理中点", "replaces": None}
        self.assertEqual(inputs["turn_answers"], [answer_view])
        view = inputs["progress"]
        self.assertEqual(view["previous_stage"], "waiting_answer")
        self.assertEqual(view["understanding"], asked.understanding)
        self.assertEqual(
            [
                (q["question_id"], q["text"], q["reason"], q["options"], q["status"])
                for q in view["questions"]
            ],
            [("q-fairness", FAIRNESS["text"], FAIRNESS["reason"], FAIRNESS["options"], "user_chose")],
        )
        self.assertEqual(view["answers"], [answer_view])
        self.assertEqual(
            view["user_choices"],
            [{"subject": FAIRNESS["text"], "value": "地理中点", "question_id": "q-fairness"}],
        )
        self.assertEqual(view["open_items"], SAMPLES["questions"]["open_items"])
        self.assertIsNone(view["candidate"])
        self.assertEqual(
            inputs["result_protocol"]["source_refs"]["allowed"], _refs(*FIRST_MATERIALS)
        )
        for forbidden in ("save_reference", "save_results", "grant", "writable", "authoriz"):
            self.assertNotIn(forbidden, json.dumps(view))
        grant = context.capability_grant
        self.assertEqual((context.step_id, grant.assigned_role), ("N03", "requirements"))
        self.assertEqual((grant.allowed_side_effects, grant.writable_paths), (frozenset(), frozenset()))

        progress = result.progress
        self.assertIs(result.stage, Stage.CANDIDATE_REVIEW)
        self.assertEqual(progress.answers, (answer,))
        self.assertEqual(progress.choices, (Choice(FAIRNESS["text"], "地理中点", "q-fairness"),))
        self.assertEqual([q.question_id for q in progress.questions], ["q-fairness"])
        self.assertEqual(progress.materials, FIRST_MATERIALS)
        candidate = progress.candidate
        self.assertEqual((candidate.revision, candidate.revises), (1, None))
        self.assertEqual(candidate.baseline.materials, tuple(m.input_version for m in FIRST_MATERIALS))
        self.assertIn("选择：地理中点", result.content)
        self.assertEqual(result.next_actions, {Action.REVISE, Action.SAVE, Action.PAUSE})

        direct = self.review()
        self.assertNotEqual(direct.candidate.candidate_id, candidate.candidate_id)
        again = self.talk(_answer(answer), asked, _package("candidate"))[0]
        self.assertEqual(again.progress.candidate.candidate_id, candidate.candidate_id)

    def test_second_question_round_keeps_earlier_answers_and_links_new_questions(self) -> None:
        asked = self.asked()
        vague = Answer("q-fairness", "看情况吧，都可以。")
        second, inputs, _ = self.talk(
            _answer(vague), asked, _package("questions", payload={"questions": [FAIRNESS, EDIT_QUESTION]})
        )
        self.assertIs(second.stage, Stage.WAITING_ANSWER)
        self.assertEqual([q.question_id for q in second.progress.questions], ["q-fairness", "q-edit-address"])
        self.assertEqual(second.progress.answers, (vague,))
        self.assertEqual(second.progress.choices, ())
        self.assertEqual(inputs["progress"]["questions"][0]["status"], "answered_needs_clarification")
        self.assertIn("未选择选项，保留待澄清", second.content)
        self.assertIn(EDIT_QUESTION["text"], second.content)

        explicit = Answer("q-fairness", "就按地理中点。", option="地理中点")
        edit = Answer("q-edit-address", "先作为待讨论扩展记录。")
        final, inputs, _ = self.talk(_answer(explicit, edit), second.progress, _package("candidate"))
        self.assertIs(final.stage, Stage.CANDIDATE_REVIEW)
        replaced = Answer("q-fairness", "就按地理中点。", "地理中点", replaces=vague.text)
        self.assertEqual(final.progress.answers, (replaced, edit))
        self.assertEqual(
            final.progress.choices, (Choice(FAIRNESS["text"], "地理中点", "q-fairness"),)
        )
        self.assertEqual(inputs["progress"]["answers"][0]["replaces"], vague.text)
        self.assertEqual(
            {q["question_id"]: q["status"] for q in inputs["progress"]["questions"]},
            {"q-fairness": "user_chose", "q-edit-address": "answered_needs_clarification"},
        )
        self.assertIn(f"替换原回答：{vague.text}", final.content)

        follow_up = _package("questions", payload={"questions": [EDIT_QUESTION]})
        waiting = self.talk(_answer(explicit), second.progress, follow_up)[0].progress
        self.assertEqual(waiting.answers, (replaced,))
        repeated = self.talk(_answer(explicit), waiting, follow_up)[0].progress
        self.assertEqual(repeated.answers, (replaced,))
        self.assertEqual(repeated.choices, waiting.choices)

    def test_invalid_answer_references_are_rejected_before_any_call(self) -> None:
        asked = self.asked()
        review = self.review()
        cases = {
            "unknown_question": (_answer(Answer("q-unknown", "地理中点")), asked),
            "unknown_option": (_answer(Answer("q-fairness", "步行", option="步行距离")), asked),
            "answer_at_review": (_answer(Answer("q-fairness", "地理中点")), review),
        }
        for name, (turn, progress) in cases.items():
            with self.subTest(case=name):
                self.assert_rejected(ContractError, turn, progress)
        with self.assertRaises(ContractError):
            _answer(Answer("q-fairness", "出行时间", replaces="地理中点"))

    def test_role_cannot_silently_reuse_a_question_id_or_reask_a_chosen_question(self) -> None:
        chosen = self.talk(
            _answer(Answer("q-fairness", "地理中点", option="地理中点")),
            self.asked(),
            _package("questions", payload={"questions": [EDIT_QUESTION]}),
        )[0].progress
        reused = dict(EDIT_QUESTION, text="识别错地址后，是否需要人工客服介入？")
        cases = {"changed_meaning": reused, "chosen_again": FAIRNESS}
        edit = Answer("q-edit-address", "先记录")
        for name, question in cases.items():
            with self.subTest(case=name):
                result, _, _ = self.talk(
                    _answer(edit), chosen, _package("questions", payload={"questions": [question]})
                )
                self.assertIs(result.stage, Stage.BLOCKED)
                self.assertIn("未形成候选", result.content)
                self.assertEqual(result.progress.questions, chosen.questions)
                self.assertEqual(result.progress.answers, (*chosen.answers, edit))
                self.assertEqual(result.progress.choices, chosen.choices)
                self.assertEqual(result.progress.blocked.missing, ("符合结果协议的需求角色返回",))


class ReviseTest(DialogueTestCase):
    def test_revise_sends_candidate_and_feedback_and_forms_a_revision_on_a_new_baseline(self) -> None:
        review = self.review()
        old = review.candidate
        readme_before = old.baseline.document("README.md").sha256
        readme = self.write("README.md", "# 审阅后更新的 README\n")
        feedback = TURNS["t3-revise"]["utterance"]
        result, inputs, _ = self.talk(_revise(feedback), review, _revised())

        self.assertEqual((inputs["action"], inputs["utterance"]), ("revise", feedback))
        view = inputs["progress"]
        self.assertEqual(view["previous_stage"], "candidate_review")
        self.assertEqual(
            (view["candidate"]["candidate_id"], view["candidate"]["body"], view["candidate"]["revision"]),
            (old.candidate_id, BODY, 1),
        )
        self.assertEqual(view["candidate"]["changes"], list(old.changes))
        self.assertEqual(view["candidate"]["open_items"], list(old.open_items))
        documents = {d["path"]: d for d in inputs["project_documents"]}
        self.assertEqual(documents["README.md"]["content"], readme.decode("utf-8"))

        new = result.progress.candidate
        self.assertIs(result.stage, Stage.CANDIDATE_REVIEW)
        self.assertEqual((new.revision, new.revises), (2, old.candidate_id))
        self.assertNotEqual(new.candidate_id, old.candidate_id)
        self.assertEqual(new.body, REVISED_BODY)
        self.assertEqual(new.changes, ("新增待讨论扩展：识别错地址后直接修改",))
        self.assertEqual(new.open_items, tuple(SAMPLES["candidate"]["open_items"]))
        self.assertEqual(new.baseline.document("README.md").sha256, _sha(readme))
        self.assertEqual(old.baseline.document("README.md").sha256, readme_before)
        self.assertEqual(review.candidate, old)
        check = [r for r in result.tool_results if r.tool == "check_candidate"]
        self.assertEqual(len(check), 1)
        self.assertEqual(
            (check[0].data["revision"], check[0].data["revises"], check[0].data["content_review"]),
            (2, old.candidate_id, "pending_user_review"),
        )
        self.assertIn(f"修订自 {old.candidate_id}", result.content)
        self.assertIn("旧候选的保存授权不适用于本版", result.content)

        again = self.talk(_revise(feedback), review, _revised())[0]
        self.assertEqual(again.progress.candidate.candidate_id, new.candidate_id)

    def test_revision_without_changes_or_without_a_candidate_is_not_accepted(self) -> None:
        review = self.review()
        result, _, _ = self.talk(_revise(), review, _revised(changes=()))
        self.assertIs(result.stage, Stage.BLOCKED)
        self.assertIn("must state its changes", result.content)
        self.assertEqual(result.progress.candidate, review.candidate)
        self.assertNotIn(Action.SAVE, result.next_actions)

        bare = Progress(TASK, PROJECT, Stage.BLOCKED, materials=FIRST_MATERIALS)
        self.assert_rejected(ContractError, _revise(), bare)
        self.assert_rejected(ContractError, _revise(), self.asked())


class AuthorizationAfterRevisionTest(DialogueTestCase):
    def test_old_reference_never_authorizes_a_revision_even_with_the_same_body(self) -> None:
        review = self.review()
        old = review.candidate
        same = self.talk(
            _revise("核对一下，没问题就保持原文"), review, _revised(body=BODY, changes=("按反馈核对后正文不变",))
        )[0].progress
        new = same.candidate
        self.assertEqual(new.body_sha256, old.body_sha256)
        self.assertNotEqual(new.candidate_id, old.candidate_id)
        self.assertEqual(new.revision, 2)

        self.assert_rejected(ContractError, _save(old), same)
        saved = self.save(same)
        self.assertEqual((self.root / REQUIREMENTS).read_bytes(), _rendered_requirements(BODY))
        self.assertEqual(saved.progress.save_results[0].data["candidate_id"], new.candidate_id)

    def test_revisions_of_different_candidates_never_share_an_id(self) -> None:
        first = self.review()
        other = self.review(_revised(changes=("另一份首轮候选",)))
        self.assertNotEqual(first.candidate.candidate_id, other.candidate.candidate_id)
        from_first = self.talk(_revise(), first, _revised())[0].progress
        from_other = self.talk(_revise(), other, _revised())[0].progress
        self.assertEqual(from_first.candidate.body_sha256, from_other.candidate.body_sha256)
        self.assertEqual(from_first.candidate.baseline, from_other.candidate.baseline)
        self.assertNotEqual(from_first.candidate.candidate_id, from_other.candidate.candidate_id)
        self.assert_rejected(ContractError, _save(from_other.candidate), from_first)

    def test_revising_a_saved_draft_sets_its_results_aside(self) -> None:
        review = self.review()
        saved = self.save(review)
        revised, inputs, _ = self.talk(_revise(), saved.progress, _revised())
        progress = revised.progress

        self.assertIs(revised.stage, Stage.CANDIDATE_REVIEW)
        self.assertEqual(inputs["progress"]["previous_stage"], "saved")
        self.assertEqual(
            inputs["progress"]["written_drafts"],
            [{"path": REQUIREMENTS, "candidate_id": review.candidate.candidate_id}],
        )
        self.assertEqual(progress.save_results, ())
        self.assertEqual(progress.prior_save_results, saved.progress.save_results)
        self.assertIsNone(progress.save_reference)
        self.assert_rejected(ContractError, _save(review.candidate), progress)


class MaterialTest(DialogueTestCase):
    def test_materials_are_inherited_or_checked_as_a_complete_new_set(self) -> None:
        asked = self.asked()
        s1, s2 = FIRST_MATERIALS[:2]
        edited = SourceMaterial(s1.source_id, s1.location, s1.version, s1.category, s1.body + "\n补充：只在同城使用。")
        relabelled = SourceMaterial(s2.source_id, s2.location, "v0.3 草稿（2026-10-22）", s2.category, s2.body)
        feedback = next(m for m in MATERIALS if m.source_id == "case01-s7-feedback")
        new_set = (edited, relabelled, *FIRST_MATERIALS[2:4], feedback)

        result, inputs, _ = self.talk(
            _answer(Answer("q-fairness", "地理中点", option="地理中点"), materials=new_set),
            asked,
            _package("questions", payload={"questions": [EDIT_QUESTION]}),
        )
        changes = {
            "inherited": False,
            "added": ["case01-s7-feedback"],
            "removed": ["case01-s9-open"],
            "changed": [
                {"source_id": s1.source_id, "version": [s1.version, s1.version], "body_changed": True},
                {
                    "source_id": s2.source_id,
                    "version": [s2.version, relabelled.version],
                    "body_changed": False,
                },
            ],
        }
        self.assertEqual(inputs["material_changes"], changes)
        check = [r for r in result.tool_results if r.tool == "check_materials"]
        self.assertEqual([dict(r.data) for r in check], [changes])
        self.assertEqual([m["body"] for m in inputs["materials"]], [m.body for m in new_set])
        self.assertEqual(inputs["result_protocol"]["source_refs"]["allowed"], _refs(*new_set))
        self.assertEqual(result.progress.materials, new_set)
        self.assertEqual(result.progress.input_versions, tuple(m.input_version for m in new_set))

        cites = _refs(edited, relabelled, feedback)
        formed, inputs, _ = self.talk(
            _answer(Answer("q-edit-address", "先作为待讨论扩展")),
            result.progress,
            _package("candidate", source_refs=cites),
        )
        self.assertEqual(
            inputs["material_changes"], {"inherited": True, "added": [], "removed": [], "changed": []}
        )
        self.assertEqual([m["body"] for m in inputs["materials"]], [m.body for m in new_set])
        self.assertEqual(
            formed.progress.candidate.baseline.materials, tuple(m.input_version for m in new_set)
        )

        stale = self.talk(
            _answer(Answer("q-edit-address", "先作为待讨论扩展")), result.progress, _package("candidate")
        )[0]
        self.assertIs(stale.stage, Stage.BLOCKED)
        self.assertIn("source_ref was not provided", stale.content)

    def test_task_project_and_material_text_are_checked_before_any_call(self) -> None:
        asked = self.asked()
        answer = Answer("q-fairness", "地理中点", option="地理中点")
        self.assert_rejected(
            ContractError, TurnInput("other-task", PROJECT, Action.ANSWER, "回答", answers=(answer,)), asked
        )
        self.assert_rejected(
            ContractError, TurnInput(TASK, "other-project", Action.ANSWER, "回答", answers=(answer,)), asked
        )
        self.assert_rejected(AuthorizationError, _answer(answer), asked, task_projects={TASK: "other"})
        self.assert_rejected(
            AuthorizationError, _answer(answer), asked, allowed_projects=frozenset({"other"})
        )
        digest_only = dataclasses.replace(asked, materials=())
        self.assertEqual(digest_only.input_versions, asked.input_versions)
        self.assert_rejected(ContractError, _answer(answer), digest_only)
        result = self.talk(_answer(answer, materials=FIRST_MATERIALS), digest_only, _package("candidate"))[0]
        self.assertEqual(result.progress.materials, FIRST_MATERIALS)


class PauseResumeTest(DialogueTestCase):
    def test_pause_and_resume_keep_stage_and_progress_without_any_call(self) -> None:
        asked = self.asked()
        answered = self.talk(
            _answer(Answer("q-fairness", "地理中点", option="地理中点")),
            asked,
            _package("questions", payload={"questions": [EDIT_QUESTION]}),
        )[0].progress
        stages = {
            "waiting_answer": answered,
            "candidate_review": self.review(),
            "researching": self.talk(_first(), None, _package("research"))[0].progress,
            "blocked": self.talk(_first(()), None, _package("blocked"))[0].progress,
        }
        stages["saved"] = self.save(stages["candidate_review"]).progress
        for name, progress in stages.items():
            with self.subTest(stage=name):
                paused = self.quiet(_turn(Action.PAUSE, TURNS["t5-pause"]["utterance"]), progress)
                self.assertIs(paused.stage, Stage.ENDED)
                self.assertIs(paused.progress.resume_stage, progress.stage)
                self.assertEqual(paused.next_actions, {Action.RESUME})
                self.assertEqual(
                    dataclasses.replace(paused.progress, stage=progress.stage, resume_stage=None),
                    progress,
                )
                self.assertIn("已暂停", paused.content)
                resumed = self.quiet(_turn(Action.RESUME), paused.progress)
                self.assertIs(resumed.stage, progress.stage)
                self.assertEqual(resumed.progress, progress)
                self.assertIn("未调用需求角色、未保存，也未重新授权保存", resumed.content)
                self.assert_rejected(ContractError, _turn(Action.PAUSE), paused.progress)

    def test_resume_never_revives_an_old_authorization(self) -> None:
        review = self.review()
        revised = self.talk(_revise(), review, _revised())[0].progress
        back = self.quiet(_turn(Action.RESUME), self.quiet(_turn(Action.PAUSE), revised).progress)
        self.assertIsNone(back.progress.save_reference)
        self.assert_rejected(ContractError, _save(review.candidate), back.progress)

        saved = self.save(back.progress).progress
        back = self.quiet(_turn(Action.RESUME), self.quiet(_turn(Action.PAUSE), saved).progress)
        self.assertEqual(back.next_actions, {Action.REVISE, Action.PAUSE})
        self.assert_rejected(ContractError, _save(saved.candidate), back.progress)

        conflict = self.review(_revised(changes=("另一版",)))
        self.write("README.md", "# 审阅后被改\n")
        refused = run_turn(
            _save(conflict.candidate), conflict, self.deps(FakeAgentRunner(), self.fresh_tools())
        )
        self.assertIs(refused.stage, Stage.BLOCKED)
        back = self.quiet(_turn(Action.RESUME), self.quiet(_turn(Action.PAUSE), refused.progress).progress)
        self.assertIs(back.stage, Stage.BLOCKED)
        self.assertNotIn(Action.SAVE, back.next_actions)
        self.assert_rejected(ContractError, _save(conflict.candidate), back.progress)

    def test_materials_changed_during_a_pause_are_not_absorbed(self) -> None:
        review = self.review()
        paused = self.quiet(_turn(Action.PAUSE), review).progress
        s1 = FIRST_MATERIALS[0]
        edited = (
            SourceMaterial(s1.source_id, s1.location, s1.version, s1.category, s1.body + "\n暂停期间补充。"),
            *FIRST_MATERIALS[1:],
        )
        self.assert_rejected(ContractError, _turn(Action.RESUME, materials=edited), paused)
        self.assert_rejected(ContractError, _turn(Action.PAUSE, materials=edited), review)
        resumed = self.quiet(_turn(Action.RESUME, materials=tuple(reversed(FIRST_MATERIALS))), paused)
        self.assertEqual(resumed.progress, review)

        revised = self.talk(_revise("材料已更新，请按新材料修订", materials=edited), resumed.progress, _revised())[0]
        self.assertEqual(
            revised.progress.candidate.baseline.materials, tuple(m.input_version for m in edited)
        )
        self.assertEqual(review.candidate.baseline.materials, tuple(m.input_version for m in FIRST_MATERIALS))
        self.assert_rejected(ContractError, _save(review.candidate), revised.progress)


class FailureTest(DialogueTestCase):
    def test_runner_errors_block_and_keep_progress_without_retry(self) -> None:
        asked = self.asked()
        answer = Answer("q-fairness", "地理中点", option="地理中点")

        class FailingRunner(FakeAgentRunner):
            def run(runner, request, context):
                runner.calls.append((request, context))
                raise RuntimeError("runner offline")

        runner = FailingRunner()
        before = self.tree()
        result = run_turn(_answer(answer), asked, self.deps(runner, self.fresh_tools()))
        self.assertEqual(len(runner.calls), 1)
        self.assertEqual(self.tree(), before)
        self.assertIs(result.stage, Stage.BLOCKED)
        self.assertIn("需求角色调用失败", result.content)
        self.assertIn("未自动重试", result.content)
        self.assertIn("runner offline", result.content)
        self.assertEqual(
            [(r.tool, r.ok) for r in result.tool_results],
            [("check_materials", True), ("read_baseline", True), ("requirements_role", False)],
        )
        progress = result.progress
        self.assertEqual(progress.questions, asked.questions)
        self.assertEqual(progress.answers, (answer,))
        self.assertEqual(len(progress.choices), 1)
        self.assertEqual(progress.materials, FIRST_MATERIALS)
        self.assertEqual(progress.understanding, asked.understanding)
        self.assertEqual(progress.blocked.missing, ("需求角色的本轮结果",))

        resumed, inputs, _ = self.talk(_turn(Action.ANALYZE, "继续分析"), progress, _package("candidate"))
        self.assertIs(resumed.stage, Stage.CANDIDATE_REVIEW)
        self.assertEqual(inputs["progress"]["previous_stage"], "blocked")
        self.assertEqual(inputs["progress"]["answers"][0]["option"], "地理中点")
        self.assertIsNone(resumed.progress.blocked)

    def test_invalid_results_and_read_failures_keep_the_candidate(self) -> None:
        review = self.review()
        invalid, _, _ = self.talk(_revise(), review, AgentResult(candidate_body="不是 JSON"))
        self.assertIs(invalid.stage, Stage.BLOCKED)
        self.assertIn("未形成候选", invalid.content)
        self.assertEqual(invalid.progress.candidate, review.candidate)
        self.assertEqual(invalid.progress.materials, review.materials)
        self.assertNotIn(Action.SAVE, invalid.next_actions)

        (self.root / "docs" / "PRD.md").mkdir(parents=True)
        runner = FakeAgentRunner([_revised()])
        result = run_turn(_revise(), review, self.deps(runner, self.fresh_tools()))
        self.assertEqual(runner.calls, [])
        self.assertIs(result.stage, Stage.BLOCKED)
        self.assertIn("未调用需求角色", result.content)
        self.assertEqual(
            [(r.tool, r.ok) for r in result.tool_results],
            [("check_materials", True), ("read_baseline", False)],
        )
        self.assertEqual(result.progress.candidate, review.candidate)
        self.assertEqual(result.progress.blocked.missing, ("项目文档、角色规则与适用方法的完整读取",))


class ResearchAndBlockedDetailTest(DialogueTestCase):
    def test_research_request_and_blocked_details_stay_in_progress(self) -> None:
        researching = self.talk(_first(), None, _package("research"))[0].progress
        sample = SAMPLES["research"]["payload"]
        research = researching.research
        self.assertEqual(
            {
                "decision": research.decision,
                "questions": list(research.questions),
                "scope": research.scope,
                "known_basis": list(research.known_basis),
                "stop_condition": research.stop_condition,
            },
            sample,
        )
        back = self.quiet(_turn(Action.RESUME), self.quiet(_turn(Action.PAUSE), researching).progress)
        self.assertEqual(back.progress.research, research)
        self.assertIn(sample["decision"], back.content)
        runner, tools = FakeAgentRunner([_package("candidate")]), self.fresh_tools()
        before = self.tree()
        unconfigured = run_turn(_turn(Action.RESEARCH, "去查"), researching, self.deps(runner, tools))
        self.assertEqual((runner.calls, tools.calls), ([], []))
        self.assertEqual(self.tree(), before)
        self.assertIs(unconfigured.stage, Stage.RESEARCHING)
        record = unconfigured.progress.research_records[-1]
        self.assertEqual((record.called, record.result.outcome.value), (False, "unavailable"))
        self.assertEqual(unconfigured.progress.research, research)

        blocked = self.talk(_first(()), None, _package("blocked"))[0].progress
        report = SAMPLES["blocked"]["payload"]
        self.assertEqual(
            (list(blocked.blocked.missing), blocked.blocked.resume_condition),
            (report["missing"], report["resume_condition"]),
        )
        result, inputs, _ = self.talk(
            _turn(Action.ANALYZE, "材料补上了", materials=FIRST_MATERIALS), blocked, _package("candidate")
        )
        self.assertEqual(inputs["progress"]["blocked"], report)
        self.assertEqual(
            inputs["material_changes"]["added"], [m.source_id for m in FIRST_MATERIALS]
        )
        self.assertIs(result.stage, Stage.CANDIDATE_REVIEW)
        self.assertIsNone(result.progress.blocked)


class RevisedSaveTest(DialogueTestCase):
    def test_lightweight_revision_is_saved_under_a_new_authorization(self) -> None:
        first = self.save(self.review())
        v1 = (self.root / REQUIREMENTS).read_bytes()
        self.assertEqual(v1, _rendered_requirements(BODY))
        revised = self.talk(_revise(), first.progress, _revised())[0].progress
        self.assertEqual((self.root / REQUIREMENTS).read_bytes(), v1)

        second = self.save(revised)
        self.assertEqual((self.root / REQUIREMENTS).read_bytes(), _rendered_requirements(REVISED_BODY))
        history = self.root / "docs" / "requirements-history"
        self.assertEqual({p.name: p.read_bytes() for p in history.iterdir()}, {f"{_sha(v1)}.md": v1})
        self.assertEqual(self.kernel_save.call_count, 2)
        self.assertEqual(second.progress.save_results[0].data["candidate_id"], revised.candidate.candidate_id)
        self.assertEqual(
            second.progress.save_results[0].data["history"],
            f"docs/requirements-history/{_sha(v1)}.md",
        )
        self.assertEqual(second.progress.prior_save_results, first.progress.save_results)

    def test_prd_revision_is_saved_under_a_new_authorization(self) -> None:
        review = self.review(_revised(body=PRD_BODY, deliverable="prd", changes=("首次形成 PRD 候选",)))
        first = self.save(review)
        v1 = (self.root / PRD).read_bytes()
        self.assertEqual(v1, _rendered_prd(PRD_BODY))
        revised = self.talk(
            _revise("候选地点改为三个"), first.progress, _revised(body=PRD_BODY_B, deliverable="prd")
        )[0].progress
        self.assertEqual(self.prd_saves(), 1)

        second = self.save(revised)
        self.assertEqual((self.root / PRD).read_bytes(), _rendered_prd(PRD_BODY_B))
        history = self.root / "docs" / "prd-history"
        self.assertEqual({p.name: p.read_bytes() for p in history.iterdir()}, {f"{_sha(v1)}.md": v1})
        self.assertEqual(self.prd_saves(), 2)
        inspect = [r for r in second.progress.save_results if r.tool == "inspect_prd"]
        self.assertTrue(inspect[0].ok)
        self.assertEqual(self.kernel_save.call_count, 0)


class FreshDependenciesTest(DialogueTestCase):
    def test_the_whole_dialogue_continues_only_from_the_returned_progress(self) -> None:
        t2 = TURNS["t2-answer"]["answers"][0]
        asked = self.asked()
        answer = Answer(t2["question_id"], t2["text"], option="地理中点")
        formed = self.talk(_answer(answer), asked, _package("candidate"))[0].progress
        revised, inputs, _ = self.talk(_revise(), formed, _revised())
        self.assertEqual(inputs["progress"]["answers"][0]["text"], t2["text"])
        self.assertEqual(inputs["progress"]["candidate"]["candidate_id"], formed.candidate.candidate_id)
        paused = self.quiet(_turn(Action.PAUSE, TURNS["t5-pause"]["utterance"]), revised.progress)
        resumed = self.quiet(_turn(Action.RESUME), paused.progress)
        saved = self.save(resumed.progress)

        progress = saved.progress
        self.assertEqual(progress.answers, (answer,))
        self.assertEqual([c.value for c in progress.choices], ["地理中点"])
        self.assertEqual(progress.materials, FIRST_MATERIALS)
        self.assertEqual(progress.candidate.revises, formed.candidate.candidate_id)
        self.assertEqual((self.root / REQUIREMENTS).read_bytes(), _rendered_requirements(REVISED_BODY))
        self.assertEqual(self.kernel_save.call_count, 1)


if __name__ == "__main__":
    unittest.main()
