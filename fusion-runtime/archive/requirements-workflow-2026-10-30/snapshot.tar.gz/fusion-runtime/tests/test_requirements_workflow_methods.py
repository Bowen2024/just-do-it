"""Method loading uses the explicit upstream link and fails before role execution."""

from __future__ import annotations

import dataclasses
import json
import os
from pathlib import Path
import sys
import unittest
from unittest import mock

_HERE = Path(__file__).resolve()
if str(_HERE.parent) not in sys.path:
    sys.path.insert(0, str(_HERE.parent))

from test_requirements_workflow_candidate import (  # noqa: E402
    HELPER_ROOT, PROJECT, RULES_PATH, TASK, CandidateChainTestCase, RecordingTools,
    _agent, _first_turn, _sample, _sha, create_foundation,
)
from fusion_runtime.adapters.memory import FakeAgentRunner  # noqa: E402
import check_foundation  # noqa: E402
from workflows.requirements.hardcode import tools as rule_tools  # noqa: E402
from workflows.requirements import (  # noqa: E402
    Action, ContractError, ReadFailedError, RequirementsTools,
    ResearchOutcome, ResearchResult, Stage, TurnInput, run_turn,
)

METHOD_PATHS = {
    "A": "upstream/develop-helper/harness-core/skills/sdd-product-design/phase-A.md",
    "R": "upstream/develop-helper/harness-core/skills/sdd-product-design/phase-R.md",
    "research_template": "upstream/develop-helper/harness-core/skills/sdd-product-design/references/research-template.md",
    "prd_template": "capabilities/requirements-prd-template.md",
}


class MethodTestCase(CandidateChainTestCase):
    def setUp(self) -> None:
        super().setUp()
        # Isolated source and lock: failure probes never alter the real upstream.
        self.helper = create_foundation(self.foundation.parent / "methods")
        self.upstream = (self.helper / "upstream/develop-helper").resolve()
        (self.helper / "scripts").symlink_to(HELPER_ROOT / "scripts", target_is_directory=True)
        self.rule_path = self.helper.parent / "requirements-main.md"
        self.rule_path.write_bytes(RULES_PATH.read_bytes())
        source = mock.patch.object(rule_tools, "ROLE_RULES_PATH", str(self.rule_path))
        source.start()
        self.addCleanup(source.stop)
        for key, relative in METHOD_PATHS.items():
            path = self.helper / relative
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(f"# {key}\r\n\r\n测试方法正文：{key}。\r\n", encoding="utf-8")
        self.lock_sources()
        self.tools = RecordingTools(RequirementsTools(foundation=self.foundation, helper_root=self.helper))

    def lock_sources(self) -> None:
        (self.helper / "upstream-lock.json").write_text(
            json.dumps(check_foundation.snapshot(self.upstream)), encoding="utf-8",
        )

    def analyze(self, *, progress=None, turn=None, package=None, **options):
        runner = FakeAgentRunner([_agent(package or _sample("candidate"))])
        deps = dataclasses.replace(self.deps(runner), **options)
        before = self.tree()
        self.tools.calls.clear()
        outcome = run_turn(turn or _first_turn(), progress, deps)
        self.assertEqual(self.tree(), before)
        return outcome, runner

    def assert_blocked(self, fragment: str, **options) -> None:
        outcome, runner = self.analyze(**options)
        self.assertEqual(runner.calls, [])
        self.assertEqual(self.tools.calls, ["read_role_rules"])
        self.assertIs(outcome.stage, Stage.BLOCKED)
        self.assertIsNone(outcome.progress.candidate)
        self.assertIsNone(outcome.progress.save_reference)
        self.assertEqual(outcome.progress.save_results, ())
        self.assertEqual([(r.tool, r.ok) for r in outcome.tool_results], [("read_baseline", False)])
        self.assertIn(fragment, outcome.content)
        self.assertIn("未调用需求角色", outcome.content)

    def assert_sources(self, outcome, runner, keys):
        self.assertEqual(len(runner.calls), 1)
        inputs = runner.calls[0][0].inputs
        sources = json.loads(inputs["method_sources"])
        self.assertEqual([m["key"] for m in sources], keys)
        for source in sources:
            relative = METHOD_PATHS[source["key"]]
            raw = (self.helper / relative).read_bytes()
            self.assertEqual(source, {
                "key": source["key"], "path": relative,
                "body": raw.decode("utf-8"), "sha256": _sha(raw),
            })
        read = next(r for r in outcome.tool_results if r.tool == "read_baseline")
        self.assertEqual(read.data["method_sources"], {m["path"]: m["sha256"] for m in sources})
        rules = self.rule_path.read_bytes()
        self.assertEqual(inputs["role_rules_path"], str(self.rule_path))
        self.assertEqual(inputs["role_rules"], rules.decode("utf-8"))
        self.assertEqual(inputs["role_rules_sha256"], _sha(rules))
        _, context = runner.calls[0]
        self.assertEqual(context.capability_grant.allowed_side_effects, frozenset())
        self.assertEqual(context.capability_grant.writable_paths, frozenset())
        return sources


class MethodSelectionTest(MethodTestCase):
    def test_real_sources_match_the_explicit_link_and_fusion_template(self):
        tools = RequirementsTools(foundation=self.foundation, helper_root=HELPER_ROOT)
        with mock.patch.object(rule_tools, "ROLE_RULES_PATH", str(RULES_PATH)):
            rules = tools.read_role_rules(research=True, prd=True)
        raw_rules = RULES_PATH.read_bytes()
        self.assertEqual((rules.path, rules.body, rules.sha256), (
            str(RULES_PATH), raw_rules.decode("utf-8"), _sha(raw_rules),
        ))
        self.assertEqual([m.key for m in rules.methods], list(METHOD_PATHS))
        for source in rules.methods:
            raw = (HELPER_ROOT / METHOD_PATHS[source.key]).read_bytes()
            self.assertEqual((source.path, source.body, source.sha256), (
                METHOD_PATHS[source.key], raw.decode("utf-8"), _sha(raw),
            ))

    def test_default_loads_only_a_with_exact_body_and_digest(self):
        outcome, runner = self.analyze()
        self.assert_sources(outcome, runner, ["A"])

    def test_agent_gets_main_document_bytes_and_never_falls_back_to_legacy_rules(self):
        legacy = self.helper / "roles/requirements.md"
        legacy.parent.mkdir()
        legacy.write_text("# 旧角色兼容入口\n只有指针，不是主规则正文。\n", encoding="utf-8")
        raw = "# 新主文档\r\n\r\n主规则测试正文：继承选择。\r\n".encode("utf-8")
        self.rule_path.write_bytes(raw)
        outcome, runner = self.analyze()
        self.assert_sources(outcome, runner, ["A"])
        self.assertEqual(runner.calls[0][0].inputs["role_rules"].encode("utf-8"), raw)
        self.assertNotIn("只有指针", runner.calls[0][0].inputs["role_rules"])
        self.rule_path.unlink()
        self.assert_blocked(str(self.rule_path))

    def test_exact_byte_limit_is_read_without_truncation(self):
        raw = "方".encode("utf-8") * ((128 * 1024) // 3) + b"\n\n"
        self.assertEqual(len(raw), 128 * 1024)
        (self.helper / METHOD_PATHS["A"]).write_bytes(raw)
        self.lock_sources()
        outcome, runner = self.analyze()
        sources = self.assert_sources(outcome, runner, ["A"])
        self.assertEqual(sources[0]["body"].encode("utf-8"), raw)

    def test_explicit_selection_matrix(self):
        for research, prd in ((True, False), (False, True), (True, True)):
            with self.subTest(research=research, prd=prd):
                outcome, runner = self.analyze(
                    include_research_methods=research, include_prd_template=prd,
                )
                keys = ["A"] + (["R", "research_template"] if research else [])
                self.assert_sources(outcome, runner, keys + (["prd_template"] if prd else []))

    def test_unselected_optional_sources_are_not_read(self):
        for key in ("R", "research_template", "prd_template"):
            (self.helper / METHOD_PATHS[key]).unlink()
        self.lock_sources()
        outcome, runner = self.analyze()
        self.assert_sources(outcome, runner, ["A"])

    def test_research_round_trip_loads_r_for_following_analysis(self):
        requested, first = self.analyze(package=_sample("research"))
        self.assert_sources(requested, first, ["A"])
        callback = mock.Mock(return_value=ResearchResult(
            ResearchOutcome.INSUFFICIENT, limitations=("测试材料：证据不足",), test_material=True,
        ))
        quiet_runner = FakeAgentRunner()
        self.tools.calls.clear()
        before = self.tree()
        researched = run_turn(
            TurnInput(TASK, PROJECT, Action.RESEARCH, "调研"), requested.progress,
            dataclasses.replace(self.deps(quiet_runner), research=callback, research_budget=1),
        )
        callback.assert_called_once_with(requested.progress.research)
        self.assertEqual((self.tools.calls, quiet_runner.calls), ([], []))
        self.assertEqual(self.tree(), before)
        outcome, runner = self.analyze(progress=researched.progress)
        self.assert_sources(outcome, runner, ["A", "R", "research_template"])
        revised = _sample("candidate")
        revised["changes"] = ["测试材料：修改措辞"]
        again, runner = self.analyze(
            progress=outcome.progress, package=revised,
            turn=TurnInput(TASK, PROJECT, Action.REVISE, "修改措辞"),
        )
        self.assertIsNone(again.progress.research)
        self.assert_sources(again, runner, ["A", "R", "research_template"])

    def test_existing_prd_candidate_loads_template_for_revision(self):
        prd = _sample("candidate")
        prd["payload"]["deliverable"] = "prd"
        first, _ = self.analyze(package=prd)
        prd["changes"] = ["测试材料：修改 PRD"]
        outcome, runner = self.analyze(
            progress=first.progress, package=prd,
            turn=TurnInput(TASK, PROJECT, Action.REVISE, "修改 PRD"),
        )
        self.assert_sources(outcome, runner, ["A", "prd_template"])

    def test_flags_are_strict_booleans(self):
        for field in ("include_research_methods", "include_prd_template"):
            for value in (0, 1, None, "true", []):
                with self.subTest(field=field, value=value), self.assertRaises(ContractError):
                    dataclasses.replace(self.deps(FakeAgentRunner()), **{field: value})
        for field in ("research", "prd"):
            for value in (0, 1, None, "true", []):
                with self.subTest(field=field, value=value), self.assertRaises(ReadFailedError):
                    self.tools.inner.read_role_rules(**{field: value})


class MethodFailureTest(MethodTestCase):
    def test_method_failure_keeps_previous_candidate_without_save_authority(self):
        review, _ = self.analyze()
        path = self.helper / METHOD_PATHS["A"]
        original = path.read_bytes()
        path.write_bytes(b"\xff")
        self.lock_sources()
        outcome, runner = self.analyze(
            progress=review.progress,
            turn=TurnInput(TASK, PROJECT, Action.REVISE, "修改措辞"),
        )
        self.assertEqual(runner.calls, [])
        self.assertIs(outcome.stage, Stage.BLOCKED)
        self.assertEqual(outcome.progress.candidate, review.progress.candidate)
        self.assertEqual(outcome.progress.materials, review.progress.materials)
        self.assertIsNone(outcome.progress.save_reference)
        self.assertNotIn(Action.SAVE, outcome.next_actions)
        self.assertIn("utf-8", outcome.content)
        path.write_bytes(original)
        self.lock_sources()
        revised = _sample("candidate")
        revised["changes"] = ["测试材料：修改措辞"]
        recovered, runner = self.analyze(progress=outcome.progress, package=revised)
        self.assertIs(recovered.stage, Stage.CANDIDATE_REVIEW)
        self.assertEqual(recovered.progress.candidate.revision, 2)
        self.assertIsNone(recovered.progress.save_reference)
        self.assert_sources(recovered, runner, ["A"])

    def test_broken_upstream_link_blocks(self):
        link = self.helper / "upstream/develop-helper"
        link.unlink()
        link.symlink_to(self.upstream.parent / "absent", target_is_directory=True)
        self.assert_blocked("method sources")

    def test_upstream_must_be_the_configured_explicit_symlink(self):
        link = self.helper / "upstream/develop-helper"
        link.unlink()
        link.mkdir()
        self.assert_blocked("上游入口不是软链")
        link.rmdir()
        link.symlink_to(self.foundation.parent, target_is_directory=True)
        self.assert_blocked("软链目标与配置不一致")

    def test_source_drift_blocks_without_refreshing_lock(self):
        lock = self.helper / "upstream-lock.json"
        locked = lock.read_bytes()
        (self.helper / METHOD_PATHS["A"]).write_text("changed", encoding="utf-8")
        self.assert_blocked("上游版本漂移")
        self.assertEqual(lock.read_bytes(), locked)

    def test_invalid_foundation_metadata_blocks(self):
        for relative in ("config/local.json", "upstream-lock.json"):
            path = self.helper / relative
            original = path.read_bytes()
            for raw in (b"{", b"[]", b"\xff"):
                with self.subTest(path=relative, raw=raw):
                    path.write_bytes(raw)
                    self.assert_blocked("method sources")
            path.write_bytes(original)

    def test_missing_selected_method_blocks(self):
        for key in METHOD_PATHS:
            with self.subTest(key=key):
                path = self.helper / METHOD_PATHS[key]
                raw = path.read_bytes()
                path.unlink()
                self.lock_sources()
                self.assert_blocked("missing or empty", include_research_methods=True, include_prd_template=True)
                path.write_bytes(raw)
                self.lock_sources()

    def test_invalid_selected_method_bodies_block(self):
        for key in METHOD_PATHS:
            path = self.helper / METHOD_PATHS[key]
            original = path.read_bytes()
            for raw, message in ((b"", "empty"), (b" \n\t", "empty"), (b"\xff", "utf-8"), (b"x" * (128 * 1024 + 1), "128 KiB")):
                with self.subTest(key=key, failure=message):
                    path.write_bytes(raw)
                    self.lock_sources()
                    self.assert_blocked(message, include_research_methods=True, include_prd_template=True)
            path.write_bytes(original)
            self.lock_sources()

    def test_method_must_be_an_independent_regular_file(self):
        path = self.helper / METHOD_PATHS["A"]
        raw = path.read_bytes()
        path.unlink()
        path.mkdir()
        self.lock_sources()
        self.assert_blocked("独立普通文件")
        path.rmdir()
        outside = self.helper.parent / "external.md"
        outside.write_bytes(raw)
        path.symlink_to(outside)
        self.lock_sources()
        self.assert_blocked("软链")
        path.unlink()
        os.link(outside, path)
        self.lock_sources()
        self.assert_blocked("独立普通文件")

    def test_symlinked_method_parent_is_rejected(self):
        parent = (self.helper / METHOD_PATHS["A"]).parent
        moved = parent.with_name("moved-product-design")
        parent.rename(moved)
        parent.symlink_to(moved, target_is_directory=True)
        self.lock_sources()
        self.assert_blocked("软链")

    def test_read_errors_and_digest_mismatch_block(self):
        kernel = self.tools.inner._requirements
        for error in (OSError("read denied"), RuntimeError("symlink loop")):
            with self.subTest(error=error), mock.patch.object(kernel, "read_document", side_effect=error):
                self.assert_blocked(str(error))
        with mock.patch.object(kernel, "read_document", return_value={"content": "body", "sha256": "0" * 64}):
            self.assert_blocked("does not match its digest")

    def test_invalid_shared_rules_block(self):
        path = self.rule_path
        for raw, message in ((b"", "empty"), (b" \n\t", "empty"), (b"\xff", "utf-8"), (b"x" * (128 * 1024 + 1), "read limit")):
            with self.subTest(failure=message):
                path.write_bytes(raw)
                self.assert_blocked(message)
        path.unlink()
        self.assert_blocked("regular file")
        path.symlink_to(RULES_PATH)
        self.assert_blocked("regular file")


if __name__ == "__main__":
    unittest.main()
