"""Contract tests for requirements workflow inputs, progress and role results."""

from __future__ import annotations

import copy
import dataclasses
import json
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "fusion-runtime-lab" / "src"))

from workflows.requirements import (  # noqa: E402
    BASELINE_DOCUMENTS,
    DELIVERABLE_TARGETS,
    MISSING,
    Baseline,
    DocumentVersion,
    NEXT_ACTIONS,
    RESULT_STAGES,
    TRANSITIONS,
    Action,
    Answer,
    BlockedReport,
    Candidate,
    CandidateDraft,
    Choice,
    ContractError,
    Deliverable,
    Evidence,
    InputVersion,
    MaterialCategory,
    Progress,
    Question,
    ResearchOutcome,
    ResearchRecord,
    ResearchRequest,
    ResearchResult,
    ResultKind,
    SaveReference,
    SourceMaterial,
    Stage,
    ToolResult,
    TurnInput,
    TurnResult,
    allowed_actions,
    check_transition,
    check_turn,
    digest,
    parse_agent_result,
    parse_role_result,
    research_inputs_sha256,
    research_request_id,
)


FIXTURE = json.loads(
    (Path(__file__).resolve().parent / "fixtures" / "requirements_case.json").read_text(
        encoding="utf-8"
    )
)
TASK = FIXTURE["task_id"]
PROJECT = FIXTURE["project_id"]
MATERIALS = tuple(SourceMaterial.from_mapping(m) for m in FIXTURE["materials"])
FIRST_TURN = next(t for t in FIXTURE["turns"] if t["turn_id"] == "t1-analyze")
FIRST_MATERIALS = tuple(m for m in MATERIALS if m.source_id in FIRST_TURN["material_ids"])


def _sample(kind: str) -> dict:
    return copy.deepcopy(FIXTURE["role_result_samples"][kind])


def _parse(package: object, *, task_id: str = TASK, project_id: str = PROJECT):
    raw = package if isinstance(package, str) else json.dumps(package, ensure_ascii=False)
    return parse_role_result(
        raw, task_id=task_id, project_id=project_id, materials=FIRST_MATERIALS
    )


def _candidate(candidate_id: str = "cand-1", body: str | None = None) -> Candidate:
    result = _parse(_sample("candidate"))
    candidate = Candidate.from_role_result(result, candidate_id)
    if body is None:
        return candidate
    return Candidate(
        candidate_id=candidate_id,
        deliverable=candidate.deliverable,
        body=body,
        source_refs=candidate.source_refs,
    )


def _save_ref(candidate: Candidate) -> SaveReference:
    return SaveReference(
        candidate_id=candidate.candidate_id,
        body_sha256=candidate.body_sha256,
        deliverable=candidate.deliverable,
        target=DELIVERABLE_TARGETS[candidate.deliverable],
    )


class RoleResultKindsTest(unittest.TestCase):
    def test_four_valid_kinds_parse_to_their_payload_and_stage(self) -> None:
        expected = {
            "questions": (ResultKind.QUESTIONS, tuple, Stage.WAITING_ANSWER),
            "research": (ResultKind.RESEARCH, ResearchRequest, Stage.RESEARCHING),
            "candidate": (ResultKind.CANDIDATE, CandidateDraft, Stage.CANDIDATE_REVIEW),
            "blocked": (ResultKind.BLOCKED, BlockedReport, Stage.BLOCKED),
        }
        self.assertEqual(set(FIXTURE["role_result_samples"]), set(expected))
        for name, (kind, payload_type, stage) in expected.items():
            with self.subTest(kind=name):
                result = _parse(_sample(name))
                self.assertIs(result.kind, kind)
                self.assertIsInstance(result.payload, payload_type)
                self.assertIs(result.stage, stage)
                self.assertIs(RESULT_STAGES[kind], stage)
                self.assertEqual((result.task_id, result.project_id), (TASK, PROJECT))

    def test_questions_keep_ids_reasons_and_option_impacts(self) -> None:
        result = _parse(_sample("questions"))
        (question,) = result.payload
        self.assertIsInstance(question, Question)
        self.assertEqual(question.question_id, "q-fairness")
        self.assertTrue(question.reason)
        self.assertEqual([o.label for o in question.options], ["地理中点", "出行时间"])
        self.assertTrue(all(o.impact for o in question.options))

    def test_research_and_blocked_keep_required_content(self) -> None:
        research = _parse(_sample("research")).payload
        self.assertTrue(research.decision and research.scope and research.stop_condition)
        self.assertTrue(research.questions)
        blocked = _parse(_sample("blocked")).payload
        self.assertTrue(blocked.missing and blocked.impact and blocked.resume_condition)

    def test_candidate_body_is_only_payload_body_not_the_package(self) -> None:
        package = _sample("candidate")
        raw = json.dumps(package, ensure_ascii=False)
        result = _parse(raw)
        candidate = Candidate.from_role_result(result, "cand-1")
        self.assertEqual(candidate.body, package["payload"]["body"])
        self.assertEqual(candidate.body_sha256, digest(package["payload"]["body"]))
        self.assertNotEqual(candidate.body_sha256, digest(raw))
        for marker in ("schema_version", '"kind"', '"payload"', "source_refs", TASK):
            self.assertNotIn(marker, candidate.body)
        self.assertIs(candidate.deliverable, Deliverable.REQUIREMENTS)
        self.assertEqual(candidate.source_refs, result.source_refs)

    def test_non_candidate_results_never_form_a_candidate(self) -> None:
        for name in ("questions", "research", "blocked"):
            with self.subTest(kind=name):
                with self.assertRaises(ContractError):
                    Candidate.from_role_result(_parse(_sample(name)), "cand-x")

    def test_role_result_has_no_binding_grant_or_save_fields(self) -> None:
        result = _parse(_sample("candidate"))
        names = set(type(result).__dataclass_fields__)
        for forbidden in ("save", "save_reference", "authorization", "allowed_tools"):
            self.assertNotIn(forbidden, names)


class RoleResultRejectionTest(unittest.TestCase):
    def test_invalid_json_is_rejected(self) -> None:
        valid = json.dumps(_sample("candidate"), ensure_ascii=False)
        cases = {
            "garbage": "not json",
            "fenced": "```json\n" + valid + "\n```",
            "trailing_text": valid + "\n以上是候选",
            "array": "[]",
            "null": "null",
            "nan": valid.replace('"schema_version": 1', '"schema_version": NaN'),
            "duplicate_key": valid[:-1] + ', "kind": "blocked"}',
            "empty": "",
        }
        for name, raw in cases.items():
            with self.subTest(case=name):
                with self.assertRaises(ContractError):
                    _parse(raw)
        with self.assertRaises(ContractError):
            parse_role_result(
                b"{}", task_id=TASK, project_id=PROJECT, materials=FIRST_MATERIALS
            )

    def test_each_missing_top_level_field_is_rejected(self) -> None:
        for name in FIXTURE["role_result_samples"]:
            for key in _sample(name):
                with self.subTest(kind=name, missing=key):
                    package = _sample(name)
                    del package[key]
                    with self.assertRaises(ContractError):
                        _parse(package)

    def test_each_missing_payload_field_is_rejected(self) -> None:
        for name in FIXTURE["role_result_samples"]:
            for key in _sample(name)["payload"]:
                with self.subTest(kind=name, missing=key):
                    package = _sample(name)
                    del package["payload"][key]
                    with self.assertRaises(ContractError):
                        _parse(package)

    def test_missing_question_and_option_fields_are_rejected(self) -> None:
        for key in ("question_id", "text", "reason", "options"):
            with self.subTest(question_missing=key):
                package = _sample("questions")
                del package["payload"]["questions"][0][key]
                with self.assertRaises(ContractError):
                    _parse(package)
        for key in ("label", "impact"):
            with self.subTest(option_missing=key):
                package = _sample("questions")
                del package["payload"]["questions"][0]["options"][0][key]
                with self.assertRaises(ContractError):
                    _parse(package)

    def test_empty_required_content_is_rejected(self) -> None:
        mutations = {
            "empty_questions": ("questions", lambda p: p["payload"].update(questions=[])),
            "blank_candidate_body": (
                "candidate",
                lambda p: p["payload"].update(body="   \n"),
            ),
            "empty_blocked_missing": ("blocked", lambda p: p["payload"].update(missing=[])),
            "empty_research_questions": (
                "research",
                lambda p: p["payload"].update(questions=[]),
            ),
            "blank_summary": ("questions", lambda p: p.update(summary="")),
            "duplicate_question_ids": (
                "questions",
                lambda p: p["payload"]["questions"].append(
                    copy.deepcopy(p["payload"]["questions"][0])
                ),
            ),
            "non_text_open_item": ("candidate", lambda p: p.update(open_items=[1])),
        }
        for name, (kind, mutate) in mutations.items():
            with self.subTest(case=name):
                package = _sample(kind)
                mutate(package)
                with self.assertRaises(ContractError):
                    _parse(package)

    def test_unknown_schema_version_is_rejected(self) -> None:
        for version in (0, 2, "1", 1.0, True, None):
            with self.subTest(version=version):
                package = _sample("candidate")
                package["schema_version"] = version
                with self.assertRaises(ContractError):
                    _parse(package)

    def test_unknown_kind_or_deliverable_is_rejected(self) -> None:
        for kind in ("answer", "save", "Candidate", "", None):
            with self.subTest(kind=kind):
                package = _sample("candidate")
                package["kind"] = kind
                with self.assertRaises(ContractError):
                    _parse(package)
        for deliverable in ("tech-spec", "requirements.md", None):
            with self.subTest(deliverable=deliverable):
                package = _sample("candidate")
                package["payload"]["deliverable"] = deliverable
                with self.assertRaises(ContractError):
                    _parse(package)

    def test_kind_and_payload_must_agree(self) -> None:
        package = _sample("candidate")
        package["kind"] = "blocked"
        with self.assertRaises(ContractError):
            _parse(package)

    def test_role_cannot_add_binding_grant_or_save_fields(self) -> None:
        for key in (
            "save_authorization",
            "authorized",
            "allowed_tools",
            "project_binding",
            "stage",
            "candidate_id",
        ):
            with self.subTest(top_level=key):
                package = _sample("candidate")
                package[key] = True
                with self.assertRaises(ContractError):
                    _parse(package)
        package = _sample("candidate")
        package["payload"]["save"] = {"target": "docs/requirements.md"}
        with self.assertRaises(ContractError):
            _parse(package)

    def test_task_or_project_mismatch_is_rejected(self) -> None:
        package = _sample("candidate")
        with self.assertRaises(ContractError):
            _parse(package, task_id="other-task")
        with self.assertRaises(ContractError):
            _parse(package, project_id="other-project")
        claimed = _sample("candidate")
        claimed["project_id"] = "other-project"
        with self.assertRaises(ContractError):
            _parse(claimed)

    def test_source_refs_must_match_provided_materials(self) -> None:
        unknown = _sample("candidate")
        unknown["source_refs"].append({"source_id": "case99-x", "version": "v9"})
        stale = _sample("candidate")
        stale["source_refs"][0]["version"] = "v0.1 草稿（2026-10-18）"
        not_given = _sample("candidate")
        not_given["source_refs"] = [
            {"source_id": "case01-s7-feedback", "version": MATERIALS[0].version}
        ]
        uncited = _sample("candidate")
        uncited["source_refs"] = []
        duplicate = _sample("candidate")
        duplicate["source_refs"].append(copy.deepcopy(duplicate["source_refs"][0]))
        for name, package in {
            "unknown": unknown,
            "stale_version": stale,
            "not_given_this_turn": not_given,
            "candidate_without_refs": uncited,
            "duplicate": duplicate,
        }.items():
            with self.subTest(case=name):
                with self.assertRaises(ContractError):
                    _parse(package)

    def test_agent_result_claims_are_checked_and_never_grant(self) -> None:
        raw = json.dumps(_sample("candidate"), ensure_ascii=False)
        ok = parse_agent_result(
            SimpleNamespace(candidate_body=raw, claimed_project_id=PROJECT, claimed_role="requirements"),
            task_id=TASK,
            project_id=PROJECT,
            materials=FIRST_MATERIALS,
        )
        self.assertIs(ok.kind, ResultKind.CANDIDATE)
        for claims in (
            {"claimed_project_id": "other-project"},
            {"claimed_role": "runtime"},
            {"claimed_tools": frozenset({"save_draft"})},
        ):
            with self.subTest(claims=claims):
                with self.assertRaises(ContractError):
                    parse_agent_result(
                        SimpleNamespace(candidate_body=raw, **claims),
                        task_id=TASK,
                        project_id=PROJECT,
                        materials=FIRST_MATERIALS,
                    )
        with self.assertRaises(ContractError):
            parse_agent_result(
                SimpleNamespace(),
                task_id=TASK,
                project_id=PROJECT,
                materials=FIRST_MATERIALS,
            )


class TurnInputAndProgressTest(unittest.TestCase):
    def test_source_material_digest_is_computed_and_checked(self) -> None:
        data = dict(FIXTURE["materials"][0])
        material = SourceMaterial.from_mapping(data)
        self.assertEqual(material.body_sha256, digest(data["body"]))
        data["body_sha256"] = digest("另一份正文")
        with self.assertRaises(ContractError):
            SourceMaterial.from_mapping(data)
        for field_name in ("body", "version", "location"):
            with self.subTest(blank=field_name):
                broken = dict(FIXTURE["materials"][0], **{field_name: " "})
                broken.pop("body_sha256")
                with self.assertRaises(ContractError):
                    SourceMaterial.from_mapping(broken)
        with self.assertRaises(ContractError):
            SourceMaterial.from_mapping(dict(FIXTURE["materials"][0], category="guess"))

    def test_progress_input_versions_keep_body_digest(self) -> None:
        original = MATERIALS[0]
        edited = SourceMaterial(
            original.source_id,
            original.location,
            original.version,
            original.category,
            original.body + "\n补充一句。",
        )
        self.assertEqual(original.ref, edited.ref)
        self.assertNotEqual(original.input_version, edited.input_version)
        progress = Progress(
            TASK, PROJECT, Stage.ANALYZING, input_versions=(original.input_version,)
        )
        self.assertNotIn(edited.input_version, progress.input_versions)
        with self.assertRaises(ContractError):
            Progress(TASK, PROJECT, Stage.ANALYZING, input_versions=(original.ref,))
        with self.assertRaises(ContractError):
            InputVersion(original.source_id, original.version, "not-a-digest")

    def test_turn_input_shapes_by_action(self) -> None:
        candidate = _candidate()
        TurnInput(TASK, PROJECT, Action.ANALYZE, "整理需求", materials=FIRST_MATERIALS)
        TurnInput(TASK, PROJECT, "answer", "回答", answers=(Answer("q-fairness", "地理中点"),))
        TurnInput(TASK, PROJECT, Action.SAVE, "保存当前候选", save=_save_ref(candidate))
        invalid = {
            "answer_without_answers": dict(action=Action.ANSWER),
            "answers_on_analyze": dict(
                action=Action.ANALYZE, answers=(Answer("q-fairness", "地理中点"),)
            ),
            "save_without_reference": dict(action=Action.SAVE),
            "reference_on_ordinary_turn": dict(
                action=Action.REVISE, save=_save_ref(candidate)
            ),
            "register_without_save": dict(action=Action.ANALYZE, register_index=True),
            "unknown_action": dict(action="approve"),
            "duplicate_materials": dict(
                action=Action.ANALYZE, materials=(MATERIALS[0], MATERIALS[0])
            ),
            "material_path_only": dict(
                action=Action.ANALYZE, materials=("my_mind/just-run/01.md",)
            ),
            "missing_utterance": dict(action=Action.ANALYZE, utterance=" "),
            "unsafe_task_id": dict(action=Action.ANALYZE, task_id="../task"),
        }
        for name, overrides in invalid.items():
            with self.subTest(case=name):
                fields = dict(task_id=TASK, project_id=PROJECT, utterance="原话")
                fields.update(overrides)
                with self.assertRaises(ContractError):
                    TurnInput(**fields)

    def test_save_reference_target_must_match_deliverable(self) -> None:
        candidate = _candidate()
        with self.assertRaises(ContractError):
            SaveReference(candidate.candidate_id, candidate.body_sha256, "requirements", "docs/PRD.md")
        with self.assertRaises(ContractError):
            SaveReference(candidate.candidate_id, "abc", "requirements", "docs/requirements.md")

    def test_progress_rejects_stale_or_mismatched_save_reference(self) -> None:
        old = _candidate("cand-1")
        new = _candidate("cand-2", body=old.body + "\n- 新增待讨论：手动修改识别地址。\n")
        Progress(TASK, PROJECT, Stage.WAITING_SAVE, candidate=old, save_reference=_save_ref(old))
        with self.assertRaises(ContractError):
            Progress(TASK, PROJECT, Stage.CANDIDATE_REVIEW, candidate=new, save_reference=_save_ref(old))
        with self.assertRaises(ContractError):
            Progress(TASK, PROJECT, Stage.SAVED, save_reference=_save_ref(old))
        with self.assertRaises(ContractError):
            Progress(TASK, PROJECT, Stage.WAITING_SAVE, candidate=old)
        with self.assertRaises(ContractError):
            Progress(TASK, PROJECT, Stage.CANDIDATE_REVIEW)

    def test_progress_links_answers_and_choices_to_questions(self) -> None:
        question = _parse(_sample("questions")).payload[0]
        Progress(
            TASK,
            PROJECT,
            Stage.ANALYZING,
            questions=(question,),
            answers=(Answer("q-fairness", "地理中点"),),
        )
        with self.assertRaises(ContractError):
            Progress(TASK, PROJECT, Stage.ANALYZING, answers=(Answer("q-other", "x"),))

    def test_pause_records_a_resumable_stage(self) -> None:
        Progress(TASK, PROJECT, Stage.ENDED, resume_stage=Stage.WAITING_ANSWER)
        for invalid in (
            dict(stage=Stage.ENDED),
            dict(stage=Stage.ENDED, resume_stage=Stage.WAITING_SAVE),
            dict(stage=Stage.ENDED, resume_stage=Stage.ENDED),
            dict(stage=Stage.ENDED, resume_stage=Stage.CANDIDATE_REVIEW),
            dict(stage=Stage.WAITING_ANSWER, resume_stage=Stage.BLOCKED),
        ):
            with self.subTest(case=invalid):
                with self.assertRaises(ContractError):
                    Progress(TASK, PROJECT, **invalid)

    def test_turn_must_belong_to_progress_task_and_project(self) -> None:
        progress = Progress(TASK, PROJECT, Stage.BLOCKED)
        check_turn(TurnInput(TASK, PROJECT, Action.ANALYZE, "补齐材料"), progress)
        for task_id, project_id in (("other-task", PROJECT), (TASK, "other-project")):
            with self.subTest(task=task_id, project=project_id):
                with self.assertRaises(ContractError):
                    check_turn(TurnInput(task_id, project_id, Action.ANALYZE, "补齐"), progress)

    def test_turn_action_and_references_follow_progress(self) -> None:
        candidate = _candidate()
        review = Progress(TASK, PROJECT, Stage.CANDIDATE_REVIEW, candidate=candidate)
        check_turn(TurnInput(TASK, PROJECT, Action.SAVE, "保存", save=_save_ref(candidate)), review)
        stale = _candidate("cand-0")
        with self.assertRaises(ContractError):
            check_turn(TurnInput(TASK, PROJECT, Action.SAVE, "保存", save=_save_ref(stale)), review)
        with self.assertRaises(ContractError):
            check_turn(TurnInput(TASK, PROJECT, Action.SAVE, "保存", save=_save_ref(candidate)), None)
        with self.assertRaises(ContractError):
            check_turn(
                TurnInput(TASK, PROJECT, Action.ANSWER, "回答", answers=(Answer("q-fairness", "x"),)),
                review,
            )
        waiting = Progress(
            TASK, PROJECT, Stage.WAITING_ANSWER, questions=_parse(_sample("questions")).payload
        )
        check_turn(
            TurnInput(TASK, PROJECT, Action.ANSWER, "回答", answers=(Answer("q-fairness", "地理中点"),)),
            waiting,
        )
        with self.assertRaises(ContractError):
            check_turn(
                TurnInput(TASK, PROJECT, Action.ANSWER, "回答", answers=(Answer("q-other", "x"),)),
                waiting,
            )


def _baseline(
    shas: dict[str, str] | None = None,
    materials: tuple = FIRST_MATERIALS,
    project_id: str = PROJECT,
) -> Baseline:
    values = {
        "project.json": "a" * 64,
        "README.md": "b" * 64,
        "docs/decisions.md": MISSING,
        "docs/requirements.md": MISSING,
        "docs/PRD.md": MISSING,
    }
    values.update(shas or {})
    return Baseline(
        project_id=project_id,
        documents=tuple(DocumentVersion(p, values[p]) for p in BASELINE_DOCUMENTS),
        materials=tuple(m.input_version for m in materials),
    )


class CandidateBaselineTest(unittest.TestCase):
    def test_baseline_lists_n02_documents_and_keeps_missing_distinct(self) -> None:
        baseline = _baseline({"docs/requirements.md": "c" * 64})
        self.assertEqual(
            tuple(d.path for d in baseline.documents),
            ("project.json", "README.md", "docs/decisions.md", "docs/requirements.md", "docs/PRD.md"),
        )
        self.assertTrue(baseline.document("docs/requirements.md").exists)
        self.assertFalse(baseline.document("docs/PRD.md").exists)
        for path, sha in (
            ("project.json", MISSING),
            ("README.md", MISSING),
            ("docs/PRD.md", ""),
            ("docs/PRD.md", "MISSING"),
            ("docs/PRD.md", "c" * 63),
            ("docs/tech-spec.md", "c" * 64),
        ):
            with self.subTest(path=path, sha=sha):
                with self.assertRaises(ContractError):
                    DocumentVersion(path, sha)
        documents = baseline.documents
        for broken in (documents[:-1], documents[::-1], documents + documents[-1:], ()):
            with self.subTest(paths=[d.path for d in broken]):
                with self.assertRaises(ContractError):
                    Baseline(PROJECT, broken, baseline.materials)
        with self.assertRaises(ContractError):
            Baseline(PROJECT, documents, baseline.materials + baseline.materials[:1])
        with self.assertRaises(dataclasses.FrozenInstanceError):
            baseline.documents = ()

    def test_candidate_baseline_is_optional_and_covers_cited_materials(self) -> None:
        result = _parse(_sample("candidate"))
        self.assertIsNone(Candidate.from_role_result(result, "cand-1").baseline)
        baseline = _baseline()
        candidate = Candidate.from_role_result(result, "cand-1", baseline)
        self.assertIs(candidate.baseline, baseline)
        cited = {ref.source_id for ref in result.source_refs}
        partial = tuple(m for m in FIRST_MATERIALS if m.source_id != sorted(cited)[0])
        relabelled = tuple(
            SourceMaterial(m.source_id, m.location, "v9", m.category, m.body)
            for m in FIRST_MATERIALS
        )
        for broken in (_baseline(materials=partial), _baseline(materials=relabelled)):
            with self.subTest(materials=[m.source_id for m in broken.materials]):
                with self.assertRaises(ContractError):
                    Candidate.from_role_result(result, "cand-1", broken)
        with self.assertRaises(ContractError):
            Candidate.from_role_result(result, "cand-1", {"documents": ()})

    def test_progress_rejects_candidate_baseline_of_another_project(self) -> None:
        result = _parse(_sample("candidate"))
        own = Candidate.from_role_result(result, "cand-1", _baseline())
        Progress(TASK, PROJECT, Stage.CANDIDATE_REVIEW, candidate=own)
        other = Candidate.from_role_result(result, "cand-1", _baseline(project_id="other-project"))
        with self.assertRaises(ContractError):
            Progress(TASK, PROJECT, Stage.CANDIDATE_REVIEW, candidate=other)


class DialogueContractTest(unittest.TestCase):
    def test_progress_keeps_material_text_matching_its_versions(self) -> None:
        progress = Progress(TASK, PROJECT, Stage.WAITING_ANSWER, materials=FIRST_MATERIALS)
        self.assertEqual(progress.materials, FIRST_MATERIALS)
        self.assertEqual(
            progress.input_versions, tuple(m.input_version for m in FIRST_MATERIALS)
        )
        edited = SourceMaterial(
            MATERIALS[0].source_id,
            MATERIALS[0].location,
            MATERIALS[0].version,
            MATERIALS[0].category,
            MATERIALS[0].body + "\n改动。",
        )
        for name, fields in {
            "fewer_versions": dict(
                materials=FIRST_MATERIALS, input_versions=progress.input_versions[1:]
            ),
            "edited_body": dict(
                materials=(edited, *FIRST_MATERIALS[1:]), input_versions=progress.input_versions
            ),
            "duplicate": dict(materials=(MATERIALS[0], MATERIALS[0])),
            "path_only": dict(materials=("my_mind/just-run/01.md",)),
        }.items():
            with self.subTest(case=name):
                with self.assertRaises(ContractError):
                    Progress(TASK, PROJECT, Stage.WAITING_ANSWER, **fields)

    def test_choices_only_come_from_explicit_answer_options(self) -> None:
        question = _parse(_sample("questions")).payload[0]
        Progress(
            TASK,
            PROJECT,
            Stage.ANALYZING,
            questions=(question,),
            answers=(Answer("q-fairness", "就按地理中点", option="地理中点"),),
            choices=(Choice("公平标准", "地理中点", "q-fairness"),),
        )
        for name, (answers, choices) in {
            "choice_without_answer": ((), (Choice("公平标准", "地理中点", "q-fairness"),)),
            "vague_answer": (
                (Answer("q-fairness", "都行吧"),),
                (Choice("公平标准", "地理中点", "q-fairness"),),
            ),
            "other_value": (
                (Answer("q-fairness", "地理中点", option="地理中点"),),
                (Choice("公平标准", "出行时间", "q-fairness"),),
            ),
            "unknown_option": ((Answer("q-fairness", "步行", option="步行距离"),), ()),
        }.items():
            with self.subTest(case=name):
                with self.assertRaises(ContractError):
                    Progress(
                        TASK,
                        PROJECT,
                        Stage.ANALYZING,
                        questions=(question,),
                        answers=answers,
                        choices=choices,
                    )

    def test_turn_answers_cannot_claim_replacement_or_unknown_options(self) -> None:
        waiting = Progress(
            TASK, PROJECT, Stage.WAITING_ANSWER, questions=_parse(_sample("questions")).payload
        )
        def answer(**fields) -> TurnInput:
            return TurnInput(TASK, PROJECT, Action.ANSWER, "回答", answers=(Answer(**fields),))

        check_turn(answer(question_id="q-fairness", text="地理中点", option="地理中点"), waiting)
        with self.assertRaises(ContractError):
            answer(question_id="q-fairness", text="出行时间", replaces="地理中点")
        with self.assertRaises(ContractError):
            check_turn(answer(question_id="q-fairness", text="步行", option="步行距离"), waiting)

    def test_candidate_revision_links_to_a_different_candidate(self) -> None:
        result = _parse(_sample("candidate"))
        first = Candidate.from_role_result(result, "cand-1")
        self.assertEqual((first.revision, first.revises), (1, None))
        second = Candidate.from_role_result(result, "cand-2", revision=2, revises="cand-1")
        self.assertEqual((second.revision, second.revises), (2, "cand-1"))
        self.assertEqual(second.body_sha256, first.body_sha256)
        for revision, revises, candidate_id in (
            (2, None, "cand-2"),
            (1, "cand-1", "cand-2"),
            (0, None, "cand-2"),
            (True, None, "cand-2"),
            (2, "cand-2", "cand-2"),
            (2, "../x", "cand-2"),
        ):
            with self.subTest(revision=revision, revises=revises):
                with self.assertRaises(ContractError):
                    Candidate.from_role_result(
                        result, candidate_id, revision=revision, revises=revises
                    )

    def test_save_results_belong_to_the_current_candidate(self) -> None:
        old = _candidate("cand-1")
        new = Candidate.from_role_result(
            _parse(_sample("candidate")), "cand-2", revision=2, revises="cand-1"
        )
        saved = ToolResult("save_requirements_draft", True, {"candidate_id": "cand-1"})
        Progress(TASK, PROJECT, Stage.SAVED, candidate=old, save_results=(saved,))
        Progress(TASK, PROJECT, Stage.CANDIDATE_REVIEW, candidate=new, prior_save_results=(saved,))
        with self.assertRaises(ContractError):
            Progress(TASK, PROJECT, Stage.CANDIDATE_REVIEW, candidate=new, save_results=(saved,))
        with self.assertRaises(ContractError):
            Progress(TASK, PROJECT, Stage.BLOCKED, save_results=(saved,))

    def test_research_and_blocked_details_are_typed(self) -> None:
        research = _parse(_sample("research")).payload
        blocked = _parse(_sample("blocked")).payload
        progress = Progress(TASK, PROJECT, Stage.RESEARCHING, research=research)
        self.assertIs(progress.research, research)
        Progress(TASK, PROJECT, Stage.BLOCKED, blocked=blocked, open_items=("公平标准",))
        for fields in (
            dict(research={"decision": "x"}),
            dict(blocked="缺材料"),
            dict(open_items=("",)),
        ):
            with self.subTest(fields=fields):
                with self.assertRaises(ContractError):
                    Progress(TASK, PROJECT, Stage.BLOCKED, **fields)


class ResearchContractTest(unittest.TestCase):
    def setUp(self) -> None:
        self.request = _parse(_sample("research")).payload
        self.evidence = Evidence(
            "https://maps.example.test/docs",
            "2026-10-22",
            "多点出行时间比较",
            "测试材料：支持多起点出行时间矩阵",
            test_material=True,
        )
        self.versions = tuple(m.input_version for m in FIRST_MATERIALS)
        self.inputs = research_inputs_sha256(self.versions, (), ())

    def test_result_shapes_separate_evidence_from_limits(self) -> None:
        ResearchResult(ResearchOutcome.EVIDENCE, evidence=(self.evidence,))
        ResearchResult("insufficient", evidence=(self.evidence,), limitations=("只覆盖一家",))
        ResearchResult(ResearchOutcome.UNAVAILABLE, limitations=("页面无法读取",))
        ResearchResult(ResearchOutcome.FAILED, limitations=("调用异常",))
        for fields in (
            dict(outcome=ResearchOutcome.EVIDENCE),
            dict(outcome=ResearchOutcome.INSUFFICIENT),
            dict(outcome=ResearchOutcome.UNAVAILABLE, evidence=(self.evidence,), limitations=("x",)),
            dict(outcome=ResearchOutcome.FAILED, evidence=(self.evidence,), limitations=("x",)),
            dict(outcome="found", evidence=(self.evidence,)),
            dict(outcome=ResearchOutcome.EVIDENCE, evidence=({"source": "x"},)),
            dict(outcome=ResearchOutcome.EVIDENCE, evidence=(self.evidence,), test_material="yes"),
        ):
            with self.subTest(fields=fields):
                with self.assertRaises(ContractError):
                    ResearchResult(**fields)
        with self.assertRaises(ContractError):
            dataclasses.replace(self.evidence, test_material=1)
        self.assertFalse(Evidence("s", "2026-10-22", "x", "y").test_material)

    def test_request_id_follows_request_and_inputs_but_not_results(self) -> None:
        found = ResearchRecord(
            self.request, self.inputs, ResearchResult(ResearchOutcome.EVIDENCE, evidence=(self.evidence,)), True
        )
        limited = ResearchRecord(
            self.request, self.inputs, ResearchResult(ResearchOutcome.UNAVAILABLE, limitations=("无工具",)), False
        )
        self.assertEqual(found.request_id, limited.request_id)
        self.assertEqual(found.request_id, research_request_id(self.request, self.inputs))
        self.assertEqual(research_inputs_sha256(tuple(reversed(self.versions)), (), ()), self.inputs)
        answered = research_inputs_sha256(self.versions, (Answer("q-fairness", "地理中点"),), ())
        chosen = research_inputs_sha256(self.versions, (), (Choice("公平标准", "地理中点", None),))
        self.assertEqual(len({self.inputs, answered, chosen}), 3)
        other = dataclasses.replace(self.request, scope="另一个范围")
        self.assertNotEqual(research_request_id(other, self.inputs), found.request_id)
        with self.assertRaises(TypeError):
            ResearchRecord(self.request, self.inputs, found.result, True, request_id="rs-forged")
        for args in (
            (self.request, self.inputs, ResearchResult(ResearchOutcome.FAILED, limitations=("x",)), False),
            (self.request, self.inputs, found.result, False),
            (self.request, "abc", found.result, True),
            ({"decision": "x"}, self.inputs, found.result, True),
            (self.request, self.inputs, found.result, 1),
        ):
            with self.subTest(args=args[2:]):
                with self.assertRaises(ContractError):
                    ResearchRecord(*args)

    def test_progress_keeps_records_counts_runs_and_gates_analysis(self) -> None:
        unavailable = ResearchRecord(
            self.request, self.inputs, ResearchResult(ResearchOutcome.UNAVAILABLE, limitations=("无工具",)), False
        )
        ran = ResearchRecord(
            self.request, self.inputs, ResearchResult(ResearchOutcome.FAILED, limitations=("异常",)), True
        )
        waiting = Progress(
            TASK, PROJECT, Stage.RESEARCHING, input_versions=self.versions, research=self.request
        )
        self.assertIsNone(waiting.research_record())
        self.assertEqual(allowed_actions(waiting), frozenset({Action.RESEARCH, Action.PAUSE}))
        with self.assertRaises(ContractError):
            check_turn(TurnInput(TASK, PROJECT, Action.ANALYZE, "分析"), waiting)
        limited = dataclasses.replace(waiting, research_records=(unavailable,))
        self.assertIs(limited.research_record(), unavailable)
        self.assertEqual(limited.research_calls, 0)
        self.assertEqual(
            allowed_actions(limited), frozenset({Action.RESEARCH, Action.ANALYZE, Action.PAUSE})
        )
        check_turn(TurnInput(TASK, PROJECT, Action.ANALYZE, "分析"), limited)
        both = dataclasses.replace(waiting, research_records=(ran, unavailable))
        self.assertIs(both.research_record(), ran)
        self.assertEqual(both.research_calls, 1)
        with self.assertRaises(ContractError):
            dataclasses.replace(waiting, research_records=(ran, ran))
        with self.assertRaises(ContractError):
            dataclasses.replace(waiting, research_records=(self.request,))
        moved = dataclasses.replace(limited, input_versions=self.versions[:1], materials=())
        self.assertIsNone(moved.research_record())
        self.assertNotIn(Action.ANALYZE, allowed_actions(moved))
        check_transition(limited, Stage.RESEARCHING)
        check_transition(limited, Stage.ANALYZING)
        with self.assertRaises(ContractError):
            check_transition(waiting, Stage.CANDIDATE_REVIEW)

    def test_candidate_research_refs_are_unique_identifiers(self) -> None:
        result = _parse(_sample("candidate"))
        traced = Candidate.from_role_result(result, "cand-1", research_refs=("rs-0123456789abcdef",))
        self.assertEqual(traced.research_refs, ("rs-0123456789abcdef",))
        self.assertEqual(_candidate().research_refs, ())
        for refs in (("rs-1", "rs-1"), ("../x",), ["rs-1"], (1,)):
            with self.subTest(refs=refs):
                with self.assertRaises(ContractError):
                    Candidate.from_role_result(result, "cand-1", research_refs=refs)


class StageTableTest(unittest.TestCase):
    def test_transition_table(self) -> None:
        check_transition(None, Stage.ANALYZING)
        with self.assertRaises(ContractError):
            check_transition(None, Stage.CANDIDATE_REVIEW)
        review = Progress(TASK, PROJECT, Stage.CANDIDATE_REVIEW, candidate=_candidate())
        check_transition(review, Stage.WAITING_SAVE)
        with self.assertRaises(ContractError):
            check_transition(review, Stage.SAVED)
        answering = Progress(TASK, PROJECT, Stage.WAITING_ANSWER)
        with self.assertRaises(ContractError):
            check_transition(answering, Stage.WAITING_SAVE)
        paused = Progress(TASK, PROJECT, Stage.ENDED, resume_stage=Stage.BLOCKED)
        check_transition(paused, Stage.BLOCKED)
        check_transition(paused, Stage.ANALYZING)
        with self.assertRaises(ContractError):
            check_transition(paused, Stage.WAITING_ANSWER)

    def test_only_waiting_save_reaches_saved_and_every_stage_has_actions(self) -> None:
        reaching_saved = {s for s, targets in TRANSITIONS.items() if Stage.SAVED in targets}
        self.assertEqual(reaching_saved, {Stage.WAITING_SAVE})
        self.assertEqual(set(NEXT_ACTIONS), set(TRANSITIONS))
        self.assertEqual(set(TRANSITIONS) - {None}, set(Stage))
        self.assertEqual(allowed_actions(None), frozenset({Action.ANALYZE}))
        save_stages = {s for s, actions in NEXT_ACTIONS.items() if Action.SAVE in actions}
        self.assertEqual(save_stages, {Stage.CANDIDATE_REVIEW, Stage.WAITING_SAVE})

    def test_turn_result_follows_progress_stage(self) -> None:
        progress = Progress(TASK, PROJECT, Stage.CANDIDATE_REVIEW, candidate=_candidate())
        result = TurnResult(
            Stage.CANDIDATE_REVIEW,
            "候选待审阅",
            progress,
            tool_results=(ToolResult("read_document", True, {"path": "docs/requirements.md"}),),
        )
        self.assertEqual(
            result.next_actions, frozenset({Action.REVISE, Action.SAVE, Action.PAUSE})
        )
        with self.assertRaises(ContractError):
            TurnResult(Stage.SAVED, "已保存", progress)
        with self.assertRaises(ContractError):
            TurnResult(Stage.CANDIDATE_REVIEW, " ", progress)
        with self.assertRaises(ContractError):
            ToolResult("save_draft", "yes")


class CaseFixtureTest(unittest.TestCase):
    def test_fixture_is_marked_test_material(self) -> None:
        self.assertEqual(FIXTURE["fixture_kind"], "test_material")
        self.assertIn("测试材料", FIXTURE["notice"])
        self.assertTrue(all(t["category"] == "test_scenario" for t in FIXTURE["turns"]))

    def test_materials_record_source_version_digest_and_category(self) -> None:
        documents = {s["document_id"]: s for s in FIXTURE["sources"]}
        role_docs = {s["location"] for s in documents.values() if s["role_input"]}
        for source in documents.values():
            self.assertRegex(source["file_sha256"], r"^[0-9a-f]{64}$")
            self.assertTrue(source["version"])
        categories = {m.category for m in MATERIALS}
        self.assertEqual(categories, set(MaterialCategory))
        for raw, material in zip(FIXTURE["materials"], MATERIALS):
            with self.subTest(material=material.source_id):
                self.assertEqual(raw["body_sha256"], material.body_sha256)
                self.assertTrue(any(material.location.startswith(d) for d in role_docs))

    def test_verification_references_are_not_role_input_or_requirements(self) -> None:
        refs = FIXTURE["verification_references"]
        expected_ids = set(FIXTURE["expected"]["not_product_requirements"])
        self.assertEqual({r["ref_id"] for r in refs}, expected_ids)
        material_ids = {m.source_id for m in MATERIALS}
        for ref in refs:
            with self.subTest(ref=ref["ref_id"]):
                self.assertFalse(ref["role_input"])
                self.assertFalse(ref["product_requirement"])
                self.assertEqual(ref["body_sha256"], digest(ref["body"]))
                self.assertNotIn(ref["ref_id"], material_ids)
                self.assertNotIn(ref["body"], "\n".join(m.body for m in MATERIALS))

    def test_first_turn_uses_facts_and_assumptions_not_test_scenarios(self) -> None:
        self.assertEqual(
            {m.category for m in FIRST_MATERIALS},
            {MaterialCategory.SOURCE_FACT, MaterialCategory.PRESALES_ASSUMPTION},
        )
        turn = TurnInput(
            TASK,
            PROJECT,
            FIRST_TURN["action"],
            FIRST_TURN["utterance"],
            materials=FIRST_MATERIALS,
        )
        check_turn(turn, None)

    def test_sample_candidate_excludes_system_verification_requirements(self) -> None:
        candidate = _candidate()
        for marker in FIXTURE["expected"]["candidate_must_not_contain"]:
            self.assertNotIn(marker, candidate.body)
        self.assertEqual(candidate.deliverable.value, FIXTURE["expected"]["first_turn_deliverable"])
        open_items = set(_parse(_sample("candidate")).open_items)
        self.assertTrue(set(FIXTURE["expected"]["open_without_evidence"]) <= open_items)


if __name__ == "__main__":
    unittest.main()
