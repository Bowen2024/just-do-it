"""Lightweight save loop: candidate review -> exact authorization -> save_draft -> re-read."""

from __future__ import annotations

import dataclasses
from datetime import datetime, timezone
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest import mock

_HERE = Path(__file__).resolve()
_WORKSPACE = _HERE.parents[2]
for _path in (
    _WORKSPACE / "fusion-runtime-lab" / "tests",
    _WORKSPACE / "fusion-runtime-lab" / "src",
    _HERE.parents[1],
    _HERE.parent,
):
    if str(_path) not in sys.path:
        sys.path.insert(0, str(_path))

from fusion_runtime.adapters.develop_helper import DevelopHelperDomainTools  # noqa: E402
from fusion_runtime.adapters.memory import FakeAgentRunner  # noqa: E402
from fusion_runtime.domain.approval import ApprovalTrustPolicy  # noqa: E402
from fusion_runtime.domain.errors import AuthorizationError, ValidationError  # noqa: E402
from fusion_runtime.domain.models import WorkflowRun, WorkflowState  # noqa: E402
from fusion_runtime.domain.policy import (  # noqa: E402
    DETERMINISTIC_ROLE,
    INSPECT_ARTIFACT,
    INSPECT_PROJECT,
    SAVE_DRAFT,
    CapabilityPolicy,
    ServerAssignment,
)
from langgraph.project_fixture import (  # noqa: E402
    HELPER_ROOT,
    create_foundation,
    create_project,
)
from test_requirements_workflow_save import (  # noqa: E402
    FIRST_MATERIALS,
    PRD_BODY,
    TamperingPolicy,
    _first_turn,
    _package,
    _sha,
)
from workflows.requirements import (  # noqa: E402
    MISSING,
    Action,
    Candidate,
    ContractError,
    Deliverable,
    Progress,
    RequirementsTools,
    SaveReference,
    SourceMaterial,
    Stage,
    TurnInput,
    UnsupportedActionError,
    WorkflowDependencies,
    run_turn,
)


FIXTURE = json.loads(
    (_HERE.parent / "fixtures" / "requirements_case.json").read_text(encoding="utf-8")
)
TASK = FIXTURE["task_id"]
PROJECT = FIXTURE["project_id"]
NOW = datetime(2026, 10, 22, 10, 0, tzinfo=timezone.utc)
PRD = "docs/PRD.md"
REQUIREMENTS = "docs/requirements.md"
HISTORY = "docs/requirements-history"
BODY = FIXTURE["role_result_samples"]["candidate"]["payload"]["body"]
BODY_B = BODY.replace("- 首次形成候选。", "- 候选数量改为最多两家。")


def _reference(candidate: Candidate) -> SaveReference:
    return SaveReference(
        candidate.candidate_id,
        candidate.body_sha256,
        candidate.deliverable,
        REQUIREMENTS if candidate.deliverable is Deliverable.REQUIREMENTS else PRD,
    )


def _save_turn(candidate: Candidate, **fields) -> TurnInput:
    values = {
        "task_id": TASK,
        "project_id": PROJECT,
        "action": Action.SAVE,
        "utterance": f"保存候选 {candidate.candidate_id} 为轻量需求 Draft",
        "save": _reference(candidate),
    }
    values.update(fields)
    return TurnInput(**values)


def _rendered(body: str) -> bytes:
    return f"---\nstatus: Draft\napproval_verified: false\n---\n\n{body.strip()}\n".encode("utf-8")


class RecordingTools:
    """Delegates to the real tools; records calls and kernel returns, hooks simulate outside events."""

    def __init__(self, inner: RequirementsTools) -> None:
        self.inner = inner
        self.calls: list[tuple] = []
        self.returned: list[dict] = []
        self.before_save = None
        self.after_save = None

    def save_requirements_draft(self, project_id, body, expected, context):
        self.calls.append(("save_requirements_draft", body, expected, context))
        if self.before_save is not None:
            self.before_save()
        result = self.inner.save_requirements_draft(project_id, body, expected, context)
        self.returned.append(dict(result))
        if self.after_save is not None:
            result = self.after_save(result)
        return result

    def __getattr__(self, name: str):
        attribute = getattr(self.inner, name)

        def call(*args, **kwargs):
            self.calls.append((name,))
            return attribute(*args, **kwargs)

        return call

    def names(self) -> list[str]:
        return [call[0] for call in self.calls]

    def saves(self) -> list[tuple]:
        return [call for call in self.calls if call[0] == "save_requirements_draft"]


class RecordingDomainTools:
    """The real PRD adapter; a lightweight save must never reach it."""

    def __init__(self, inner: DevelopHelperDomainTools) -> None:
        self.inner = inner
        self.calls: list[tuple] = []

    def __getattr__(self, name: str):
        attribute = getattr(self.inner, name)

        def call(*args, **kwargs):
            self.calls.append((name, *args))
            return attribute(*args, **kwargs)

        return call


class LightweightTestCase(unittest.TestCase):
    def setUp(self) -> None:
        temp = tempfile.TemporaryDirectory(prefix="req-wf-s4-")
        self.addCleanup(temp.cleanup)
        self.foundation = create_foundation(Path(temp.name))
        self.root = create_project(self.foundation, PROJECT, "语音约碰面地点测试项目")
        self.real_tools = RequirementsTools(foundation=self.foundation, helper_root=HELPER_ROOT)
        self.tools = RecordingTools(self.real_tools)
        self.domain = RecordingDomainTools(
            DevelopHelperDomainTools(
                foundation=self.foundation,
                helper_root=HELPER_ROOT,
                approval_policy=ApprovalTrustPolicy.deny_all(),
                runtime_authority="req-wf-s4-test",
            )
        )
        kernel = self.real_tools._requirements
        patcher = mock.patch.object(kernel, "save_draft", wraps=kernel.save_draft)
        self.kernel_save = patcher.start()
        self.addCleanup(patcher.stop)

    def deps(self, runner, *, domain="default", policy=None, **overrides):
        values = {
            "allowed_projects": frozenset({PROJECT}),
            "task_projects": {TASK: PROJECT},
            "agent_runner": runner,
            "tools": self.tools,
            "domain_tools": self.domain if domain == "default" else domain,
            "clock": lambda: NOW,
        }
        if policy is not None:
            values["policy"] = policy
        values.update(overrides)
        return WorkflowDependencies(**values)

    def tree(self) -> dict[str, str]:
        return {
            path.relative_to(self.root).as_posix(): (
                "dir" if path.is_dir() else _sha(path.read_bytes())
            )
            for path in sorted(self.root.rglob("*"))
        }

    def write(self, relative: str, text: str) -> bytes:
        path = self.root / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")
        return path.read_bytes()

    def restore(self, relative: str, original: bytes | None) -> None:
        if original is None:
            (self.root / relative).unlink()
        else:
            (self.root / relative).write_bytes(original)

    def history(self) -> dict[str, bytes]:
        directory = self.root / HISTORY
        if not directory.is_dir():
            return {}
        return {p.name: p.read_bytes() for p in sorted(directory.iterdir())}

    def review(self, body: str = BODY, deliverable: str = "requirements") -> Progress:
        runner = FakeAgentRunner([_package(body, deliverable)])
        before = self.tree()
        self.tools.calls.clear()
        result = run_turn(_first_turn(), None, self.deps(runner))
        self.assertIs(result.stage, Stage.CANDIDATE_REVIEW)
        self.assertEqual(len(runner.calls), 1)
        self.assertEqual(self.tools.names(), ["read_role_rules", "read_project"])
        self.assertEqual(self.tree(), before)
        self.assertEqual(self.domain.calls, [])
        return result.progress

    def save(self, progress: Progress, turn: TurnInput | None = None, **deps):
        runner = FakeAgentRunner([_package(BODY_B)])
        result = run_turn(turn or _save_turn(progress.candidate), progress, self.deps(runner, **deps))
        self.assertEqual(runner.calls, [])
        self.assertEqual(self.domain.calls, [])
        self.assertFalse(any(r.tool == "inspect_prd" for r in result.tool_results))
        return result

    def tool(self, result, name: str):
        found = [r for r in result.tool_results if r.tool == name]
        self.assertEqual(len(found), 1, name)
        return found[0]

    def assert_not_saved(self, result, before: dict[str, str]) -> None:
        self.assertIs(result.stage, Stage.BLOCKED)
        self.assertIn("轻量需求未保存", result.content)
        self.assertNotIn("轻量需求 Draft 已保存", result.content)
        self.assertEqual(self.tree(), before)
        self.assertIsNone(result.progress.save_reference)
        self.assertNotIn(Action.SAVE, result.next_actions)
        self.assertFalse(
            any(r.tool == "save_requirements_draft" and r.ok for r in result.tool_results)
        )

    def assert_saved(self, result, body: str) -> bytes:
        raw = (self.root / REQUIREMENTS).read_bytes()
        self.assertIs(result.stage, Stage.SAVED)
        self.assertIs(result.progress.stage, Stage.SAVED)
        self.assertEqual(raw, _rendered(body))
        saved = self.tool(result, "save_requirements_draft")
        self.assertTrue(saved.ok)
        self.assertEqual(saved.data["sha256"], _sha(raw))
        self.assertEqual((saved.data["path"], saved.data["status"]), (REQUIREMENTS, "Draft"))
        self.assertIs(saved.data["approval_verified"], False)
        reread = self.tool(result, "reread_requirements")
        self.assertTrue(reread.ok)
        self.assertEqual((reread.data["sha256"], reread.data["problems"]), (_sha(raw), []))
        self.assertEqual(
            [r.tool for r in result.progress.save_results],
            ["save_requirements_draft", "reread_requirements"],
        )
        self.assertEqual(result.progress.save_reference, _reference(result.progress.candidate))
        self.assertIn(f"轻量需求 Draft 已保存到 {REQUIREMENTS}", result.content)
        self.assertIn("写后复读通过", result.content)
        self.assertIn("Draft 不等于正式确认；未登记项目索引", result.content)
        self.assertEqual(result.next_actions, {Action.REVISE, Action.PAUSE})
        return raw


class LightweightSaveTest(LightweightTestCase):
    def test_exact_authorization_saves_through_save_draft_only(self) -> None:
        review = self.review()
        candidate = review.candidate
        self.assertIs(candidate.deliverable, Deliverable.REQUIREMENTS)
        before = self.tree()
        self.tools.calls.clear()
        result = self.save(review)
        raw = self.assert_saved(result, BODY)

        self.assertEqual(self.tools.names(), ["read_project", "save_requirements_draft", "read_project"])
        self.assertEqual(self.kernel_save.call_count, 1)
        _, body, expected, context = self.tools.saves()[0]
        self.assertEqual(body, candidate.body)
        self.assertEqual(expected, candidate.baseline.document(REQUIREMENTS).sha256)
        self.assertEqual(expected, MISSING)
        grant = context.capability_grant
        self.assertEqual((context.project_id, context.step_id), (PROJECT, "N04"))
        self.assertEqual(grant.assigned_role, DETERMINISTIC_ROLE)
        self.assertEqual(grant.allowed_tools, frozenset({INSPECT_PROJECT, INSPECT_ARTIFACT, SAVE_DRAFT}))
        self.assertEqual(grant.allowed_side_effects, frozenset({SAVE_DRAFT}))
        self.assertEqual(grant.writable_paths, frozenset({REQUIREMENTS}))
        self.assertEqual(grant.readable_paths, frozenset({"project.json", "README.md", REQUIREMENTS}))
        self.assertEqual(grant.artifact_types, frozenset({"requirements"}))
        self.assertIn(candidate.candidate_id, context.run_id)
        self.assertIn("requirements", context.run_id)

        self.assertTrue(self.tool(result, "check_baseline").ok)
        saved = self.tool(result, "save_requirements_draft")
        self.assertTrue(saved.data["changed"])
        self.assertIsNone(saved.data["history"])
        self.assertEqual(saved.data["candidate_id"], candidate.candidate_id)
        self.assertNotIn("PRD 结构检查通过", result.content)
        after = self.tree()
        self.assertEqual({p for p in after if before.get(p) != after[p]}, {"docs", REQUIREMENTS})
        self.assertEqual(self.history(), {})
        self.assertFalse((self.root / PRD).exists())
        self.assertEqual(result.progress.candidate, candidate)
        self.assertEqual(after[REQUIREMENTS], _sha(raw))

    def test_save_works_without_the_prd_adapter(self) -> None:
        result = self.save(self.review(), domain=None)
        self.assert_saved(result, BODY)

    def test_update_keeps_the_previous_version_byte_for_byte(self) -> None:
        old = self.write(REQUIREMENTS, "# 旧轻量需求\n\n上一版内容，含尾随空格  \n")
        prd = self.write(PRD, "# 已有 PRD\n")
        review = self.review()
        self.assertEqual(review.candidate.baseline.document(REQUIREMENTS).sha256, _sha(old))

        result = self.save(review)
        self.assert_saved(result, BODY)
        archive = f"{HISTORY}/{_sha(old)}.md"
        self.assertEqual(self.history(), {f"{_sha(old)}.md": old})
        _, _, expected, context = self.tools.saves()[0]
        self.assertEqual(expected, _sha(old))
        self.assertEqual(context.capability_grant.writable_paths, frozenset({REQUIREMENTS, archive}))
        self.assertEqual(
            context.capability_grant.readable_paths,
            frozenset({"project.json", "README.md", REQUIREMENTS, archive}),
        )
        saved = self.tool(result, "save_requirements_draft")
        self.assertEqual(saved.data["history"], archive)
        self.assertIn(f"原轻量需求保留在 {archive}", result.content)
        self.assertEqual((self.root / PRD).read_bytes(), prd)

    def test_identical_content_is_not_rewritten_and_adds_no_history(self) -> None:
        self.write(REQUIREMENTS, "# 旧轻量需求\n")
        first = self.save(self.review())
        raw = self.assert_saved(first, BODY)
        self.assertEqual(len(self.history()), 1)
        history = self.history()

        again = self.review()
        self.assertEqual(again.candidate.baseline.document(REQUIREMENTS).sha256, _sha(raw))
        before = self.tree()
        result = self.save(again)
        self.assert_saved(result, BODY)
        kernel = self.tools.returned[-1]
        self.assertIs(kernel["changed"], False)
        self.assertNotIn("approval_verified", kernel)
        self.assertFalse(self.tool(result, "save_requirements_draft").data["changed"])
        self.assertIn("未重写", result.content)
        self.assertEqual(self.history(), history)
        self.assertEqual(self.tree(), before)
        self.assertEqual(self.kernel_save.call_count, 2)

    def test_a_new_candidate_does_not_reuse_the_previous_save_result(self) -> None:
        first = self.save(self.review())
        raw_a = self.assert_saved(first, BODY)
        first_context = self.tools.saves()[0][3]

        second_review = self.review(BODY_B)
        self.assertNotEqual(second_review.candidate.candidate_id, first.progress.candidate.candidate_id)
        second = self.save(second_review)
        raw_b = self.assert_saved(second, BODY_B)
        self.assertNotEqual(raw_a, raw_b)
        self.assertEqual(self.history(), {f"{_sha(raw_a)}.md": raw_a})
        self.assertEqual(self.kernel_save.call_count, 2)
        second_context = self.tools.saves()[0][3]
        self.assertNotEqual(first_context.idempotency_key, second_context.idempotency_key)
        self.assertIn(second_review.candidate.candidate_id, second_context.run_id)
        saved = self.tool(second, "save_requirements_draft")
        self.assertEqual(saved.data["sha256"], _sha(raw_b))
        self.assertEqual(saved.data["candidate_id"], second_review.candidate.candidate_id)

    def test_same_candidate_id_for_both_deliverables_uses_separate_operation_keys(self) -> None:
        prd_review = self.review(PRD_BODY, "prd")
        light_review = self.review(PRD_BODY)
        self.assertEqual(prd_review.candidate.candidate_id, light_review.candidate.candidate_id)

        prd_saved = run_turn(
            _save_turn(prd_review.candidate), prd_review, self.deps(FakeAgentRunner())
        )
        self.assertIs(prd_saved.stage, Stage.SAVED)
        prd_context = next(c for c in self.domain.calls if c[0] == "save_prd_draft")[2]
        (self.root / PRD).unlink()
        self.domain.calls.clear()

        result = self.save(light_review)
        self.assert_saved(result, PRD_BODY)
        light_context = self.tools.saves()[0][3]
        self.assertNotEqual(prd_context.run_id, light_context.run_id)
        self.assertNotEqual(prd_context.idempotency_key, light_context.idempotency_key)
        self.assertIn("-prd-", prd_context.run_id)
        self.assertIn("-requirements-", light_context.run_id)

    def test_repeated_request_checks_the_known_effect_and_never_rewrites(self) -> None:
        self.write(REQUIREMENTS, "# 旧轻量需求\n")
        review = self.review()
        raw = self.assert_saved(self.save(review), BODY)
        before, history = self.tree(), self.history()

        for name, tools in (("same tools", self.tools), ("fresh tools", None)):
            with self.subTest(case=name):
                tools = tools or RecordingTools(
                    RequirementsTools(foundation=self.foundation, helper_root=HELPER_ROOT)
                )
                calls = len(tools.saves())
                result = self.save(review, tools=tools)
                self.assert_saved(result, BODY)
                self.assertEqual(len(tools.saves()), calls)
                self.assertFalse(self.tool(result, "check_baseline").ok)
                self.assertFalse(self.tool(result, "save_requirements_draft").data["changed"])
                self.assertIn("本轮未重写", result.content)
                self.assertEqual(self.tree(), before)
                self.assertEqual(self.history(), history)
        self.assertEqual(self.kernel_save.call_count, 1)

        text = raw.decode("utf-8")
        for name, edited_text in (
            ("body_appended", text + "\n外部补充。\n"),
            ("metadata_approved", text.replace("approval_verified: false", "approval_verified: true")),
        ):
            with self.subTest(external=name):
                edited = self.write(REQUIREMENTS, edited_text)
                before = self.tree()
                result = self.save(review)
                self.assert_not_saved(result, before)
                self.assertEqual(self.kernel_save.call_count, 1)
                self.assertEqual((self.root / REQUIREMENTS).read_bytes(), edited)


class LightweightAuthorizationTest(LightweightTestCase):
    def assert_rejected(self, error, turn, progress, **deps) -> None:
        runner = FakeAgentRunner([_package(BODY)])
        before = self.tree()
        self.tools.calls.clear()
        self.domain.calls.clear()
        with self.assertRaises(error):
            run_turn(turn, progress, self.deps(runner, **deps))
        self.assertEqual(runner.calls, [])
        self.assertEqual(self.tools.calls, [])
        self.assertEqual(self.domain.calls, [])
        self.assertEqual(self.kernel_save.call_count, 0)
        self.assertEqual(self.tree(), before)

    def test_missing_stale_or_mismatched_references_never_save(self) -> None:
        review = self.review()
        candidate = review.candidate
        other = self.review(BODY_B).candidate
        cases = {
            "other_candidate": _save_turn(other),
            "other_digest": _save_turn(
                candidate,
                save=SaveReference(
                    candidate.candidate_id, other.body_sha256, Deliverable.REQUIREMENTS, REQUIREMENTS
                ),
            ),
            "other_deliverable": _save_turn(
                candidate,
                save=SaveReference(candidate.candidate_id, candidate.body_sha256, Deliverable.PRD, PRD),
            ),
        }
        for name, turn in cases.items():
            with self.subTest(case=name):
                self.assert_rejected(ContractError, turn, review)
        with self.assertRaises(ContractError):
            SaveReference(candidate.candidate_id, candidate.body_sha256, Deliverable.REQUIREMENTS, PRD)
        with self.subTest(case="no_progress"):
            self.assert_rejected(ContractError, _save_turn(candidate), None)
        with self.subTest(case="saved_progress"):
            saved = dataclasses.replace(review, stage=Stage.SAVED, save_reference=_reference(candidate))
            self.assert_rejected(ContractError, _save_turn(candidate), saved)
        with self.subTest(case="registration"):
            self.assert_rejected(
                UnsupportedActionError, _save_turn(candidate, register_index=True), review
            )

    def test_candidate_without_baseline_cannot_be_saved(self) -> None:
        review = self.review()
        bare = dataclasses.replace(review.candidate, baseline=None)
        self.assert_rejected(
            ContractError, _save_turn(bare), dataclasses.replace(review, candidate=bare)
        )

    def test_changed_materials_void_the_save_reference(self) -> None:
        review = self.review()
        first = FIRST_MATERIALS[0]
        edited = SourceMaterial(
            first.source_id, first.location, first.version, first.category, first.body + "\n补充。"
        )
        changed = (edited, *FIRST_MATERIALS[1:])
        self.assert_rejected(ContractError, _save_turn(review.candidate, materials=changed), review)
        self.assert_rejected(
            ContractError, _save_turn(review.candidate, materials=FIRST_MATERIALS[1:]), review
        )
        moved = dataclasses.replace(
            review, input_versions=review.input_versions[1:], materials=review.materials[1:]
        )
        self.assert_rejected(ContractError, _save_turn(review.candidate), moved)

        same = tuple(reversed(FIRST_MATERIALS))
        self.assert_saved(self.save(review, _save_turn(review.candidate, materials=same)), BODY)

    def test_project_binding_is_checked_first(self) -> None:
        review = self.review()
        turn = _save_turn(review.candidate)
        self.assert_rejected(AuthorizationError, turn, review, allowed_projects=frozenset({"other"}))
        self.assert_rejected(AuthorizationError, turn, review, task_projects={TASK: "other"})


class LightweightConflictTest(LightweightTestCase):
    def test_files_changed_after_review_are_not_overwritten(self) -> None:
        self.write(PRD, "# 已有 PRD\n")
        self.write(REQUIREMENTS, "# 旧轻量需求\n")
        project_json = (self.root / "project.json").read_text(encoding="utf-8")
        edits = {
            REQUIREMENTS: "# 审阅期间外部修改的轻量需求\n",
            PRD: "# 审阅期间外部修改的 PRD\n",
            "README.md": "# 审阅期间外部修改的 README\n",
            "docs/decisions.md": "# 审阅期间新增的决策\n",
            "project.json": project_json + "\n",
        }
        for path, text in edits.items():
            with self.subTest(changed=path):
                review = self.review()
                original = (self.root / path).read_bytes() if (self.root / path).exists() else None
                edited = self.write(path, text)
                before = self.tree()
                calls = self.kernel_save.call_count
                result = self.save(review)
                self.assert_not_saved(result, before)
                self.assertEqual(self.kernel_save.call_count, calls)
                self.assertEqual((self.root / path).read_bytes(), edited)
                check = self.tool(result, "check_baseline")
                self.assertFalse(check.ok)
                self.assertEqual(check.data["changed"], [path])
                self.assertEqual(
                    check.data["baseline"][path], review.candidate.baseline.document(path).sha256
                )
                self.assertEqual(check.data["current"][path], _sha(edited))
                self.assertIn(path, result.content)
                self.restore(path, original)

    def test_kernel_version_check_uses_the_review_baseline(self) -> None:
        for original_text in (None, "# 旧轻量需求\n"):
            with self.subTest(previous="missing" if original_text is None else "existing"):
                original = None if original_text is None else self.write(REQUIREMENTS, original_text)
                review = self.review()
                history = self.history()
                edited = []
                self.tools.before_save = lambda: edited.append(
                    self.write(REQUIREMENTS, "# 保存前一刻被改\n")
                )
                result = self.save(review)
                self.tools.before_save = None
                self.assertIs(result.stage, Stage.BLOCKED)
                self.assertIn("轻量需求未保存", result.content)
                self.assertIn("写入前拒绝", result.content)
                self.assertIn("版本冲突", result.content)
                self.assertEqual((self.root / REQUIREMENTS).read_bytes(), edited[0])
                self.assertEqual(self.history(), history)
                expected = self.tools.saves()[-1][2]
                self.assertEqual(expected, review.candidate.baseline.document(REQUIREMENTS).sha256)
                self.restore(REQUIREMENTS, original)

    def test_source_changed_between_comparison_and_write_is_reported_after_the_write(self) -> None:
        review = self.review()
        readme = []
        self.tools.before_save = lambda: readme.append(self.write("README.md", "# 比较后被改\n"))
        result = self.save(review)
        self.assertIs(result.stage, Stage.BLOCKED)
        self.assertIn("轻量需求文件已写入", result.content)
        self.assertIn("写后检查未通过：reread_requirements", result.content)
        self.assertIn("README.md 与审阅基线不一致", result.content)
        self.assertEqual((self.root / REQUIREMENTS).read_bytes(), _rendered(BODY))
        self.assertEqual((self.root / "README.md").read_bytes(), readme[0])
        self.assertTrue(self.tool(result, "save_requirements_draft").ok)
        self.assertFalse(self.tool(result, "reread_requirements").ok)
        self.assertEqual(self.kernel_save.call_count, 1)


class LightweightPermissionTest(LightweightTestCase):
    def test_step_role_project_type_and_path_scope_are_enforced(self) -> None:
        old = self.write(REQUIREMENTS, "# 旧轻量需求\n")
        archive = f"{HISTORY}/{_sha(old)}.md"

        def assignment(**fields):
            return lambda workflow, assigned: (workflow, dataclasses.replace(assigned, **fields))

        def paths(readable=None, writable=None):
            def change(workflow, assigned):
                return workflow, dataclasses.replace(
                    assigned,
                    readable_paths=readable(assigned.readable_paths) if readable else assigned.readable_paths,
                    writable_paths=writable(assigned.writable_paths) if writable else assigned.writable_paths,
                )

            return change

        def other_project(workflow, assigned):
            return dataclasses.replace(workflow, project_id="other-project"), assigned

        def other_node(workflow, assigned):
            return (
                dataclasses.replace(workflow, current_node="N10"),
                dataclasses.replace(assigned, step_id="N10"),
            )

        cases = {
            "requirements_role": (assignment(assigned_role="requirements"), False),
            "other_node_with_save_draft": (other_node, False),
            "other_project": (other_project, False),
            "missing_history_write": (paths(writable=lambda p: p - {archive}), True),
            "missing_history_read": (paths(readable=lambda p: p - {archive}), True),
            "extra_writable_path": (paths(writable=lambda p: p | {PRD}), True),
            "missing_readable_path": (paths(readable=lambda p: p - {"README.md"}), True),
            "extra_readable_path": (paths(readable=lambda p: p | {PRD}), True),
            "prd_artifact_type": (assignment(artifact_types=frozenset({"prd"})), True),
            "extra_artifact_type": (
                assignment(artifact_types=frozenset({"requirements", "prd"})),
                True,
            ),
        }
        for name, (change, reaches_tools) in cases.items():
            with self.subTest(case=name):
                review = self.review()
                before, history = self.tree(), self.history()
                calls = len(self.tools.saves())
                result = self.save(review, policy=TamperingPolicy("N04", change))
                self.assert_not_saved(result, before)
                self.assertEqual(self.history(), history)
                self.assertEqual(len(self.tools.saves()), calls + int(reaches_tools))
                self.assertEqual(self.kernel_save.call_count, 0)
                if reaches_tools:
                    self.assertIn("写入前拒绝", result.content)

        result = self.save(self.review())
        self.assert_saved(result, BODY)
        self.assertEqual(self.history(), {f"{_sha(old)}.md": old})

    def test_the_tool_rejects_untrusted_or_read_contexts_directly(self) -> None:
        policy = CapabilityPolicy()

        def context(node, role, **scope):
            workflow = WorkflowRun(
                workflow_id=TASK,
                workflow_type="requirements",
                project_id=PROJECT,
                state=WorkflowState.RUNNING,
                current_node=node,
                created_from_ingress=TASK,
                created_at=NOW,
                updated_at=NOW,
            )
            return policy.build_execution_context(
                workflow=workflow,
                run_id=f"probe-{node}",
                ingress_ref=TASK,
                assignment=ServerAssignment(
                    principal="runtime", assigned_role=role, step_id=node, attempt=1, **scope
                ),
            )

        valid = context(
            "N04",
            DETERMINISTIC_ROLE,
            readable_paths=frozenset({"project.json", "README.md", REQUIREMENTS}),
            writable_paths=frozenset({REQUIREMENTS}),
            artifact_types=frozenset({"requirements"}),
        )
        read_only = context("N05", "requirements", readable_paths=frozenset({"docs"}))
        cases = {
            "plain_mapping": (AuthorizationError, BODY, MISSING, {"project_id": PROJECT}),
            "read_context": (AuthorizationError, BODY, MISSING, read_only),
            "other_project": (AuthorizationError, BODY, MISSING, valid, "other-project"),
            "bad_expected": (ValidationError, BODY, "latest", valid),
            "empty_body": (ValidationError, "  \n", MISSING, valid),
            "front_matter": (ValidationError, "---\nstatus: Approved\n---\n\n" + BODY, MISSING, valid),
        }
        for name, (error, body, expected, ctx, *project) in cases.items():
            with self.subTest(case=name):
                with self.assertRaises(error):
                    self.real_tools.save_requirements_draft(
                        project[0] if project else PROJECT, body, expected, ctx
                    )
        self.assertEqual(self.kernel_save.call_count, 0)
        self.assertFalse((self.root / REQUIREMENTS).exists())

        saved = self.real_tools.save_requirements_draft(PROJECT, BODY, MISSING, valid)
        self.assertEqual(saved["sha256"], _sha(_rendered(BODY)))
        self.assertEqual(self.kernel_save.call_count, 1)


class LightweightFailureTest(LightweightTestCase):
    def test_failures_before_writing_report_not_saved(self) -> None:
        bodies = {
            "front_matter": "---\nstatus: Approved\napproval_verified: true\n---\n\n" + BODY,
            "wrong_source_digest": BODY + "\n\n来源 README.md sha256: " + "0" * 64,
        }
        for name, body in bodies.items():
            with self.subTest(case=name):
                review = self.review(body)
                before = self.tree()
                result = self.save(review)
                self.assert_not_saved(result, before)
                self.assertIn("写入前拒绝", result.content)
                self.assertFalse((self.root / REQUIREMENTS).exists())
        self.assertEqual(self.kernel_save.call_count, 1)

        review = self.review()
        before = self.tree()

        def refuse():
            raise OSError("disk unavailable")

        self.tools.before_save = refuse
        result = self.save(review)
        self.assert_not_saved(result, before)
        self.assertIn("保存调用异常：OSError", result.content)
        self.assertIn("复读确认轻量需求未写入", result.content)
        self.assertIs(self.tool(result, "save_requirements_draft").data["written"], False)

    def test_unknown_outcome_is_observed_once_and_never_retried(self) -> None:
        review = self.review()

        def lost_reply(saved):
            raise OSError("connection lost after the write")

        self.tools.after_save = lost_reply
        result = self.save(review)
        self.assert_saved(result, BODY)
        self.assertEqual(self.kernel_save.call_count, 1)
        self.assertIn("复读确认本候选已写入", result.content)

        review = self.review(BODY_B)
        self.tools.after_save = lambda saved: {"sha256": "not-a-digest"}
        result = self.save(review)
        self.assert_saved(result, BODY_B)
        self.assertIn("保存返回不合格", result.content)
        self.assertEqual(self.kernel_save.call_count, 2)

        review = self.review(BODY)
        foreign = []

        def foreign_write(saved):
            foreign.append(self.write(REQUIREMENTS, "# 另一个写入者的内容\n"))
            raise OSError("reply lost")

        self.tools.after_save = foreign_write
        result = self.save(review)
        self.assertIs(result.stage, Stage.BLOCKED)
        self.assertIn("轻量需求保存结果无法确认", result.content)
        self.assertNotIn("轻量需求 Draft 已保存", result.content)
        self.assertEqual((self.root / REQUIREMENTS).read_bytes(), foreign[0])
        self.assertEqual(self.kernel_save.call_count, 3)
        self.assertIsNone(self.tool(result, "save_requirements_draft").data["written"])

    def assert_written_not_verified(self, result) -> None:
        self.assertIs(result.stage, Stage.BLOCKED)
        self.assertIn("轻量需求文件已写入", result.content)
        self.assertIn("写后检查未通过：reread_requirements", result.content)
        self.assertIn("不算完整成功，未自动重试", result.content)
        self.assertNotIn("轻量需求 Draft 已保存", result.content)
        saved = self.tool(result, "save_requirements_draft")
        self.assertTrue(saved.ok)
        self.assertTrue(saved.data["changed"])
        self.assertFalse(self.tool(result, "reread_requirements").ok)
        self.assertEqual(
            [r.tool for r in result.progress.save_results],
            ["save_requirements_draft", "reread_requirements"],
        )
        self.assertIsNone(result.progress.save_reference)
        self.assertNotIn(Action.SAVE, result.next_actions)

    def test_reread_failing_after_the_write_is_reported_as_written_not_verified(self) -> None:
        review = self.review()
        touched = []

        def edited_after(saved):
            text = (self.root / REQUIREMENTS).read_text(encoding="utf-8")
            touched.append(self.write(REQUIREMENTS, text + "并发追加。\n"))
            return saved

        self.tools.after_save = edited_after
        result = self.save(review)
        self.tools.after_save = None
        self.assert_written_not_verified(result)
        self.assertEqual((self.root / REQUIREMENTS).read_bytes(), touched[0])
        self.assertIn("摘要与保存返回不一致", result.content)
        self.assertIn("正文与候选不一致", result.content)

        old = (self.root / REQUIREMENTS).read_bytes()
        review = self.review(BODY_B)
        archive = self.root / HISTORY / f"{_sha(old)}.md"

        def history_replaced(saved):
            archive.write_text("# 被替换的历史\n", encoding="utf-8")
            return saved

        self.tools.after_save = history_replaced
        result = self.save(review)
        self.tools.after_save = None
        self.assert_written_not_verified(result)
        self.assertIn("未保留审阅基线中的轻量需求", result.content)
        self.assertEqual((self.root / REQUIREMENTS).read_bytes(), _rendered(BODY_B))

        review = self.review(BODY)
        check_role = TamperingPolicy(
            "N05", lambda w, a: (w, dataclasses.replace(a, assigned_role=DETERMINISTIC_ROLE))
        )
        result = self.save(review, policy=check_role)
        self.assert_written_not_verified(result)
        self.assertEqual((self.root / REQUIREMENTS).read_bytes(), _rendered(BODY))
        self.assertEqual(self.kernel_save.call_count, 3)


class LightweightScopeTest(LightweightTestCase):
    def test_analysis_still_only_returns_the_candidate(self) -> None:
        review = self.review()
        self.assertIsNone(review.save_reference)
        self.assertEqual(review.save_results, ())
        self.assertFalse((self.root / REQUIREMENTS).exists())
        self.assertEqual(self.kernel_save.call_count, 0)

    def test_other_actions_stay_rejected_without_side_effects(self) -> None:
        cases = {
            "research_without_request": (
                TurnInput(TASK, PROJECT, Action.RESEARCH, "去查一下"),
                Progress(TASK, PROJECT, Stage.RESEARCHING),
            ),
        }
        for name, (turn, progress) in cases.items():
            with self.subTest(case=name):
                before = self.tree()
                self.tools.calls.clear()
                runner = FakeAgentRunner([_package(BODY)])
                with self.assertRaisesRegex(ContractError, "no research request"):
                    run_turn(turn, progress, self.deps(runner))
                self.assertEqual((runner.calls, self.tools.calls, self.domain.calls), ([], [], []))
                self.assertEqual(self.tree(), before)
        self.assertEqual(self.kernel_save.call_count, 0)


if __name__ == "__main__":
    unittest.main()
