"""PRD save loop: candidate review -> exact authorization -> save -> re-read and inspect."""

from __future__ import annotations

import copy
import dataclasses
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest import mock

_HERE = Path(__file__).resolve()
_WORKSPACE = _HERE.parents[2]
for _path in (
    _WORKSPACE / "fusion-runtime-lab" / "tests",
    _WORKSPACE / "fusion-runtime-lab" / "src",
    _HERE.parents[1],
):
    if str(_path) not in sys.path:
        sys.path.insert(0, str(_path))

from fusion_runtime.adapters.develop_helper import DevelopHelperDomainTools  # noqa: E402
from fusion_runtime.adapters.memory import FakeAgentRunner  # noqa: E402
from fusion_runtime.domain.approval import ApprovalTrustPolicy  # noqa: E402
from fusion_runtime.domain.errors import AuthorizationError  # noqa: E402
from fusion_runtime.domain.policy import (  # noqa: E402
    DETERMINISTIC_ROLE,
    SAVE_DRAFT,
    CapabilityPolicy,
)
from fusion_runtime.ports.agents import AgentResult  # noqa: E402
from langgraph.project_fixture import (  # noqa: E402
    HELPER_ROOT,
    create_foundation,
    create_project,
)
from workflows.requirements import (  # noqa: E402
    MISSING,
    Action,
    Candidate,
    ContractError,
    Deliverable,
    Progress,
    RequirementsTools,
    SaveReference,
    SourceMaterial,
    Stage,
    TurnInput,
    UnsupportedActionError,
    WorkflowDependencies,
    run_turn,
)


FIXTURE = json.loads(
    (_HERE.parent / "fixtures" / "requirements_case.json").read_text(encoding="utf-8")
)
TASK = FIXTURE["task_id"]
PROJECT = FIXTURE["project_id"]
MATERIALS = tuple(SourceMaterial.from_mapping(m) for m in FIXTURE["materials"])
FIRST_TURN = next(t for t in FIXTURE["turns"] if t["turn_id"] == "t1-analyze")
FIRST_MATERIALS = tuple(m for m in MATERIALS if m.source_id in FIRST_TURN["material_ids"])
NOW = datetime(2026, 10, 21, 15, 30, tzinfo=timezone.utc)
PRD = "docs/PRD.md"
REQUIREMENTS = "docs/requirements.md"

# Test material: a PRD body shaped for inspect_prd, not a reviewed product requirement.
PRD_BODY = """# 语音约碰面地点 PRD（测试材料）

## 用户结果与成功指标
两位用户用一句语音说明各自位置后，得到可选的碰面地点并发出邀请。

## 具体案例
小李说“我在西湖文化广场，小王在滨江星光大道”，系统给出三个折中地点。

## 范围与边界
只包含语音输入、地点理解、候选推荐与结果反馈；公平标准仍待确认。

## REQ 与 AC

## REQ-001 语音生成候选地点

### AC-001 识别成功
- 结果类型：成功
- 前置条件：两处位置都能识别
- 操作：说出两处位置
- 可观察结果：显示至少一个候选地点
- 验证方式：测试脚本与人工检查

### AC-002 识别失败
- 结果类型：失败
- 前置条件：有一处位置无法识别
- 操作：说出模糊位置
- 可观察结果：提示补充位置且不生成候选
- 验证方式：测试脚本与人工检查

## 业务流程图
```mermaid
flowchart TD
A[语音输入] --> B[地点理解] --> C[候选推荐] --> D[结果反馈]
```

## 业务时序图
```mermaid
sequenceDiagram
U->>S: 语音说明两处位置
S-->>U: 候选碰面地点
```

## 事实、假设与待决事项
客户画像与价值目标为售前假设；公平标准待确认。

## 变更摘要
首次形成 PRD 候选。"""

PRD_BODY_B = PRD_BODY.replace("显示至少一个候选地点", "显示三个候选地点").replace(
    "首次形成 PRD 候选。", "候选地点数量改为三个。"
)


def _sha(raw: bytes) -> str:
    return sha256(raw).hexdigest()


def _package(body: str, deliverable: str = "prd") -> AgentResult:
    package = copy.deepcopy(FIXTURE["role_result_samples"]["candidate"])
    package["payload"] = {"deliverable": deliverable, "body": body}
    return AgentResult(candidate_body=json.dumps(package, ensure_ascii=False))


def _first_turn() -> TurnInput:
    return TurnInput(
        task_id=TASK,
        project_id=PROJECT,
        action=Action.ANALYZE,
        utterance=FIRST_TURN["utterance"],
        materials=FIRST_MATERIALS,
    )


def _reference(candidate: Candidate) -> SaveReference:
    return SaveReference(
        candidate.candidate_id,
        candidate.body_sha256,
        candidate.deliverable,
        "docs/PRD.md" if candidate.deliverable is Deliverable.PRD else REQUIREMENTS,
    )


def _save_turn(candidate: Candidate, **fields) -> TurnInput:
    values = {
        "task_id": TASK,
        "project_id": PROJECT,
        "action": Action.SAVE,
        "utterance": f"保存候选 {candidate.candidate_id} 为 PRD Draft",
        "save": _reference(candidate),
    }
    values.update(fields)
    return TurnInput(**values)


def _rendered(body: str, requirements_sha: str = MISSING) -> bytes:
    return (
        "---\nartifact_kind: prd\nstatus: Draft\napproval_verified: false\n"
        "source_requirements_path: docs/requirements.md\n"
        f"source_requirements_sha256: {requirements_sha}\n---\n\n{body.strip()}\n"
    ).encode("utf-8")


class RecordingTools:
    """Delegates to the real read tools and records every method the workflow uses."""

    def __init__(self, inner: RequirementsTools) -> None:
        self.inner = inner
        self.calls: list[str] = []

    def __getattr__(self, name: str):
        attribute = getattr(self.inner, name)

        def call(*args, **kwargs):
            self.calls.append(name)
            return attribute(*args, **kwargs)

        return call


class RecordingDomainTools:
    """Delegates to the real Develop Helper adapter; hooks simulate outside events."""

    def __init__(self, inner: DevelopHelperDomainTools) -> None:
        self.inner = inner
        self.calls: list[tuple] = []
        self.before_save = None
        self.after_save = None

    def save_prd_draft(self, command, context):
        self.calls.append(("save_prd_draft", command, context))
        if self.before_save is not None:
            self.before_save()
        result = self.inner.save_prd_draft(command, context)
        if self.after_save is not None:
            result = self.after_save(result)
        return result

    def inspect_draft(self, project_id, kind, context):
        self.calls.append(("inspect_draft", kind, context))
        return self.inner.inspect_draft(project_id, kind, context)

    def __getattr__(self, name: str):
        self.calls.append((name,))
        return getattr(self.inner, name)

    def names(self) -> list[str]:
        return [call[0] for call in self.calls]

    def saves(self) -> list[tuple]:
        return [call for call in self.calls if call[0] == "save_prd_draft"]


class TamperingPolicy(CapabilityPolicy):
    """Changes the trusted assignment of one step to probe the save permission checks."""

    def __init__(self, node: str, change) -> None:
        self.node = node
        self.change = change

    def build_execution_context(self, *, workflow, run_id, ingress_ref, assignment, **extra):
        if assignment.step_id == self.node:
            workflow, assignment = self.change(workflow, assignment)
        return super().build_execution_context(
            workflow=workflow,
            run_id=run_id,
            ingress_ref=ingress_ref,
            assignment=assignment,
            **extra,
        )


class SaveTestCase(unittest.TestCase):
    def setUp(self) -> None:
        temp = tempfile.TemporaryDirectory(prefix="req-wf-s3-")
        self.addCleanup(temp.cleanup)
        self.foundation = create_foundation(Path(temp.name))
        self.root = create_project(self.foundation, PROJECT, "语音约碰面地点测试项目")
        self.tools = RecordingTools(
            RequirementsTools(foundation=self.foundation, helper_root=HELPER_ROOT)
        )
        self.domain = RecordingDomainTools(self.adapter())

    def adapter(self) -> DevelopHelperDomainTools:
        return DevelopHelperDomainTools(
            foundation=self.foundation,
            helper_root=HELPER_ROOT,
            approval_policy=ApprovalTrustPolicy.deny_all(),
            runtime_authority="req-wf-s3-test",
        )

    def deps(self, runner, *, domain="default", policy=None, **overrides):
        values = {
            "allowed_projects": frozenset({PROJECT}),
            "task_projects": {TASK: PROJECT},
            "agent_runner": runner,
            "tools": self.tools,
            "domain_tools": self.domain if domain == "default" else domain,
            "clock": lambda: NOW,
        }
        if policy is not None:
            values["policy"] = policy
        values.update(overrides)
        return WorkflowDependencies(**values)

    def tree(self) -> dict[str, str]:
        return {
            path.relative_to(self.root).as_posix(): (
                "dir" if path.is_dir() else _sha(path.read_bytes())
            )
            for path in sorted(self.root.rglob("*"))
        }

    def write(self, relative: str, text: str) -> bytes:
        path = self.root / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")
        return path.read_bytes()

    def history(self) -> dict[str, bytes]:
        directory = self.root / "docs" / "prd-history"
        if not directory.is_dir():
            return {}
        return {p.name: p.read_bytes() for p in sorted(directory.iterdir())}

    def review(self, body: str = PRD_BODY, deliverable: str = "prd") -> Progress:
        runner = FakeAgentRunner([_package(body, deliverable)])
        before = self.tree()
        calls = len(self.domain.calls)
        result = run_turn(_first_turn(), None, self.deps(runner))
        self.assertIs(result.stage, Stage.CANDIDATE_REVIEW)
        self.assertEqual(len(runner.calls), 1)
        self.assertEqual(self.tree(), before)
        self.assertEqual(len(self.domain.calls), calls)
        return result.progress

    def save(self, progress: Progress, turn: TurnInput | None = None, **deps):
        runner = FakeAgentRunner([_package(PRD_BODY_B)])
        result = run_turn(turn or _save_turn(progress.candidate), progress, self.deps(runner, **deps))
        self.assertEqual(runner.calls, [])
        return result

    def tool(self, result, name: str):
        found = [r for r in result.tool_results if r.tool == name]
        self.assertEqual(len(found), 1, name)
        return found[0]

    def assert_not_saved(self, result, before: dict[str, str]) -> None:
        self.assertIs(result.stage, Stage.BLOCKED)
        self.assertIn("PRD 未保存", result.content)
        self.assertNotIn("PRD Draft 已保存", result.content)
        self.assertEqual(self.tree(), before)
        self.assertIsNone(result.progress.save_reference)
        self.assertNotIn(Action.SAVE, result.next_actions)
        self.assertFalse(any(r.tool == "save_prd_draft" and r.ok for r in result.tool_results))

    def assert_saved(self, result, body: str, requirements_sha: str = MISSING) -> bytes:
        raw = (self.root / PRD).read_bytes()
        self.assertIs(result.stage, Stage.SAVED)
        self.assertIs(result.progress.stage, Stage.SAVED)
        self.assertEqual(raw, _rendered(body, requirements_sha))
        saved = self.tool(result, "save_prd_draft")
        self.assertTrue(saved.ok)
        self.assertEqual(saved.data["sha256"], _sha(raw))
        self.assertEqual((saved.data["path"], saved.data["status"]), (PRD, "Draft"))
        self.assertIs(saved.data["approval_verified"], False)
        self.assertTrue(self.tool(result, "reread_prd").ok)
        inspect = self.tool(result, "inspect_prd")
        self.assertTrue(inspect.ok)
        self.assertEqual(inspect.data["sha256"], _sha(raw))
        self.assertEqual((inspect.data["status"], inspect.data["issues"]), ("ready_for_review", []))
        self.assertEqual(
            [r.tool for r in result.progress.save_results],
            ["save_prd_draft", "reread_prd", "inspect_prd"],
        )
        self.assertEqual(result.progress.save_reference, _reference(result.progress.candidate))
        self.assertIn("PRD Draft 已保存", result.content)
        self.assertIn("Draft 不等于正式确认", result.content)
        self.assertEqual(result.next_actions, {Action.REVISE, Action.PAUSE})
        return raw


class PrdSaveTest(SaveTestCase):
    def test_exact_authorization_saves_the_prd_without_calling_the_role(self) -> None:
        review = self.review()
        candidate = review.candidate
        before = self.tree()
        result = self.save(review)
        raw = self.assert_saved(result, PRD_BODY)

        self.assertEqual(self.domain.names(), ["save_prd_draft", "inspect_draft"])
        _, command, context = self.domain.saves()[0]
        self.assertEqual(command.body, candidate.body)
        self.assertEqual(command.expected_prd_sha256, candidate.baseline.document(PRD).sha256)
        self.assertEqual(
            command.expected_requirements_sha256,
            candidate.baseline.document(REQUIREMENTS).sha256,
        )
        grant = context.capability_grant
        self.assertEqual((context.project_id, context.step_id), (PROJECT, "N04"))
        self.assertEqual(grant.assigned_role, DETERMINISTIC_ROLE)
        self.assertEqual(grant.allowed_side_effects, frozenset({SAVE_DRAFT}))
        self.assertEqual(grant.writable_paths, frozenset({PRD}))
        self.assertEqual(grant.artifact_types, frozenset({"prd"}))
        self.assertIn(candidate.candidate_id, context.run_id)
        _, kind, inspect_context = self.domain.calls[1]
        self.assertEqual((kind, inspect_context.step_id), ("prd", "N05"))
        self.assertEqual(inspect_context.capability_grant.allowed_side_effects, frozenset())

        self.assertTrue(self.tool(result, "check_baseline").ok)
        self.assertTrue(self.tool(result, "save_prd_draft").data["changed"])
        self.assertIsNone(self.tool(result, "save_prd_draft").data["history"])
        after = self.tree()
        changed = {p for p in after if before.get(p) != after[p]}
        self.assertEqual(changed, {"docs", PRD})
        self.assertEqual(self.history(), {})
        self.assertEqual(after[PRD], _sha(raw))
        self.assertEqual(result.progress.candidate, candidate)

    def test_update_keeps_the_previous_prd_in_history(self) -> None:
        old = self.write(PRD, "# 旧 PRD\n\n上一版内容。\n")
        requirements = self.write(REQUIREMENTS, "# 轻量需求\n\n已有轻量需求。\n")
        review = self.review()
        self.assertEqual(review.candidate.baseline.document(PRD).sha256, _sha(old))

        result = self.save(review)
        self.assert_saved(result, PRD_BODY, _sha(requirements))
        self.assertEqual(self.history(), {f"{_sha(old)}.md": old})
        _, command, context = self.domain.saves()[0]
        self.assertEqual(command.expected_prd_sha256, _sha(old))
        self.assertEqual(
            context.capability_grant.writable_paths,
            frozenset({PRD, f"docs/prd-history/{_sha(old)}.md"}),
        )
        saved = self.tool(result, "save_prd_draft")
        self.assertEqual(saved.data["history"], f"docs/prd-history/{_sha(old)}.md")
        self.assertIn(f"docs/prd-history/{_sha(old)}.md", result.content)
        self.assertEqual((self.root / REQUIREMENTS).read_bytes(), requirements)

    def test_identical_content_is_not_rewritten_and_adds_no_history(self) -> None:
        self.write(PRD, "# 旧 PRD\n")
        first = self.save(self.review())
        raw = self.assert_saved(first, PRD_BODY)
        history = self.history()
        self.assertEqual(len(history), 1)

        again = self.review()
        self.assertEqual(again.candidate.baseline.document(PRD).sha256, _sha(raw))
        before = self.tree()
        result = self.save(again)
        self.assert_saved(result, PRD_BODY)
        self.assertFalse(self.tool(result, "save_prd_draft").data["changed"])
        self.assertIn("未重写", result.content)
        self.assertEqual(self.history(), history)
        self.assertEqual(self.tree(), before)
        self.assertEqual(len(self.domain.saves()), 2)

    def test_a_new_candidate_does_not_reuse_the_previous_save_result(self) -> None:
        first = self.save(self.review())
        raw_a = self.assert_saved(first, PRD_BODY)

        second_review = self.review(PRD_BODY_B)
        self.assertNotEqual(
            second_review.candidate.candidate_id, first.progress.candidate.candidate_id
        )
        second = self.save(second_review)
        raw_b = self.assert_saved(second, PRD_BODY_B)
        self.assertNotEqual(raw_a, raw_b)
        self.assertEqual(self.history(), {f"{_sha(raw_a)}.md": raw_a})
        saves = self.domain.saves()
        self.assertEqual(len(saves), 2)
        self.assertNotEqual(saves[0][2].idempotency_key, saves[1][2].idempotency_key)
        self.assertEqual(self.tool(second, "save_prd_draft").data["sha256"], _sha(raw_b))
        self.assertEqual(
            self.tool(second, "save_prd_draft").data["candidate_id"],
            second_review.candidate.candidate_id,
        )

    def test_repeated_request_checks_the_known_effect_and_never_rewrites(self) -> None:
        self.write(PRD, "# 旧 PRD\n")
        review = self.review()
        raw = self.assert_saved(self.save(review), PRD_BODY)
        before, history = self.tree(), self.history()

        for name, domain in (("same adapter", self.domain), ("fresh adapter", None)):
            with self.subTest(case=name):
                tools = domain or RecordingDomainTools(self.adapter())
                calls = len(tools.saves())
                result = self.save(review, domain=tools)
                self.assert_saved(result, PRD_BODY)
                self.assertEqual(len(tools.saves()), calls)
                self.assertFalse(self.tool(result, "check_baseline").ok)
                self.assertFalse(self.tool(result, "save_prd_draft").data["changed"])
                self.assertIn("本轮未重写", result.content)
                self.assertEqual(self.tree(), before)
                self.assertEqual(self.history(), history)

        edited = self.write(PRD, raw.decode("utf-8") + "\n外部补充。\n")
        before = self.tree()
        calls = len(self.domain.saves())
        result = self.save(review)
        self.assert_not_saved(result, before)
        self.assertEqual(len(self.domain.saves()), calls)
        self.assertEqual((self.root / PRD).read_bytes(), edited)


class SaveAuthorizationTest(SaveTestCase):
    def assert_rejected(self, error, turn, progress, **deps) -> None:
        runner = FakeAgentRunner([_package(PRD_BODY)])
        before = self.tree()
        self.tools.calls.clear()
        self.domain.calls.clear()
        with self.assertRaises(error):
            run_turn(turn, progress, self.deps(runner, **deps))
        self.assertEqual(runner.calls, [])
        self.assertEqual(self.tools.calls, [])
        self.assertEqual(self.domain.calls, [])
        self.assertEqual(self.tree(), before)

    def test_missing_stale_or_mismatched_references_never_save(self) -> None:
        review = self.review()
        candidate = review.candidate
        other = self.review(PRD_BODY_B).candidate
        cases = {
            "other_candidate": _save_turn(other),
            "other_digest": _save_turn(
                candidate,
                save=SaveReference(candidate.candidate_id, other.body_sha256, Deliverable.PRD, PRD),
            ),
            "other_deliverable": _save_turn(
                candidate,
                save=SaveReference(
                    candidate.candidate_id, candidate.body_sha256, Deliverable.REQUIREMENTS, REQUIREMENTS
                ),
            ),
        }
        for name, turn in cases.items():
            with self.subTest(case=name):
                self.assert_rejected(ContractError, turn, review)
        with self.assertRaises(ContractError):
            SaveReference(candidate.candidate_id, candidate.body_sha256, Deliverable.PRD, REQUIREMENTS)
        with self.subTest(case="no_progress"):
            self.assert_rejected(ContractError, _save_turn(candidate), None)
        with self.subTest(case="not_a_save_action"):
            with self.assertRaises(ContractError):
                TurnInput(TASK, PROJECT, Action.REVISE, "这个方向可以", save=_reference(candidate))
        with self.subTest(case="saved_progress"):
            saved = dataclasses.replace(
                review, stage=Stage.SAVED, save_reference=_reference(candidate)
            )
            self.assert_rejected(ContractError, _save_turn(candidate), saved)

    def test_candidate_without_baseline_cannot_be_saved(self) -> None:
        review = self.review()
        bare = dataclasses.replace(review.candidate, baseline=None)
        progress = dataclasses.replace(review, candidate=bare)
        self.assert_rejected(ContractError, _save_turn(bare), progress)

    def test_changed_materials_void_the_save_reference(self) -> None:
        review = self.review()
        first = FIRST_MATERIALS[0]
        edited = SourceMaterial(
            first.source_id, first.location, first.version, first.category, first.body + "\n补充。"
        )
        changed = (edited, *FIRST_MATERIALS[1:])
        self.assert_rejected(ContractError, _save_turn(review.candidate, materials=changed), review)
        fewer = FIRST_MATERIALS[1:]
        self.assert_rejected(ContractError, _save_turn(review.candidate, materials=fewer), review)
        moved = dataclasses.replace(
            review, input_versions=review.input_versions[1:], materials=review.materials[1:]
        )
        self.assert_rejected(ContractError, _save_turn(review.candidate), moved)

        same = tuple(reversed(FIRST_MATERIALS))
        self.assert_saved(self.save(review, _save_turn(review.candidate, materials=same)), PRD_BODY)

    def test_project_binding_and_tool_configuration_are_checked_first(self) -> None:
        review = self.review()
        turn = _save_turn(review.candidate)
        self.assert_rejected(AuthorizationError, turn, review, allowed_projects=frozenset({"other"}))
        self.assert_rejected(AuthorizationError, turn, review, task_projects={TASK: "other"})
        self.assert_rejected(ContractError, turn, review, domain=None)


class SaveConflictTest(SaveTestCase):
    def test_files_changed_after_review_are_not_overwritten(self) -> None:
        self.write(PRD, "# 旧 PRD\n")
        self.write(REQUIREMENTS, "# 轻量需求\n")
        project_json = (self.root / "project.json").read_text(encoding="utf-8")
        edits = {
            PRD: "# 审阅期间外部修改的 PRD\n",
            REQUIREMENTS: "# 审阅期间外部修改的轻量需求\n",
            "README.md": "# 审阅期间外部修改的 README\n",
            "docs/decisions.md": "# 审阅期间新增的决策\n",
            "project.json": project_json + "\n",
        }
        for path, text in edits.items():
            with self.subTest(changed=path):
                review = self.review()
                original = (self.root / path).read_bytes() if (self.root / path).exists() else None
                edited = self.write(path, text)
                before = self.tree()
                calls = len(self.domain.saves())
                result = self.save(review)
                self.assert_not_saved(result, before)
                self.assertEqual(len(self.domain.saves()), calls)
                self.assertEqual((self.root / path).read_bytes(), edited)
                check = self.tool(result, "check_baseline")
                self.assertFalse(check.ok)
                self.assertEqual(check.data["changed"], [path])
                self.assertEqual(
                    check.data["baseline"][path], review.candidate.baseline.document(path).sha256
                )
                self.assertEqual(check.data["current"][path], _sha(edited))
                self.assertIn(path, result.content)
                if original is None:
                    (self.root / path).unlink()
                else:
                    (self.root / path).write_bytes(original)

    def test_kernel_version_check_still_uses_the_review_baseline(self) -> None:
        self.write(PRD, "# 旧 PRD\n")
        for path in (PRD, REQUIREMENTS):
            with self.subTest(changed=path):
                review = self.review()
                original = (self.root / path).read_bytes() if (self.root / path).exists() else None
                edited = []
                self.domain.before_save = lambda: edited.append(self.write(path, "# 保存前一刻被改\n"))
                result = self.save(review)
                self.domain.before_save = None
                self.assertIs(result.stage, Stage.BLOCKED)
                self.assertIn("PRD 未保存", result.content)
                self.assertIn("写入前拒绝", result.content)
                self.assertEqual((self.root / path).read_bytes(), edited[0])
                self.assertEqual(self.history(), {})
                _, command, _ = self.domain.saves()[-1]
                self.assertEqual(command.expected_prd_sha256, review.candidate.baseline.document(PRD).sha256)
                self.assertEqual(
                    command.expected_requirements_sha256,
                    review.candidate.baseline.document(REQUIREMENTS).sha256,
                )
                if original is None:
                    (self.root / path).unlink()
                else:
                    (self.root / path).write_bytes(original)


class SavePermissionTest(SaveTestCase):
    def test_step_role_project_and_path_scope_are_enforced(self) -> None:
        self.write(PRD, "# 旧 PRD\n")

        def assignment(**fields):
            return lambda workflow, assigned: (workflow, dataclasses.replace(assigned, **fields))

        def history_only(workflow, assigned):
            return workflow, dataclasses.replace(assigned, writable_paths=frozenset({PRD}))

        def other_project(workflow, assigned):
            return dataclasses.replace(workflow, project_id="other-project"), assigned

        def other_node(workflow, assigned):
            return (
                dataclasses.replace(workflow, current_node="N10"),
                dataclasses.replace(assigned, step_id="N10"),
            )

        cases = {
            "requirements_role": (assignment(assigned_role="requirements"), False),
            "other_node_with_save_draft": (other_node, False),
            "other_project": (other_project, False),
            "missing_history_path": (history_only, True),
            "extra_writable_path": (
                lambda w, a: (w, dataclasses.replace(a, writable_paths=a.writable_paths | {REQUIREMENTS})),
                True,
            ),
            "missing_readable_path": (
                lambda w, a: (w, dataclasses.replace(a, readable_paths=frozenset({PRD}))),
                True,
            ),
            "other_artifact_type": (assignment(artifact_types=frozenset({"tech-spec"})), True),
        }
        for name, (change, reaches_adapter) in cases.items():
            with self.subTest(case=name):
                review = self.review()
                before, history = self.tree(), self.history()
                calls = len(self.domain.saves())
                result = self.save(review, policy=TamperingPolicy("N04", change))
                self.assert_not_saved(result, before)
                self.assertEqual(self.history(), history)
                self.assertEqual(len(self.domain.saves()), calls + int(reaches_adapter))
                self.assertNotIn("inspect_draft", self.domain.names()[calls:])

        result = self.save(self.review())
        self.assert_saved(result, PRD_BODY)


class SaveFailureTest(SaveTestCase):
    def test_failures_before_writing_report_not_saved(self) -> None:
        bodies = {
            "front_matter": "---\nstatus: Approved\n---\n\n" + PRD_BODY,
            "wrong_source_digest": PRD_BODY + "\n\n来源 README.md sha256: " + "0" * 64,
        }
        for name, body in bodies.items():
            with self.subTest(case=name):
                review = self.review(body)
                before = self.tree()
                result = self.save(review)
                self.assert_not_saved(result, before)
                self.assertIn("写入前拒绝", result.content)
                self.assertFalse((self.root / PRD).exists())

        review = self.review()
        before = self.tree()

        def refuse():
            raise OSError("disk unavailable")

        self.domain.before_save = refuse
        result = self.save(review)
        self.assert_not_saved(result, before)
        self.assertIn("复读确认 PRD 未写入", result.content)

    def test_unknown_outcome_is_observed_once_and_never_retried(self) -> None:
        review = self.review()

        def lost_reply(saved):
            raise OSError("connection lost after the write")

        self.domain.after_save = lost_reply
        result = self.save(review)
        self.assert_saved(result, PRD_BODY)
        self.assertEqual(len(self.domain.saves()), 1)
        self.assertIn("复读确认本候选已写入", result.content)

        review = self.review(PRD_BODY_B)
        self.domain.after_save = lambda saved: {"sha256": "not-a-digest"}
        result = self.save(review)
        self.assert_saved(result, PRD_BODY_B, MISSING)
        self.assertEqual(len(self.domain.saves()), 2)

        review = self.review(PRD_BODY)
        foreign = []

        def foreign_write(saved):
            foreign.append(self.write(PRD, "# 另一个写入者的内容\n"))
            raise OSError("reply lost")

        self.domain.after_save = foreign_write
        result = self.save(review)
        self.assertIs(result.stage, Stage.BLOCKED)
        self.assertIn("保存结果无法确认", result.content)
        self.assertNotIn("PRD Draft 已保存", result.content)
        self.assertEqual((self.root / PRD).read_bytes(), foreign[0])
        self.assertEqual(len(self.domain.saves()), 3)
        self.assertIsNone(self.tool(result, "save_prd_draft").data["written"])

    def assert_written_not_verified(self, result, failed: set[str]) -> None:
        self.assertIs(result.stage, Stage.BLOCKED)
        self.assertIn("PRD 文件已写入", result.content)
        self.assertIn("写后检查未通过", result.content)
        self.assertNotIn("PRD Draft 已保存", result.content)
        saved = self.tool(result, "save_prd_draft")
        self.assertTrue(saved.ok)
        self.assertTrue(saved.data["changed"])
        self.assertEqual(
            saved.data["sha256"] == _sha((self.root / PRD).read_bytes()),
            "reread_prd" not in failed,
        )
        self.assertEqual(
            {r.tool for r in result.tool_results if r.tool in {"reread_prd", "inspect_prd"} and not r.ok},
            failed,
        )
        self.assertEqual(
            [r.tool for r in result.progress.save_results],
            ["save_prd_draft", "reread_prd", "inspect_prd"],
        )
        self.assertIsNone(result.progress.save_reference)
        self.assertNotIn(Action.SAVE, result.next_actions)

    def test_checks_failing_after_the_write_are_reported_as_written_not_verified(self) -> None:
        thin = "# PRD\n\n只有标题，缺少必需章节。"
        result = self.save(self.review(thin))
        self.assert_written_not_verified(result, {"inspect_prd"})
        self.assertEqual((self.root / PRD).read_bytes(), _rendered(thin))
        inspect = self.tool(result, "inspect_prd")
        self.assertEqual(inspect.data["status"], "attention_required")
        self.assertIn("prd_sections_missing", {i["code"] for i in inspect.data["issues"]})
        self.assertIn("prd_sections_missing", result.content)

        review = self.review()
        touched = []

        def edited_after(saved):
            touched.append(self.write(PRD, (self.root / PRD).read_text(encoding="utf-8") + "并发追加。\n"))
            return saved

        self.domain.after_save = edited_after
        result = self.save(review)
        self.domain.after_save = None
        self.assert_written_not_verified(result, {"reread_prd", "inspect_prd"})
        self.assertEqual((self.root / PRD).read_bytes(), touched[0])
        self.assertIn("摘要与保存返回不一致", result.content)

        review = self.review(PRD_BODY_B)
        with mock.patch.object(
            self.domain.inner, "inspect_draft", side_effect=RuntimeError("inspect unavailable")
        ):
            result = self.save(review)
        self.assert_written_not_verified(result, {"inspect_prd"})
        self.assertIn("inspect unavailable", self.tool(result, "inspect_prd").data["error"])
        self.assertEqual(len(self.domain.saves()), 3)

        review = self.review(PRD_BODY)
        check_role = TamperingPolicy(
            "N05", lambda w, a: (w, dataclasses.replace(a, assigned_role=DETERMINISTIC_ROLE))
        )
        result = self.save(review, policy=check_role)
        self.assertEqual(len(self.domain.saves()), 4)
        self.assertIs(result.stage, Stage.BLOCKED)
        self.assertIn("PRD 文件已写入", result.content)
        self.assertFalse(self.tool(result, "reread_prd").ok)
        self.assertFalse(self.tool(result, "inspect_prd").ok)
        self.assertNotEqual(self.domain.names()[-1], "inspect_draft")
        self.assertEqual(
            (self.root / PRD).read_bytes(), _rendered(PRD_BODY, MISSING)
        )


class SaveScopeTest(SaveTestCase):
    def test_analysis_still_stops_at_candidate_review(self) -> None:
        review = self.review()
        self.assertEqual(self.domain.calls, [])
        self.assertFalse((self.root / PRD).exists())
        self.assertIsNone(review.save_reference)
        self.assertEqual(review.save_results, ())

    def test_registration_and_other_actions_are_rejected_without_side_effects(self) -> None:
        prd = self.review()
        cases = {
            "registration": (
                _save_turn(prd.candidate, register_index=True),
                prd,
                UnsupportedActionError,
                "not implemented",
            ),
            "research_without_request": (
                TurnInput(TASK, PROJECT, Action.RESEARCH, "去查一下"),
                Progress(TASK, PROJECT, Stage.RESEARCHING),
                ContractError,
                "no research request",
            ),
        }
        for name, (turn, progress, error, message) in cases.items():
            with self.subTest(case=name):
                runner = FakeAgentRunner([_package(PRD_BODY)])
                before = self.tree()
                self.tools.calls.clear()
                self.domain.calls.clear()
                with self.assertRaises(error) as caught:
                    run_turn(turn, progress, self.deps(runner))
                self.assertIn(message, str(caught.exception))
                self.assertEqual(runner.calls, [])
                self.assertEqual(self.tools.calls, [])
                self.assertEqual(self.domain.calls, [])
                self.assertEqual(self.tree(), before)


if __name__ == "__main__":
    unittest.main()
